# 动态表单定义协议

复杂动态表单与数据录入引擎的领域词汇。协议与决策正文见 [L1 定义协议](design/l1/README.md)。

## Language

**Pure Function（纯函数）**：表单纯表达式可调用的同步、确定性计算能力，内置能力与注册的领域能力属于同一类别；输入相同则输出相同，不读外部可变状态，也不产生 I/O 或数据写入副作用。
_Avoid_：泛称 Function 而省略纯计算约束、把异步业务操作归入纯函数。

**Capability Catalog**：编译时可查询的 Material 与 Pure Function 契约集合；Host 静态契约可以作为可选补充。
_Avoid_：将契约目录等同于可执行代码或统一业务执行器。

**Capability Lock**：一次表单发布在指定平台与 Profile 下选定的能力版本及不可变制品身份。
_Avoid_：以最新版本指针代替发布锁定。

**Form Release**：绑定业务表单版本、编译产物、能力锁及 Host 依赖要求的不可变发布单元。
_Avoid_：回滚时使用当前能力目录重新组装旧发布。

**View Profile**：同一 FormDefinition 内按场景命名的视图，其值直接是一个 ViewNode。`default` 只是可选名称，不表示额外的协议层级。
_Avoid_：Profile Entry 包装、固定 default 根。

**Default Slot**：Material 的默认子节点组合位置，以 `slots.default` 表达，与 Profile 名称无关。
_Avoid_：把默认插槽与默认视图混用。

**定义信息**：文档中对协议标识、版本和非执行性 metadata 的阅读分组；它不是新的协议字段或嵌套对象。
_Avoid_：basicInfo 协议域。
