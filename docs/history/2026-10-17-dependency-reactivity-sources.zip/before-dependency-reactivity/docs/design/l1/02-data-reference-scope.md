# 数据、引用与作用域

> L1 V1.0 架构与语义决策正文；正式类型、Schema 与发布验收状态见各节。

## Data / Value / Default / Output {#data}

> 状态：已收敛

**数据结构只定义一次**

```json
{
  "data": {
    "schema": {
      "type": "object",
      "properties": {
        "applicant": { "$ref": "#/$defs/Person" },
        "insureds": { "type": "array", "items": { "$ref": "#/$defs/Person" } }
      },
      "$defs": {
        "Person": {
          "type": "object",
          "properties": {
            "name": { "type": "string" },
            "age": { "type": "integer" }
          }
        }
      }
    }
  }
}
```

- **数据与视图分离：**JSON Schema 管结构与基础约束；单个 Form 不需要按 Profile 创建多份业务 Schema。
- **Working Data 允许暂时不合法：**例如输入过程、Host 回填或旧数据，不得静默以“最后一次合法值”替换当前数据。
- **缺失与 null 不同：**Missing、null、解析失败属于不同语义；不设计独立的 Incomplete 解析状态。
- **默认值：**Host 初始化数据优先，Schema 默认值可填充真正缺失的位置；不覆盖显式 null。
- **提交：**通过 Schema、内部约束、必要外部约束和输出转换后才构造规范化输出；Host 负责真正提交。

## Reference：统一寻址规则 {#reference}

> 状态：已收敛

**引用类别**

```typescript
type DataReference = {
  source: 'data';
  path: string;          // JSON Pointer
  scope?: string;        // 仅词法可见的局部名称
};
type ContextReference = {
  source: 'context';
  path: string;
};
type EventReference = {
  source: 'event';
  path: string;
};
```

**不同来源的只读/可写能力由所处位置约束**

```text
{ "source": "data", "path": "/applicant/name" }
{ "source": "data", "scope": "insured", "path": "/age" }
{ "source": "context", "path": "/countryOptions" }
{ "source": "event", "path": "/selectedValue" }
```

统一使用 JSON Pointer：`""` 表示引用根值，`"/"` 表示空字符串字段名。绝对路径简写（例如 `"/applicant/name"`）始终从 Form Data 根开始，不会随当前 Scope 隐式变成相对路径。

> **位置级约束**
> 
> Expression 可读取受允许的 Data / Context（Event 仅在交互上下文有效）；Command `target` 只能写 Data，不能写 Context、Event 或 Material Props。

## ScopeBinder：局部词法绑定，不建全局注册表 {#scope}

> 状态：已收敛

**唯一绑定语义**

```typescript
interface ScopeBinder {
  from: DataReference;
  as: string;
  mode?: 'one' | 'each';
}
```

`one` 将一个数据位置绑定为局部名称；`each` 对一个数组的每个项建立独立上下文。在 View 的 ScopeNode 中，`each` **直接表示重复实例化对应子视图**，父 Material 不需要额外 `repeat`。

**View 中的逐项实例化**

```json
{
  "scope": {
    "from": { "source": "data", "path": "/insureds" },
    "as": "insured",
    "mode": "each"
  },
  "node": {
    "material": "insured-card",
    "bindings": {
      "value": { "source": "data", "scope": "insured", "path": "" }
    }
  }
}
```

View、Reaction、Constraint 在协议允许的位置建立局部 Binder；它们不定义独立的数据存储域。L2 处理词法名称绑定，L3 对应实际数据位置与数组项稳定身份；不同规则使用同名别名，不构成全局 Scope 冲突。

> **不扩张为通用变量系统**
> 
> Scope 只能出现于明确的结构性入口；普通 Props、Expression 和 Command 都不能随意创建 Scope。`from` 不接受任意 Expression 拼出的动态数据位置；词法链中不得重复遮蔽已有别名（V1 保守规则）。

## ScopeHandle 与数组实例身份 {#scope-handle}

> 状态：已收敛

**Data Reference 与 ScopeHandle 不混用**

```text
// 获取当前数组项的业务值：
{ "source": "data", "scope": "insured", "path": "" }

// 在需要项身份的命令中表达当前实例：
{ "$scope": "insured" }

// 示例：精确删除当前项，而不是按数组下标删除
{
  "op": "array.remove",
  "target": { "source": "data", "path": "/insureds" },
  "item": { "$scope": "insured" }
}
```

ScopeHandle 表示数据实例的定位身份，不代表数据副本，也不是业务主键。数组排序后不能悄悄指向新的同下标对象；原实例被删除时句柄失效。普通 View Template 参数则**只传 Data Reference**，不需要对外暴露 ScopeHandle。
