# 表达式、约束与校验

> L1 V1.0 架构与语义决策正文；正式类型、Schema 与发布验收状态见各节。

## Expression AST 与 ValueSpec {#expression}

> 状态：已收敛

**概念类型 · 正式 Union 仍需消歧校验**

```typescript
type Expression =
  | JsonPrimitive
  | { ref: Reference }
  | { use: string }
  | { op: string; args: Expression[] }
  | { literal: JsonValue };

type ValueSpec =
  | JsonPrimitive
  | { $expr: Expression }
  | { $literal: JsonValue }
  | ValueSpec[]
  | { [key: string]: ValueSpec };
```

Expression 是纯计算 AST，采用严格类型、有限内置 Pure Function 与版本化领域纯函数。Named Expression 可复用，但全局命名表达式不得隐式捕获调用方的局部 Scope；V1 不引入参数化函数语言。

**Pure Function 命名与能力边界 · 2026.10.17 架构决策**

内置与注册的同步纯计算统一称为 Pure Function（纯函数），使用同一调用协议；复杂同步校验直接复用领域纯函数，不新增平行的同步 Validator DSL。纯函数不执行 I/O、不读外部可变状态、不修改数据，也不管理 Scope 或校验状态；Constraint 负责适用条件、Issue 目标和错误码，内部 `assert` 必须返回 boolean。

本次保留 Expression 的 `op + args` 字段。`core.*` 为内置能力保留命名空间，业务 ID 不得覆盖；短 ID 的明确别名与规范化映射随正式契约固化，现有草案示例暂保留短名。L2 按确定 Catalog 解析签名与依赖，L3 绑定锁定实现；版本和制品锁不新增为 L1 顶层字段。详见 [L2 纯函数命名](../l2-preparation.md#l2-function-identity) 与 [能力契约](../l2-preparation.md#l2-manifests)。

**动态 Expression 可以出现在任意嵌套 ValueSpec 内**

```json
{
  "material": "summary-card",
  "props": {
    "title": "投保摘要",
    "badge": {
      "visible": {
        "$expr": {
          "op": "eq",
          "args": [
            { "ref": { "source": "data", "path": "/plan" } },
            "premium"
          ]
        }
      }
    }
  }
}
```

| 协议位置 | 表达式形态 |
| --- | --- |
| `constraint.assert` / `reaction.when` / `expressions.*` | 直接使用 Expression AST |
| `props.*` / `command.value` / `host.emit.payload` | 递归 ValueSpec，通过完整的 `$expr` 包装进入表达式 |
| 需要原样保留标记对象 | 通过显式 Literal 转义表达，不能按普通对象形状误判表达式 |

> **求值失败的语义**
> 
> 解析失败或类型不匹配不等于 Expression 返回 `false`，也不等于自动使用最近一次合法值。同步业务 Constraint 不通过、外部校验 Pending 也不应自动阻断全部 Reaction。

## Constraint：内部断言与外部校验义务 {#constraint}

> 状态：已收敛

**Internal · 可同步求值的业务约束**

```json
{
  "id": "age-eligible",
  "kind": "internal",
  "scope": {
    "from": { "source": "data", "path": "/insureds" },
    "as": "insured",
    "mode": "each"
  },
  "assert": {
    "op": "gte",
    "args": [
      { "ref": { "source": "data", "scope": "insured", "path": "/age" } },
      18
    ]
  },
  "issue": {
    "target": { "source": "data", "scope": "insured", "path": "/age" },
    "code": "AGE_BELOW_MINIMUM"
  }
}
```

**External · 声明义务，不声明 URL 或请求策略**

```json
{
  "id": "insured-eligibility",
  "kind": "external",
  "scope": {
    "from": { "source": "data", "path": "/insureds" },
    "as": "insured",
    "mode": "each"
  },
  "dependsOn": [
    { "source": "data", "scope": "insured", "path": "/age" },
    { "source": "data", "scope": "insured", "path": "/idNumber" }
  ],
  "target": { "source": "data", "scope": "insured", "path": "/idNumber" },
  "requiredForSubmit": true
}
```

内部约束使用可选 `when` 和必需的 `assert`；外部约束声明依赖、归属位置及是否阻断提交。**Constraint 不执行 Command，不设计 onFail 动作链。**

## 校验状态与提交 Readiness 的协议边界 {#validation}

> 状态：已收敛

L1 只需要完整声明约束；各约束实例的结果、失效和状态迁移由 L3 统一管理，不是一个需要写入 Form Definition 的 `validationState` 字段。外部校验由 Host 执行并上报，而不是由 Form Runtime 自行发送网络请求。

| 状态 | 语义 |
| --- | --- |
| unverified | 尚未对当前有效数据版本取得结论 |
| pending | 对应校验正在进行 |
| valid | 当前有效输入版本验证通过 |
| invalid | 当前有效输入版本验证未通过 |
| error | 校验执行错误，不能被当成通过 |

一个外部 Constraint 在数组 Scope 下会派生出多个实例义务；结果需与具体数据项及版本关联。数据发生依赖变化后旧结果失效。Submit Readiness 依赖 Schema、内部约束、输出有效性及所有**当前适用且 requiredForSubmit** 的外部约束，不能以“未知或请求失败”冒充通过。

> **与 View 的关系已经定稿**
> 
> View 的 `bindings` 只写数据位置。无需 `validationBind`、`errorBind` 或物料校验管理字段；Runtime 提供状态，Material 只负责显示。字段状态机的具体结构留到 L3。
