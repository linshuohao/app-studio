# 命令与同步联动

> L1 V1.0 架构与语义决策正文；正式类型、Schema 与发布验收状态见各节。

## Command：封闭的受控数据修改语言 {#commands}

> 状态：已收敛

| 操作 | 语义 | 边界 |
| --- | --- | --- |
| set | 替换目标 Data 值 | 目标必须为可写 Data Reference |
| patch | 浅层对象字段更新 | 不隐式递归深度合并 |
| remove | 删除属性位置 | 区分将属性设为 null |
| array.insert | 插入集合项 | 受目标 Schema 约束 |
| array.remove | 按稳定项身份删除 | 不可仅依赖不稳定 index |
| array.move | 按稳定项身份移动 | 保留被移动项身份 |
| batch | 把多个 Command 视为一次逻辑提交 | 不能变成通用工作流 |

**修改目标与计算值必须严格区分**

```json
{
  "op": "set",
  "target": { "source": "data", "path": "/order/total" },
  "value": {
    "$expr": {
      "op": "mul",
      "args": [
        { "ref": { "source": "data", "path": "/order/price" } },
        { "ref": { "source": "data", "path": "/order/quantity" } }
      ]
    }
  }
}
```

Command 只做表单数据修改。请求上传、业务审批、支付、弹窗动画和远端提交均不变成 Command 类型。复杂业务逻辑可以由 Host 根据结果发回一个受控 Command。

## Reaction：明确触发与条件的边界 {#reactions}

> 状态：已收敛

**规则级作用域可使用有序绑定链**

```typescript
interface Reaction {
  id: string;
  scope?: ScopeBinder | ScopeBinder[];
  watch: DataReference[];
  when?: Expression;
  then: Command[];
}
```

**数据变化时的最小联动声明**

```json
{
  "id": "clear-city-on-country-change",
  "scope": {
    "from": { "source": "data", "path": "/insureds" },
    "as": "insured",
    "mode": "each"
  },
  "watch": [
    { "source": "data", "scope": "insured", "path": "/country" }
  ],
  "then": [
    {
      "op": "set",
      "target": { "source": "data", "scope": "insured", "path": "/city" },
      "value": null
    }
  ]
}
```

`watch` 决定何时触发，`when` 决定触发后是否执行；二者不能互相代替。Expression 读取到的依赖不应自动变成触发条件。`then` 已经是有序 Command 数组，不必再强制包一层 `batch`。

> **范围约束**
> 
> Reaction 只消费内部同步 Data Change；外部异步校验完成并不会自动重新触发所有联动。需要改变数据时由 Host 显式提交 Command。
