# 生命周期与多视图交付

> L1 V1.0 架构与语义决策正文；正式类型、Schema 与发布验收状态见各节。

## 初始化、更新、重初始化与提交 {#lifecycle}

> 状态：已收敛

| 操作 | 语义约束 |
| --- | --- |
| Initialize | 创建当前 Form 实例基线；Host 数据优先，缺失位置按规则补默认值 |
| Update | 向当前 Working Data 提交受控数据修改；不是重新初始化 |
| Reinitialize | 用新的外部初始数据建立新的当前基线；不假扮逐字段用户编辑 |
| Reset | 回到当前初始化基线，不是必然回到第一次加载的旧基线 |
| Submit / Readiness | 内外约束以及输出完整性符合要求后，由 Host 执行真实提交 |

Definition 不增加 `onInit`、`onReset`、`beforeSubmit` 等通用生命周期脚本。宿主 API 的具体返回值或事务流程属于 L3/Host 实现，但上述生命周期的语义差异必须保持。

## 多 Profile 与按需交付 {#profiles}

> 状态：已收敛

View Profile 表达同一业务数据在不同终端或场景下采用不同的物料树。服务端或 L2 可以按请求只准备当前 Profile 的入口与其静态引用依赖，但共享 Data Schema、Constraint、Reaction 不能仅因为某字段不可见就被裁剪掉。

**Profile 是选择入口，不是复制 Form Definition**

```json
{
  "views": {
    "expanded": {
      "$use": "expanded-form"
    },
    "compact": {
      "$use": "compact-form"
    }
  }
}
```
