# 修订、待固化事项与发布

> L1 V1.0 架构与语义决策正文；正式类型、Schema 与发布验收状态见各节。

## 从早期方案到当前决策：修订记录 {#history}

> 状态：已收敛

01

**数据与业务边界**

确定 JSON Schema + 唯一 Working Data；Data、View、Validation 与外部业务执行分离。

02

**表达式与内部规则**

由多种可执行配置收敛为纯 Expression、Constraint 与受控 Command/Reaction。

03

**Scope 的权柄争论**

从可能的跨层 Scope 注册表，收敛为 Data 提供位置、局部 Binder 提供词法别名、L3 提供实例身份。

04

**View Root / Target / Fragment 重复**

统一为 具名 Profile → ViewNode + Named View Template + 静态 $use；不再各自维护定义体系。

05

**view.present 的撤回**

发现与容器/复合 Material 重叠，取消核心 Presentation DSL 和 view.present/view.dismiss。

06

**Binding/Validation 的纠偏**

取消 ValidationMetadata 作为独立 L1 DSL 的倾向；Binding 仅映射端口，字段与校验状态由 Runtime 管理。

07

**Canonical 结构统一**

bindings、slots 使用唯一规范形态；bind、children 可以作为 Authoring 简写。

08

**Typed Template Params 收敛**

采用 schemaRef + DataReference 传参；不创建泛型系统，也不暴露额外的 Template ScopeHandle。

09

**物料约束职责冻结**

Protocol 管机制、Material Manifest 管能力限制、Form Definition 管业务合法性。

10

**L1 架构定稿**

顶层结构及主要领域边界冻结，转入 TS 类型、机器 Schema 和一致性验收。

11

**Profile 去掉单字段包装 · 2026.10.16**

views 的每个具名 Profile 直接对应 ViewNode；原 entry 没有独立语义，予以移除。Profile 名可自由选择，default 不是固定关键字；slots.default 保持插槽语义。基础标识、版本与 metadata 在文档中合并展示为定义信息，协议顶层字段不变。

12

**Pure Function 命名与平台能力边界 · 2026.10.17**

统一采用 Pure Function（纯函数）作为内置和注册纯计算的能力分类，复杂同步校验复用纯函数；Material、Pure Function 与 Host 保留不同职责。Expression 继续使用 `op + args`，调用字段迁移另行决策。L2 消费确定的能力契约，Form Release 锁定版本与不可变制品身份；Host 运行时注册，静态契约可选。具体 [L2 决策与待固化接口](../l2-preparation.md#l2-decisions) 不等于生产协议实现已经完成。

## 被排除或延期的能力 {#tradeoffs}

> 状态：已收敛

| 方案 | 不进入核心的原因 | 替代方案 |
| --- | --- | --- |
| 全局 scopes 注册表 | 与 Data Schema 引用重复，提升解析间接性 | 局部 ScopeBinder + 统一实例身份 |
| 通用 Action / Workflow DSL | 把 Form 协议变为应用编排语言 | Command + Host |
| view.present / view.dismiss | 重复容器 Material 的展示职责 | Modal/Drawer/BottomSheet Material |
| 独立 Validation Binding | 同一数据位置重复绑定，增加 L1 语义 | Runtime Field State → 现有 Binding |
| 动态 Template ID | 引入动态 View 选择与状态替换问题 | 静态 $use + 物料内部组合 |
| 通用 Typed Params 泛型 | 类型证明器成本远超当前需要 | schemaRef 的 Typed Data Params |
| Expression 生成写入路径 | 降低引用静态可分析性 | 结构化 DataReference 作为 Command Target |
| 自动双向派生字段镜像 | 制造重复业务状态 | 需要展示用 Expression，需要保存时显式 Command |
| 生命周期脚本与请求 URL | 引入通用外部流程执行机制 | Host API 与 External Constraint |

## 仍需规范固化的事项：不等于重开架构 {#boundaries}

> 状态：待固化

| 事项 | 当前方向 | 固化工作 |
| --- | --- | --- |
| Reference / Expression Union | 类型与用途已经明确 | 确定严格判别结构和 Literal 转义边界 |
| ScopeBinder 单/链 | View 单 Binder、规则可链式绑定 | 用 Schema/TS 校验数组链顺序和遮蔽规则 |
| Pure Function Contract | 同步确定性、受限、类型明确；内置与注册共用调用 | 列出内置签名、`core.*` / 短名别名映射、错误诊断与版本契约 |
| Command 全量结构 | 封闭 7 类动作 | 补完插入位置、移动位置、批量失败边界 |
| JSON Schema 兼容性 | Typed Params 引用 schemaRef | 明确兼容性规则与静态不可证明时的诊断 |
| Material / Pure Function Version Resolution | 确定 Catalog Snapshot，Release 锁定版本及制品身份 | 固化锁字段、摘要对象、升级与 Runtime 兼容检查 |
| Interaction Event Context | Event Reference 仅在有效上下文 | 明确事件 Payload Schema 与解析限制 |
| Formal JSON Schema | Canonical 形状已收敛 | 生成并验证 2020-12 Schema 与 TS 类型一致性 |

> **冻结原则**
> 
> 这些是将“架构共识”工程化为“正式规范”的工作清单。除非样例或校验出现事实上的冲突，否则不再因局部实现问题增设新的顶层领域模型。

## 附录：完整的核心类型关系（概念稿） {#types}

> 状态：待固化

**架构核心类型汇编（用于后续正式 TypeScript 固化）**

```typescript
type JsonPrimitive = string | number | boolean | null;
type JsonValue = JsonPrimitive | JsonValue[] | { [key: string]: JsonValue };
type JsonSchema = Record<string, unknown>; // 采用正式 JSON Schema 类型

type DataReference = { source: 'data'; path: string; scope?: string };
type ContextReference = { source: 'context'; path: string };
type EventReference = { source: 'event'; path: string };
type Reference = DataReference | ContextReference | EventReference;

type ScopeBinder = {
  from: DataReference;
  as: string;
  mode?: 'one' | 'each';
};
type ScopeDeclaration = ScopeBinder | ScopeBinder[];
type ScopeHandleReference = { $scope: string };

type Expression =
  | JsonPrimitive
  | { ref: Reference }
  | { use: string }
  | { op: string; args: Expression[] }
  | { literal: JsonValue };

type ValueSpec =
  | JsonPrimitive
  | { $expr: Expression }
  | { $literal: JsonValue }
  | ValueSpec[]
  | { [key: string]: ValueSpec };

type IssueDefinition = { target: DataReference; code: string };

type InternalConstraint = {
  id: string; kind: 'internal';
  scope?: ScopeDeclaration;
  when?: Expression;
  assert: Expression;
  issue: IssueDefinition;
};
type ExternalConstraint = {
  id: string; kind: 'external';
  scope?: ScopeDeclaration;
  when?: Expression;
  dependsOn: DataReference[];
  target: DataReference;
  requiredForSubmit?: boolean;
};
type Constraint = InternalConstraint | ExternalConstraint;

// Command 具体每种操作的字段请以正式 JSON Schema 为准
// 下方展示稳定的分发类别，非已完整定义的公开类型。
type Command =
  | { op: 'set'; target: DataReference; value: ValueSpec }
  | { op: 'patch'; target: DataReference; value: Record<string, ValueSpec> }
  | { op: 'remove'; target: DataReference }
  | { op: 'array.insert'; target: DataReference; value: ValueSpec; [k: string]: unknown }
  | { op: 'array.remove'; target: DataReference; item: ScopeHandleReference }
  | { op: 'array.move'; target: DataReference; item: ScopeHandleReference; [k: string]: unknown }
  | { op: 'batch'; commands: Command[] };

type Reaction = {
  id: string;
  scope?: ScopeDeclaration;
  watch: DataReference[];
  when?: Expression;
  then: Command[];
};

type InteractionIntent =
  | { type: 'form.command'; command: Command }
  | { type: 'host.emit'; event: string; payload?: ValueSpec };

type MaterialNode = {
  material: string;
  props?: Record<string, ValueSpec>;
  bindings?: Record<string, DataReference>;
  slots?: Record<string, ViewNode[]>;
  on?: Record<string, InteractionIntent>;
};
type ScopeNode = { scope: ScopeBinder; node: ViewNode };
type TemplateUse = { $use: string; with?: Record<string, DataReference> };
type ViewNode = MaterialNode | ScopeNode | TemplateUse;
type ViewTemplate = {
  params?: Record<string, { schemaRef: string }>;
  node: ViewNode;
};

type FormDefinition = {
  protocolVersion: string;
  id: string;
  version: string;
  data: { schema: JsonSchema };
  expressions?: Record<string, Expression>;
  constraints?: Constraint[];
  reactions?: Reaction[];
  views: Record<string, ViewNode>;
  viewTemplates?: Record<string, ViewTemplate>;
  metadata?: Record<string, JsonValue>;
};
```

> **不要误当成可直接发布的 npm 类型**
> 
> 本附录刻意把 `array.insert` / `array.move` 的具体位置描述留作固化项，且 JsonSchema 使用抽象占位。它是已收敛语义的汇编，不是已经编译与验证的完整类型包。

## 正式 V1.0 发布前的验收与交付 {#release}

> 状态：已收敛

- [ ] 生成完整 `form-definition.types.ts`，消除占位和不严谨 Union
- [ ] 生成完整 `form-definition.schema.json`，与 TypeScript 一致
- [ ] 校验简单表单 / 动态数组 / 多端保险表单三类样例
- [ ] 反例验收：非法引用、Scope 越界、模板参数类型不匹配、端口不兼容
- [ ] 冻结 Material Manifest 版本解析约定及 Pure Function 合约
- [ ] 发布规范语义说明、版本兼容说明与变更记录

上述勾选仅供阅读时自查，不自动代表项目真实完成状态。后续阶段 L2、L3、L4 只能在遵守这份 L1 语义的前提下选择自己的实现策略。

> 最终决策：**停止 L1 的开放式抽象扩张，进入 Canonical Type / JSON Schema / 反例验收**。需要修订时提出能复现的协议冲突，而不是重新设计已确定的领域层次。
