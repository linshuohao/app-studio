# 文档维护

项目处于方案设计与规范固化阶段。L1 架构与语义已收敛；L2 静态编译、Material / Pure Function / Host 分类、平台治理与发布锁定方向已收敛。跨层依赖模型已明确读取 / 触发 / 活跃订阅分离、L2 计划 / L3 匹配 / L4 挂载的职责，External dependsOn 在现行草案统一为 watch。正式类型、Schema、精确版本规则与发布验收尚待完成；Prepared ABI、L3 执行调度和 L4 框架适配仍待设计与实现。

## 阅读与源文件

主阅读入口包括 [整体架构](reading/architecture.html)、[L1 定义协议](reading/l1-definition-protocol-v1.html)、[L2 编译与发布](reading/l2-preparation.html)、[依赖与订阅](reading/dependency-reactivity.html) 和 [协议样例](validation/index.html)，在各现行阅读页侧栏直接切换。L1 从极简表单开始，按计算与规则、重复数据、视图组合、宿主接入逐步展开，完整协议与决策依据放在后面查阅；分组和章节在同一文档的侧栏呈现，默认只展开当前阅读组，也可手动展开其他组或搜索全部章节。术语并入架构，复现与来源说明并入样例。历史材料只从 [归档入口](history/index.html) 按需追溯。

| 来源 | 职责 |
| --- | --- |
| `design/architecture.md` | 产品边界、完整分层设计、图示、取舍、交付物与详细设计路线 |
| `design/l2-preparation.md` | L2 与平台职责、Pure Function、能力契约、Host 注册、编译与不可变发布；侧栏提供直达入口，整体架构的 L2 章节也保留链接 |
| `design/dependency-reactivity.md` | 跨层读取 / 触发 / 订阅契约，依赖计划、统一观察、Scope、挂载生命周期、时序与验收；语法和编译细节同步相应 L1 / L2 主题 |
| `design/l1/01-*.md` 至 `08-*.md` | 同一份 L1 正文的八个主题；按需读取和修改 |
| `design/l1/README.md` | L1 阅读分组、场景引导与章节顺序；生成时嵌入同一协议页，不另建索引页或复制协议正文 |
| `CONTEXT.md` | 领域词汇，生成时嵌入架构文档 |
| `validation/` | 样本生成源、候选验证器、数据、报告与复现说明 |
| `history/` | 原始来源与被替代版本，不与现行正文并列生效 |

讨论某项能力时先查对应 Markdown 的标题和章节锚点，再读必要的相邻契约。完整示例、类型附录和验证数据按需加载；不为获取设计约束读取 HTML、CSS、JS 或历史稿。已形成现行正文的 L2 与跨层专题复用统一阅读外壳和侧栏导航，不新增重复索引页；后续层级设计继续归入 `design/`，实现目录在落地任务中建立。

## 维护方式 {#maintenance}

1. 修改相应 Markdown 或样本生成源，保留稳定章节锚点和已收敛 / 待固化状态；不按讨论轮次新增平行规范。
2. 示例变化时同步验证源。保险基线读取 [示例正文](design/l1/07-examples.md#sample)；其余样本来自 `validation/build_cases.py` / `extend_cases.py`。不直接修改生成的 cases、报告和阅读页。
3. 生成阅读页并检查同步；协议样例变更时另复跑验证。出现冲突，以相应主题正文为准，修正受影响的样本和说明。

首次安装依赖与日常生成，在项目根目录执行：

```bash
python3 -m pip install -r tools/docs/requirements.txt -r docs/validation/requirements.txt
python3 tools/docs/build_docs.py
python3 tools/docs/build_docs.py --check
```

协议样例变更后的验证：

```bash
python3 docs/validation/run_validation.py
```

阅读页共用 `tools/docs/reader.py`、`tools/docs/templates/document.html` 及 `docs/reading/assets/documentation.css` / `documentation.js`。`examples.css` 只补充样例布局；历史快照保留原有呈现，纯函数术语已统一，原始字节见历史来源包。仅改呈现时重新生成页面即可，无需重建协议数据。旧首页 `reading/index.html` 直接转到整体架构，不另维护一份首页正文。

L1 阅读顺序在 `design/l1/README.md` 中维护：每个带稳定锚点的二级标题是一组，段落说明使用场景，末尾列表逐项链接编号正文的章节。生成器要求每节正文恰好出现一次，保留原章节及主题锚点，避免重排时漏节、重复或破坏既有链接。新增章节时同步安排阅读位置；协议字段、类型、约束和样例仍只在编号正文维护。

架构图在 Markdown 的 `diagram` 代码块中维护节点、连接和说明数据，由 `tools/docs/diagrams.py` 生成共享风格的图形。这些数据仅用于文档呈现，不是 L1 协议字段；正文和图示中的职责、状态与演进关系需要同步维护。
