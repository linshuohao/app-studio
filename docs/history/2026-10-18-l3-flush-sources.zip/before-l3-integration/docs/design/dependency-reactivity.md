# 跨层依赖编译与响应式订阅模型

本篇将用户提供的《L1–L4 跨层依赖编译与响应式订阅模型 · 架构设计 V0.1》整合为现行跨层设计。L1 声明语义，L2 静态编译依赖，L3 统一匹配状态变化，L4 按实际挂载管理视图订阅。读取、触发与活跃订阅的分离是设计基线；接口草图、执行时机与存储结构仍待固化，不代表已经实现。

## 范围、状态与三个概念 {#dependency-baseline}

本专题连接 [L1 表达式与约束](l1/03-expression-validation.md#expression)、[L2 静态编译](l2-preparation.md#l2-dependencies) 和 [整体架构的 Runtime / Renderer](architecture.md#runtime)，解决各类消费者重复发现依赖的问题。各层完整职责、能力治理和发布机制仍在原主题维护。

| 概念 | 回答的问题 | 例子 | 所属阶段 |
| --- | --- | --- | --- |
| Read Dependency | 计算可能读取什么？ | 保费表达式读取年龄与产品 | L1 声明，L2 分析 |
| Watch Dependency | 哪些变化需要让行为响应？ | 年龄变化触发保费联动 | 按 L1 使用位置显式声明或静态推导 |
| Subscription | 哪个消费者现在正在观察？ | 已挂载输入框观察当前数组项 | L3 登记，消费者管理生命周期 |

读取不必然构成触发：按钮 Payload 读取年龄，年龄变化不应自动发出按钮事件。静态计划不等于活跃订阅：编译了一百个 View 节点，此刻可能只挂载十个。Expression 只描述计算，不独立拥有订阅生命周期。

| 状态 | 本轮处理 |
| --- | --- |
| 设计基线 | 三类概念分离；按类型递归分析；统一变化匹配；业务规则与 View 激活分离 |
| 本次草案修订 | External Constraint 的 `dependsOn` 统一为 `watch`；合并其 `when` 的可见读取依赖 |
| 结构方向 | PreparedForm 携带 Dependency Plan；按计划或明确引用建立订阅 |
| 待固化 | 正式类型 / ABI、状态引用形状、求值接口、通知时机、合并与重入、View 订阅粒度 |

## 四层分工与激活归属 {#dependency-layers}

```diagram
{
  "id":"figure-reactivity-layers",
  "title":"静态依赖统一编译，活跃订阅分别管理生命周期",
  "rows":[
    [{"title":"L1 · Definition","body":"Expression / Constraint / Reaction / View / Scope；使用位置决定触发语义"}],
    [{"title":"L2 · Preparation","body":"递归读取分析 → 使用位置解释 → Scope 解析 → Dependency Plan"}],
    [{"title":"L3 · Runtime","body":"Data / Runtime State + Reactive Engine；按来源、引用、实例匹配活跃订阅","major":true}],
    [{"title":"Runtime 消费者","body":"L3 随 Form / Scope 激活 Reaction 与 Constraint"},{"title":"View 消费者","body":"L4 随挂载、更新、卸载订阅 / 释放"},{"title":"Host 消费者","body":"Host 随业务对象生命周期观察，受控写回"}]
  ],
  "arrows":["↓","↓","↕ read / dispatch / subscribe"],
  "note":"统一的是依赖计划与观察入口；业务策略、首次执行、生命周期和调度时机仍由各消费者契约决定。L4 不重写依赖分析或匹配引擎。"
}
```

| 消费者 | 激活方与生命周期 | 变化命中后的行为 |
| --- | --- | --- |
| Reaction | L3；FormRuntime / Scope 实例 | 判断 when，按顺序执行 then Command |
| Internal Constraint | L3；FormRuntime / Scope 实例 | 重新求值适用条件和断言，维护 Issue |
| External Constraint | L3；FormRuntime / Scope 实例 | 使旧结论失效；是否请求 Host 由校验策略决定 |
| View Binding / 动态 Props | L4；实际挂载的 View 实例 | 使当前投影失效，读取最新状态并交给 UI 框架 |
| Host Observer | Host；调用方业务对象 | 执行宿主逻辑；需改数据时提交受控 Command |

L3 的基础协作角色可概括为 Data + Reactive Engine；Reaction、Validation 是具有不同语义的消费者。这个概括保留 Scope、求值、生命周期和有效性职责，不要求新增多个平级业务引擎。L4 无需代替 Runtime 手工注册业务 Constraint。

## L1 使用位置：从读取到触发 {#dependency-usage}

L1 的权威规则见 [表达式使用位置矩阵](l1/03-expression-validation.md#expression)。本专题以以下区别解释整条处理链：

| 位置 | 读取是否形成自动观察 | 语义 |
| --- | --- | --- |
| Reaction.watch | 显式触发 | 保持原有 watch，不追加 when / then 的读取 |
| Reaction.when / then ValueSpec | 否 | 命中 watch 后门控 / 执行命令时求值 |
| Internal Constraint.when + assert | 是 | 二者所有可能读取的输入均影响结果 |
| External Constraint.watch + when | 显式声明与自动读取合并 | Host 不透明输入由 watch 补充；只表示旧结果何时失效 |
| View Binding / 动态 Props | 是 | 当前值、动态禁用及物料声明的可见性投影随变化更新 |
| Material / Host 事件 Payload | 否 | 事件实际发生时求值，不因输入变化发出事件 |
| ScopeBinder.from | 结构性关系 | 维持绑定及数组实例创建、销毁、重排 |

Constraint 的 `issue.target` / external `target` 是归属位置，不能充当唯一读取依赖，也不因作为目标而自动加入 watch。External Constraint 当前没有 Payload 字段；来源稿关于“可见 Payload 输入”的合并原则只适用于将来正式引入的合法输入位置，本次不扩展协议。

命名统一不等于对象结构统一：Reaction 仍是 watch / when / then，Constraint 仍是适用条件与断言 / 外部义务，View 仍是 Binding 与 Props。`watch` 说明何种变化需要响应，不规定何时执行回调。

### 跨字段条件校验与联动示例

以下是协议片段，假设 Schema 与相应 Pure Function / Material 契约存在。沿用现有样本的内置短 ID；`core.*` Canonical 映射见 [L2 命名规则](l2-preparation.md#l2-function-identity)。

```json
{
  "expressions": {
    "isMinor": {
      "op": "lt",
      "args": [{ "ref": { "source": "data", "path": "/applicant/age" } }, 18]
    }
  },
  "reactions": [{
    "id": "recompute-premium",
    "watch": [
      { "source": "data", "path": "/applicant/age" },
      { "source": "data", "path": "/product/id" }
    ],
    "then": [{
      "op": "set",
      "target": { "source": "data", "path": "/premium" },
      "value": { "$expr": {
        "op": "insurance.calculatePremium",
        "args": [
          { "ref": { "source": "data", "path": "/applicant/age" } },
          { "ref": { "source": "data", "path": "/product/id" } }
        ]
      } }
    }]
  }],
  "constraints": [{
    "id": "guardian-required",
    "kind": "internal",
    "when": { "use": "isMinor" },
    "assert": {
      "op": "notEmpty",
      "args": [{ "ref": { "source": "data", "path": "/guardian/name" } }]
    },
    "issue": {
      "target": { "source": "data", "path": "/guardian/name" },
      "code": "GUARDIAN_REQUIRED"
    }
  }]
}
```

保费 Reaction 观察显式年龄和产品；监护人 Constraint 自动观察年龄与姓名。只修改年龄也必须重评估 Constraint：条件 false → true 时可能新增 Issue，true → false 时移除该规则实例的旧 Issue。不能因 `issue.target` 只指向姓名，就漏掉年龄的影响。

## L2 递归分析与使用位置编译 {#dependency-analysis}

输入为 Definition、确定的能力契约与目标；输出为 Prepared Expression / ValueSpec、Dependency Plan 和 Diagnostics。逻辑步骤是类型引导的读取分析、使用位置解释、Scope / 模板绑定解析、检查及打包，可共享遍历，不强制分成多个服务。

| 结构 | 分析要求 |
| --- | --- |
| Expression.ref | 校验来源、词法可见性与路径，记录读取引用 |
| Expression.use | 递归分析命名表达式；A → B → A 为编译错误；不允许捕获调用方局部 Scope |
| Expression.op + args | 递归分析全部参数；不执行 Pure Function，不分析其外部源码 |
| ValueSpec | 递归对象、数组与合法 `$expr`；`$literal` 内容是普通数据 |
| 条件 / 短路计算 | 保守合并所有可能分支的读取，不依赖当前运行值裁剪 |
| Binding / Scope / Template | 解析数据端口、结构依赖和 Typed DataReference 参数；保留 each 模式 |
| 普通 JsonValue / Schema / 原始 Payload | 不按恰好出现的 ref / $expr 属性扫描成表达式 |

例如 `and(use(isMinor), notEmpty(ref(/guardian/name)))` 读取年龄和姓名，即使运行时短路，静态读取集也覆盖二者。内部分析器可以分类为 literal / ref / use / call；这不改变 L1 的 `op + args` 语法，也不新增 conditional 节点。

分析缓存须考虑词法 Scope、模板参数绑定和编译上下文，不能仅以表达式名称跨环境复用。Pure Function 接收整个对象时，保守视为该对象子树依赖；它不应通过隐藏可变状态增加输入。Schema 能精确推导时使用局部依赖，不能精确证明的条件约束退化为对应对象 / 子树观察。

将来若支持动态路径，必须给出明确依赖契约或编译报错；不能静默遗漏。循环检测仍区分符号引用环、合法 Schema 递归和潜在 Reaction 触发环，见 [L2 环检测](l2-preparation.md#l2-dependencies)。

## 最小 Dependency Plan 与交付边界 {#dependency-plan}

Dependency Plan 是 PreparedForm 的静态产物，Observation Plan 是来源稿中的同义表述。本篇统一使用前者；计划条目可称 PreparedObservation。以下只表达信息需求，不冻结 TS 字段或 ABI：

```typescript
interface PreparedObservation {
  id: string;
  owner: { kind: 'reaction' | 'constraint' | 'view'; id: string };
  watch: PreparedDependency[];
  scope?: PreparedScopePattern;
  activation: 'runtime' | 'view-mounted';
}

interface PreparedDependency {
  source: 'data' | 'context' | 'validation' | 'field-meta';
  reference: PreparedReferencePattern;
  aspect?: 'value' | 'structure';
}
```

`source` 是运行时可观察状态类别的候选表示，**不扩展 L1 Reference.source**。数组结构是 Data 的观察方面；来源稿把 structure 列为独立来源的表示仍是候选，正式 ABI 再决定编码，不能同时把它当成第二个权威状态源。Validation / Field Meta 引用也需要 L3 契约，不能直接写进 L1 Binding。

概念上，guardian-required 的计划关联年龄和姓名、owner 为 constraint、activation 为 runtime；guardian 输入框的 disabled 计划关联年龄、owner 为 view、activation 为 view-mounted。`activation` 只说明由谁激活，不表示通知优先级，也不规定订阅后首次执行。

| 静态产物保存 | 留给运行时 |
| --- | --- |
| 引用模式、状态类别、结构观察、词法 Scope 关系 | 数组成员、实例身份、当前数据与校验结果 |
| 行为身份、Prepared 求值引用、激活归属 | 回调、组件、DOM、宿主对象 |
| View 与计划的关联 | 挂载状态、通知队列、框架优先级 |

Prepared View 可引用计划 ID，也可内嵌紧凑依赖集合；节点合并或按属性拆分是可比较的粒度方案，不建立两套语义。该信息归入既有 Form / View Plan 交付，具体打包位置和 `formatVersion` 兼容校验需随正式 Prepared 格式确定。

## Scope：静态模式、真实实例与视图实例 {#dependency-scope}

L2 知道关系模式，L3 知道真实数据实例，L4 知道实际挂载的视图实例。对 `from: /insureds, as: insured, mode: each` 的逐项约束，L2 记录 insured.age → 该项 Constraint 的模式，不展开当前数组：

```text
静态：insured(each).age → insured(each) 的 Constraint
实例：A.age → Constraint A；B.age → Constraint B；C.age → Constraint C
视图：只有挂载的 A / C 行创建自己的 View Subscription
```

| 数组操作 | 必须保持的关系 |
| --- | --- |
| 插入 | L3 新建 Scope 实例并激活业务规则；L4 若挂载新行再建立 View 订阅 |
| 删除 | L3 释放实例规则、无效订阅、校验与请求适用性关联；L4 卸载相应视图 |
| 移动 | 保留数据实例身份；订阅、Issue 和组件不能改绑为原下标的另一项 |
| 整组替换 | 身份是否复用由身份契约决定，不能默认任意替换都保留 ID |

父子路径、整对象替换、数组成员值和结构变化都应正确匹配；精确编码与相等性规则留给 L3。Scope 的词法规则和 Handle 语义仍见 [L1 Scope](l1/02-data-reference-scope.md#scope)。

## L3 读取、修改与订阅入口 {#dependency-runtime-api}

```typescript
// 职责草图；引用、Scope、返回值及快照一致性契约仍待正式定义。
interface FormRuntime {
  read(ref: RuntimeReference, scope?: RuntimeScope): unknown;
  dispatch(command: Command, scope?: RuntimeScope): MutationResult;
  subscribe(target: SubscriptionTarget, callback: () => void,
    options?: SubscribeOptions): Unsubscribe;
}
type SubscriptionTarget =
  | { planId: string; scope?: RuntimeScope }
  | { refs: RuntimeReference[]; scope?: RuntimeScope };
interface SubscribeOptions {
  flush?: 'sync' | 'deferred'; // 候选扩展位，尚无冻结语义
}
```

计划入口供 Runtime 规则与 L4 复用 L2 产物；明确引用入口供 Host、动态 UI 适配和调试器临时观察。两者共用匹配能力，不要求 Host 先新增 L1 View。返回的释放函数由消费者管理，实例销毁后不再保留无效回调。

`read(ref)` 只示意读取状态引用，不能据此宣称已解决 Prepared Expression 求值。动态 Props 必须经统一求值能力或共享适配契约获取，L4 不独立实现业务表达式。正式求值与快照 API 是后续交付。

## L3 变化匹配与不同消费语义 {#dependency-delivery}

```diagram
{
  "id":"figure-reactivity-delivery",
  "title":"变化统一匹配，消费者分别响应",
  "rows":[
    [{"title":"Command / 受控状态入口","body":"数据只能经受控命令写入；Context 与校验报告各走相应状态入口"}],
    [{"title":"Data / Runtime State","body":"记录值、父子路径、数组结构或校验状态的可观察变化"}],
    [{"title":"Reactive Engine","body":"按状态来源、引用位置及 Scope 实例匹配已激活订阅","major":true}],
    [{"title":"Reaction / Constraint","body":"联动可再次 dispatch；校验维护状态并使旧结论失效"},{"title":"View / Host","body":"接收失效信号，重新读取最新状态；UI 更新交给 L4"}]
  ],
  "arrows":["↓","↓","↓"],
  "note":"Reaction 新 Command 与校验状态变化继续进入相同观察机制，但不同状态来源隔离。匹配谁受影响与何时执行回调分开设计。"
}
```

只更新 Validation Issue 不应触发仅观察 Data 的 Reaction。Reaction 产生的新 Command 仍走统一数据入口，不能旁路写 Store。外部观察者收到的可以是“当前投影可能失效”信号，随后读取最新状态；不能由此推断业务 Reaction 也可以丢弃中间触发。

External Constraint 要分开三件事：依赖变化立即使旧结论不再可信；blur、显式 validate、submit 或未来自动策略决定是否请求 Host；结果返回时核对有效输入与 Scope 实例，过期结果不得覆盖当前状态。请求、重试和取消仍归 Host。

初始化校验、主动校验、首次 View 读取和 Reaction 是否初始化执行都有独立入口。`subscribe` 本身不隐含“注册时必然执行一次”；初始数据已违反 Constraint 也必须能被初始化 / 主动校验发现。

内部可采用路径列表、结构化变化记录或 Store 事件；只要满足匹配与有效性契约，本轮不要求新增 DataRevision、ChangeSet、Scheduler、ExecutionCycle 等专门对象。

## L4 方案选择与挂载生命周期 {#dependency-view}

| 方案 | 收益 | 代价与结论 |
| --- | --- | --- |
| L3 初始化时预注册全部 View | 表面上统一激活 | 隐藏和虚拟列表节点承担无效成本；不作默认方案 |
| L4 自行解析 AST 并监听 Data | 框架可自主组织 | 重复 L2 分析，跨端语义容易漂移；不采用 |
| L2 编译 + L4 挂载订阅 | 静态语义统一，按需激活 | 要求稳定 L3 订阅 / 读取契约；本次采用的方向 |

例：insured 项的 Input Binding 读取 guardianName，动态 disabled 读取 age。L2 为其准备两条关系；L4 挂载时用当前 Scope 激活计划，随后经共享求值入口刷新。按节点合并或按 Binding / Props 拆分仍待测量。

```json
{
  "scope": {
    "from": { "source": "data", "path": "/insureds" },
    "as": "insured",
    "mode": "each"
  },
  "node": {
    "material": "text-input",
    "bindings": {
      "value": { "source": "data", "scope": "insured", "path": "/guardianName" }
    },
    "props": {
      "disabled": { "$expr": {
        "op": "gte",
        "args": [{ "ref": { "source": "data", "scope": "insured", "path": "/age" } }, 18]
      } }
    }
  }
}
```

片段假设数组项字段及 text-input 的 disabled 契约已声明；它只展示 Scope / Binding / Props，业务 Constraint 仍在 Form 层独立声明。

```typescript
// 生命周期示意，不是可直接替代框架 Store Adapter 的实现。
function mountPreparedView(runtime, node, scope) {
  const unsubscribe = runtime.subscribe(
    { planId: node.observationPlanId, scope },
    () => invalidateNode(node.id)
  );
  refreshNodeFromRuntime(node, scope);
  return () => unsubscribe();
}
```

| 阶段 | 责任 |
| --- | --- |
| Mount | 绑定真实 Scope，订阅当前计划，取得最新快照 / 求值结果 |
| Update | 普通变化按框架协议重读；节点、计划或 Scope 改绑时释放旧订阅并建立新关系 |
| Unmount | 释放 View 订阅与局部 UI 资源；不删除数据或共享业务规则 |

正式 React / Vue / Flutter 适配器需满足各自的一致性要求，防止订阅与首次读取之间、改绑交接期间发生变化而漏更新。示意代码的调用顺序不构成框架快照一致性保证。

条件渲染时，决定子树是否出现的父级条件观察者必须存活；子组件尚未挂载时由父级 / 容器持有它，否则条件变 true 也无人创建子视图。这里的可见性使用合法动态 Props 或容器契约，不新增通用 `visibility` 协议字段。

虚拟列表只为可见行建立 View 订阅，未挂载行的业务 Reaction / Constraint 仍由 L3 激活。切换 Profile 只更换 View 订阅和局部状态；PC / Mobile 若共享同一 FormRuntime，就共享业务数据与规则，不能随 View 切换反复创建或销毁校验义务。Focus、Hover、展开、动画、布局和局部缓存归 L4，业务值与 Issues 归 L3。

## 执行时机与本轮未决项 {#dependency-scheduling}

| 维度 | 需要比较 | 当前边界 |
| --- | --- | --- |
| 回调时机 | 当前调用内 sync / 后续批次 deferred | 消费语义可不同；重入、异常和可见状态需明确 |
| 交付模式 | 每次变化 / 合并为最新状态 | Renderer 可读取最新；Reaction 不默认丢触发 |
| View 粒度 | 按 Node / Binding / 属性拆分 | 共享静态语义，性能测量后决定 |
| 变化记录 | 路径列表 / 结构化记录 / Store 内部事件 | 先验收来源、路径与实例匹配 |
| 求值接口 | Prepared Expression 的值与快照如何读取 | 统一能力；正式 API 待设计 |
| 外部校验 | 失效后立即请求 / 按策略请求 | 本轮只确定失效与请求分离 |

Reaction 的 Command 同步、受控、有序，不意味着本轮已决定所有订阅回调必须在 dispatch 当前调用栈内完成。两次触发分别 `array.insert`，若合并成一次就改变业务效果；不能照搬 UI 通知合并。sync / deferred 也不保证浏览器何时绘制，耗时同步纯函数仍可能阻塞执行线程。

原架构事务图保留为失败边界、稳定发布与回滚的设计议题，不用它提前冻结“全部规则结算后只通知一次”等调度算法。事务原子性、初始 Reaction 策略、同值写入、通知次数、跨消费者顺序和销毁时待交付回调的处理仍需下一阶段契约。

## 贯穿四层的交互与验收 {#dependency-acceptance}

场景：年龄从 20 改成 16，监护人姓名为空，监护人子视图尚未显示，年龄同时参与保费联动。

| 逻辑事件 | 层级与结果 |
| --- | --- |
| 定义与编译 | L1 声明 isMinor、保费 Reaction、姓名 Constraint 与动态 View；L2 编译相关计划 |
| 实例初始化 | L3 建立 Working Data、Scope 与业务规则观察，并通过明确入口处理初始校验 |
| 初始挂载 | L4 挂载年龄 Input 与父条件观察者；监护人子节点尚无订阅 |
| 修改年龄 | L4 经 Binding 提交 set；L3 更新 Data，匹配活跃观察者 |
| 业务响应 | Reaction 按契约重算保费并可产生新 Command；Constraint 发现姓名为空，维护 Issue |
| 条件与子视图 | 父观察者重读条件、挂载监护人区域；子 Input 绑定 Scope 并建立自己的订阅 |
| 校验展示 | 已挂载视图观察对应 Validation State，显示当前错误 |

表格表达必须发生的逻辑事件，不冻结 Reaction、Constraint 与 UI 通知之间的精确同步先后。原稿的逐步演示归并为这张时序表，沿用项目统一阅读样式。

| 验收场景 | 必须证明 | 层级 |
| --- | --- | --- |
| 深层 ValueSpec / 嵌套 Expression / Named use | 收集全部合法的可能读取；Literal 不被误识别 | L1 / L2 |
| Named Expression A → B → A | 编译错误，不进入运行时 | L2 |
| Reaction.when 读 watch 外字段 | 单独修改它不触发 Reaction | L1 / L2 / L3 |
| Constraint.when 读 age，assert 读 name | 任一变化均可重评估；条件不适用时旧 Issue 清除 | L1 / L2 / L3 |
| Issue 目标与读取字段不同 | 目标只管定位，不漏掉真正输入 | L1 / L2 |
| External 隐藏 Host 输入 | 显式 watch 补充；变化失效但不隐含请求 | L1 / L3 |
| Event Payload 读 age | age 变化不发出事件 | L1 / L2 / L3 |
| View 未挂载 / 虚拟列表 / Profile 切换 | 没有多余 View 订阅，业务规则仍有效 | L3 / L4 |
| 父级条件变化 | 能创建此前未挂载的子视图 | L2 / L4 |
| 数组插入、删除、移动、替换 | 实例订阅不串项；删除后报告失效；替换遵守身份契约 | L2 / L3 / L4 |
| 父子路径与整对象替换 | 精确字段、父引用与数组结构都正确受影响 | L3 |
| 只改变 Validation Issue | 只观察 Data 的 Reaction 不重跑，错误展示更新 | L3 / L4 |
| 初始数据已违反 Constraint | 初始化 / 主动校验可发现，不依赖首次修改 | L3 |
| 高速输入与多次 insert 触发 | 无明示语义时不丢失业务动作次数 | L3 |
| 挂载 / 改绑期间发生变化 | 当前视图读取最新状态且不残留旧订阅 | L3 / L4 |
| Unmount / Form 销毁 | 后续变化不调用已释放视图；共享规则按自身生命周期清理 | L3 / L4 |

以上是设计验收集。现有候选结构验证与有界抽测不实现 Dependency Plan、真实订阅或框架适配，不能将其通过计数当作这些跨层行为已验收。

## 影响、决策与后续交付 {#dependency-decisions}

| 编号 | 议题 | 本轮结论与状态 |
| --- | --- | --- |
| D01 | Read / Watch / Subscription | 三者分离；设计基线 |
| D02 | dependsOn → watch | 本次采纳到现行 L1 草案与样本；正式协议版本 / 迁移规则待固化 |
| D03 | Internal Constraint | when + assert 自动推导；设计基线 |
| D04 | Reaction.watch | 显式触发不扩展；保持原语义 |
| D05 | L2 分析 | 类型引导递归、保守覆盖；设计基线 |
| D06 | Prepared Dependency Plan | 本次采用的结构方向；存储与 ABI 未冻结 |
| D07 | Runtime 统一观察 | 规则与 View 共用匹配；设计基线 |
| D08 | View 激活 | L4 通过 L3 API 挂载 / 释放；设计基线 |
| D09 | flush sync / deferred | 候选字段，执行语义未决 |
| D10 | View 粒度 | Node 合并或属性拆分未决 |
| D11 | 底层变化结构 | 内部表示未决 |
| D12 | 每次触发 / 最新状态 | 合并、去重和业务交付语义未决 |
| D13 | 对外求值入口 | Prepared Expression 与快照契约待固化 |

本次改动集中在 L1 使用位置与命名、L2 递归分析和静态计划、L3 统一匹配与激活、L4 挂载生命周期。无需重写 Expression DSL / Command，也不让 L2 执行纯函数、实例化数组或建立真实订阅。

旧 `dependsOn` 的确定迁移为 External Constraint 同位置的 `watch`，引用值保持不变；不自动扩展 Reaction.watch。历史原件保留旧字段；现行草案和候选样本只接受新字段，不静默兼容双字段。若已有正式发布数据，迁移必须识别旧 Protocol Version，校验后输出新版本并记录来源，不能在原版本下悄悄换名。项目当前尚无已发布正式协议版本，本次不虚构新版本号。新增计划改变 Prepared 交付时，也必须更新格式版本和兼容检查。

后续顺序：先按 L1 位置矩阵检查语义，再用跨字段 Constraint、嵌套 Expression 与 scoped View 验证最小计划；随后打通 L4 挂载、父条件与卸载；最后比较 L3 变化表示、交付时机、重入及合并。实际类型、Schema、编译器和运行时实现按任务另行落地。

原始附件的 23 节按概念、各层职责、时序、验收与决策整合至本篇和对应主题；术语并入整体架构的词汇表。原始字节和整合前正文见 [来源归档](../history/README.md#dependency-integration)。本篇是跨层契约，L1 语法和 L3 完整执行规范仍分别维护，不以草图替代正式发布包。
