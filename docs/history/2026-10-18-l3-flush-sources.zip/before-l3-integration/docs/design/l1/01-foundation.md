# 协议基础与核心决策

> L1 V1.0 架构与语义决策正文；正式类型、Schema 与发布验收状态见各节。

## 定稿结论与阅读说明 {#summary}

> 状态：已收敛

> L1 的架构模型可以定稿；本文件是 **架构与语义决策定稿**，并非已通过机器校验的最终 JSON Schema 发布包。

这份文档整合此前六组专题及后续统一收敛讨论，以**最终有效决策**为准。阅读页从极简表单逐步展开能力，再提供完整协议、业务组合与决策依据的查阅。历史示例中与最终方案冲突的字段（例如 `view.present`、`bind` 作为 Canonical、独立 `fragments`）均不再视为当前规范。

**定位**

面向复杂 C 端业务表单的**声明式 Definition Protocol**，不建设通用应用 DSL。

**已定方向**

Data / Reference / Scope / Expression / Constraint / Command / Reaction / View / Material / Host 边界。

**发布状态**

**架构已冻结**；2026.10.17 跨层模型进一步明确读取 / 触发 / 订阅分工，并将 External dependsOn 修订为 watch，迁移与正式版本规则待固化。TS 类型、JSON Schema、兼容规则和机器化验收仍属于协议固化工作。

**阅读方法**

初次阅读从「极简表单」开始，按阅读页侧栏逐步展开能力；核对协议时查「顶层结构」「总决策表」和「完整保险示例」，了解方案取舍时再查「修订史」。

> **规范声明级别**
> 
> **已冻结**：架构或语义已经有明确共识。**待固化**：方向明确，但特定类型形状、静态检查算法或字面量语法仍应由正式 TS/JSON Schema 对齐。示例中的字段名以本文 V1 候选 Canonical 为准；不能将“架构定稿”误读为所有细节已通过校验。

## 设计目标、边界与硬约束 {#principles}

> 状态：已收敛

- **唯一业务数据源：**一个 Form Instance 只有一份权威 Working Data；视图复用不复制业务数据。
- **跨端共享业务语义：**Data / Rules 不依赖 Web、Flutter、Modal 或 Drawer。
- **协议只承载稳定语义：**复杂视觉与内部交互交由 Material，外部请求与业务流程交由 Host。
- **可静态分析：**引用、表达式和指令受到约束；不接受任意 JS 函数、动态路径拼接和通用工作流。
- **默认使用成本低：**简单表单只应需要 Schema + Material View + Binding；复杂场景按需引入 Scope、Reaction、Template。

| L1 应表达 | 不属于 L1 Definition |
| --- | --- |
| 数据形状、字段引用、作用域 | 数据存储结构、字段状态机具体实现 |
| 纯表达式、约束、同步联动、受控指令 | 求值调度、事务与通知算法 |
| 物料结构、端口绑定与语义事件映射 | DOM、Portal、焦点、滚动、局部 UI State |
| 外部校验义务 | 实际 API、网络请求、重试、提交流程 |

## 四层架构与外部契约 {#architecture}

> 状态：已收敛

| 层级 / 外部契约 | 职责 |
| --- | --- |
| L1 · **Definition** | Schema · Reference · Scope · Expression · Constraint · Reaction · View |
| L2 · **Preparation** | 规范化 · 静态检查 · 递归读取 / 触发分析 · Dependency Plan · Profile 准备 |
| L3 · **Form Runtime** | 唯一 Working Data · 统一变化匹配 / 订阅 · Command · Reaction · Validation · Field State |
| L4 · **Renderer & Material Adapter** | UI 树 · Material 实例 · Binding 连接 · 挂载 / 改绑 / 释放订阅 · 局部交互状态 |
| **Material Registry** | Props / Bindings / Slots / Events 契约与实现 |
| **Host** | 初始化 / 外部校验 / 业务事件 / 提交 |

Material Registry 和 Host 是外部能力边界，不是要往 `FormDefinition` 顶层增加 `services` 或 `resources`。L1 可以声明需要哪些能力，但不需要把实现细节写进业务配置。

## 核心决策总表 {#decisions}

> 状态：已收敛

| 编号 | 模块 | 最终决定 | 说明 |
| --- | --- | --- | --- |
| D1 | Data | **JSON Schema + 唯一 Working Data** | 允许临时不合法值；Normalized Output 单独校验 |
| D2 | Reference | **结构化 Reference** | 根路径字符串是 Authoring 简写 |
| D3 | Scope | **局部 ScopeBinder · one / each** | 无全局 Scope Registry；数组项身份统一管理 |
| D4 | Expression | **纯 AST + 递归 $expr** | 动态 JSON 值由显式包装识别 |
| D5 | Constraint | **Internal / External** | 内部 when + assert 推导；外部 watch 合并 when，声明失效义务，不编排请求 |
| D6 | Command | **有限数据修改集合** | 不等于任意 Action 脚本 |
| D7 | Reaction | **watch / when / then** | 仅内部同步数据联动 |
| D8 | View | **Material / Scope / TemplateUse** | 每个 Profile 直接对应 ViewNode |
| D9 | Binding | **Canonical: bindings 端口映射** | 不增加 read/write/validationBind |
| D10 | Slots | **Canonical: slots** | children 是默认 Slot 简写 |
| D11 | Template | **Typed Data Params** | schemaRef 复用 Data Schema；with 传 Data Reference |
| D12 | Interaction | **form.command / host.emit** | view.present/dismiss 不进入核心 |
| D13 | Material | **物料自有能力限制由 Manifest 定义** | 协议统一机制，Manifest 定义具体端口和类型 |
| D14 | Host | **外部业务能力不内嵌** | 网络、上传、提交都在 Host / 自定义物料服务中 |
| D15 | Lifecycle | **初始化 / 更新 / 重初始化 / Reset 区分** | 属于宿主-运行时 API 语义，不定义生命周期脚本 |
| D16 | 跨层依赖 | **Read / Watch / Subscription 分离** | L2 编译，L3 匹配，L4 按挂载订阅；调度 / ABI 仍待固化 |

## 唯一 FormDefinition 顶层结构 {#top-level}

> 状态：已收敛

**架构定稿 · 顶层字段**

```typescript
interface FormDefinition {
  protocolVersion: string;
  id: string;
  version: string;

  data: { schema: JsonSchema };
  expressions?: Record<string, Expression>;
  constraints?: Constraint[];
  reactions?: Reaction[];
  views: Record<string, ViewNode>;
  viewTemplates?: Record<string, ViewTemplate>;
  metadata?: Record<string, JsonValue>;
}
```

文档展示将 `protocolVersion`、`id`、`version` 与 `metadata` 合并为“定义信息”。这只是阅读分组，不新增 basicInfo 字段；这些字段仍处于 FormDefinition 顶层，metadata 仍只承载非执行性元数据。

业务规则处于 Form Definition 级别，不能因为切换 View Profile 或某字段暂时隐藏就失效。`metadata` 只用于非执行性元数据，不能通过它绕过已确定的协议语义。

> **明确不增加的顶层域**
> 
> `actions`、`behaviors`、`resources`、`services`、`submissionWorkflow`、`presentation`、`validationState`、`scopes` 不进入 V1 核心。

## Canonical、Authoring、Prepared 的分离 {#representations}

> 状态：已收敛

| 形式 | 定位 | 示例 |
| --- | --- | --- |
| Canonical Protocol | 唯一正式结构：机器验收与交换 | `bindings.value = {source:"data",path:"/name"}` |
| Authoring Syntax | 可选的书写简化，不扩展语义 | `bind: "/name"`；`children: [...]` |
| Prepared Representation | L2 内部交付产物，非 L1 文档的一部分 | 已解析引用、编译依赖、索引及 Profile 选择 |

遵循“一种语义，一种 Canonical 形式”。有简写也不能把简写当成第二套协议。跨端传递、规范校验和文档样例均应优先使用 Canonical。
