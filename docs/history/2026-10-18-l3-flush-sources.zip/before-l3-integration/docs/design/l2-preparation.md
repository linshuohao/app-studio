# L2 Preparation：平台能力治理与编译发布

L2 是平台的静态协议编译能力。平台管理资产与发布，L2 编译声明式 Definition，Runtime 执行准备后的计划，Host 在实际应用中注入副作用能力。本篇整合 2026.10.17 的 L2 决策归档；设计基线已经收敛，接口草图不等于正式类型、Schema 或生产实现。

## 设计基线、范围与状态 {#l2-status}

| 状态 | 内容 | 使用方式 |
| --- | --- | --- |
| 已收敛 | Material / Pure Function / Host 三类职责；复杂同步校验复用纯函数；L2 静态编译；能力 Manifest 与发布锁定 | 后续设计基线 |
| 已收敛 | 内置与注册纯函数共用调用协议，`core.*` 为保留命名空间；Host 运行时注册，静态契约可选 | 不再另建校验函数 DSL 或通用业务执行器 |
| 结构方向已收敛 | PreparedForm、Diagnostics、能力依赖与 Host Requirements；推荐 Form Plan + View Plan 与可序列化交付 | 正式 TS / JSON 字段、兼容规则仍需固化 |
| 跨层设计基线 | Read / Watch / Subscription 分离；按使用位置编译 Dependency Plan；L3 统一匹配，L4 按挂载激活视图 | 计划是静态描述，不是已建立的观察者；完整接口与调度未冻结 |
| 待固化 | 调用字段迁移、Host 缺失等级、Manifest 最小字段、摘要覆盖对象、Prepared Format / ABI 兼容规则 | 保留明确判定问题，不能标为已冻结 |

此次统一术语为 **Pure Function（纯函数）**，候选契约相应使用 `PureFunctionManifest` 等名称。L1 表达式调用节点目前保留 `op + args`；名称统一不自动构成协议字段迁移。原来源中较宽泛的 Function 分类在现行正文中均明确为 Pure Function。

本篇覆盖 L2 与平台的交界、能力分类、编译输入输出、注册、版本化、依赖分析及发布验收。Working Data 状态机与 Reaction 事务属于 L3，Material DOM 和组件生命周期属于 L4。[整体架构](architecture.md#preparation) 保留各层完整设计；L1 语义以 [定义协议](l1/README.md) 为准。

[跨层依赖编译与订阅模型](dependency-reactivity.md) 补齐本层到 L3/L4 的消费契约；本篇继续维护编译与发布职责，不因统一观察机制接管真实订阅、实例状态或 UI 调度。

## 平台、编译器和运行时的职责 {#l2-platform}

```diagram
{
  "id":"figure-l2-platform",
  "title":"平台治理、静态编译与运行时绑定",
  "rows":[
    [{"title":"Form Registry","body":"Definition、草稿、版本、发布审批"},{"title":"Capability Registry","body":"Material / Pure Function 的 Manifest、制品索引与版本"}],
    [{"title":"Release 构建上下文","body":"Definition + 确定 Catalog Snapshot + Build Target + 目标格式要求"}],
    [{"title":"L2 Protocol Compiler","body":"Validate / Analyze / Transform / Package","major":true}],
    [{"title":"Release Management / Artifact Distribution","body":"登记 PreparedForm、Capability Lock、Host Requirements；摘要、审核、发布、回滚与分发"}],
    [{"title":"L3 Runtime + L4 Renderer","body":"加载与能力预检查、工作数据、规则执行、字段状态、物料实例"},{"title":"Host Runtime","body":"validators / events / services 在应用运行时注册"}]
  ],
  "arrows":["↓","↓","↓","↓"],
  "note":"Form Registry 管表单资产，Capability Registry 管能力资产，Compiler 管静态转换，Release Management 管不可变发布。执行代码在运行时绑定，Host 代码不强制进入平台注册。"
}
```

L2 消费确定的契约快照，不负责代码托管、CI 构建、权限审批、制品下载分发或发布环境管理。平台注册提升复用、治理与追踪能力，但不是 L2 能工作的前提：应用本地导出的确定 Material / Pure Function 契约同样可以作为输入。

## L2 的边界与调用时机 {#l2-boundary}

| L2 负责 | 交由其他职责负责 |
| --- | --- |
| 结构和 Canonical 语法检查、Authoring 简写规范化 | L3 修改 Working Data、初始化、恢复草稿 |
| Reference、ScopeBinder、Template 参数静态解析 | L3 管理真实数组项身份与实例状态 |
| Material、Pure Function、已知 Host 契约兼容检查 | L3 求值纯函数，Host 执行业务请求 |
| Expression / Constraint / Reaction 依赖与潜在环分析 | L3 事务、重入、实际级联与防环 |
| Form / View Plan、索引、Diagnostics | L4 组件实例、弹窗、焦点、动画 |
| 平台 / Profile 产物和运行时需求声明 | 平台代码构建、注册、分发与部署治理 |

L2 不读取某个实例的具体 Working Data，不执行业务纯函数，不实例化真实数组项，也不请求外部服务。这里的编译可以在发布期 AOT、服务端按需或客户端加载时发生；生产优先预编译与缓存，编辑器、预览和离线场景可以按需调用同一编译能力。

同一 Definition、目标环境、已锁定契约和 Compiler 版本应产生语义等价、可复现的产物。目标或契约变化后必须重检 / 重编，不能无条件复用旧缓存。

## 能力分类与复杂同步校验 {#l2-pure-functions}

| 能力 | 类别 | 边界 |
| --- | --- | --- |
| Input、Select、Modal、Drawer、业务卡片、复合编辑器 | Material | UI 展示与交互，通过 Binding / Slot 组合 |
| 算术、日期差、年龄判断、证件校验、纯保费计算 | Pure Function | 同步、确定性输入输出，无 I/O 和写入副作用 |
| 用户名唯一性、远程承保资格 | Host Validator | 依赖外部系统，按外部义务报告结果 |
| 远程价格重算、订单提交、埋点 | Host Event Handler | 业务流程与副作用 |
| 上传、地址检索、远程选项查询 | Host Service | Material 管 UI，Host 注入网络服务 |

Host 可以分为 validators / events / services，但不因此新增通用 Action、Workflow 或异步计算扩展类别。纯计算价格属于 Pure Function；远程重算价格属于 Host。依赖网络、当前时间或外部可变状态的实现不满足纯函数要求；所需日期、地区与策略应作为显式输入。

复杂同步逻辑可以封装在版本化纯函数代码中，由 AST 表达一次调用，无需将算法展开成庞大 AST，也无需建立第二套同步 Validator 注册体系。

```json
{
  "id": "validate-identity",
  "kind": "internal",
  "assert": {
    "op": "insurance.validateIdentity",
    "args": [
      { "ref": { "source": "data", "path": "/applicant/idNumber" } },
      { "ref": { "source": "data", "path": "/applicant/birthDate" } }
    ]
  },
  "issue": {
    "target": { "source": "data", "path": "/applicant/idNumber" },
    "code": "INVALID_IDENTITY"
  }
}
```

```typescript
export function validateIdentity(idNumber: string, birthDate: string): boolean {
  return checkIdentity(idNumber) && matchesBirthDate(idNumber, birthDate);
}
```

以上是结构示意，假设字段与能力契约已注册。Pure Function 只处理传入值，不捕获调用方 Scope，不管理校验状态；Constraint 决定适用条件、Issue 目标与错误码。L1 V1 内部 `assert` 返回 boolean。一次动态返回多条 Issue 需要另行评估 Constraint 返回契约；联网属于 Host Validator，修改数据属于 Command。

## 纯函数 ID、内置能力与调用协议 {#l2-function-identity}

| Pure Function ID | 来源 | 管理形式 |
| --- | --- | --- |
| `core.eq`、`core.gte`、`core.mul` | Core Built-in | SDK 内置 Pure Function Set 与稳定 Catalog |
| `insurance.validateIdentity` | Registered | 版本化 Manifest 与制品 |
| `insurance.calculatePremium` | Registered | 同上，并需跨端契约测试 |
| `travel.checkDateRange` | Registered | 同上 |

内置与注册纯函数共用同一 Expression AST 和调用协议，来源只是 Catalog 属性。`core.*` 保留给内置能力，业务能力使用稳定命名空间；任一 ID 在确定编译上下文中只能解析为一个契约，禁止覆盖、自动搜索或静默回退。

```json
{
  "op": "core.gte",
  "args": [{ "ref": { "source": "data", "path": "/age" } }, 18]
}
```

`eq`、`and` 等短 ID 仅能作为明确列出的内置 Authoring 别名，目标 Canonical 解析为完整 ID。现有 L1 草案和验证样本仍保留短 ID；别名白名单、规范化映射及样本迁移需随正式内置契约固化，不把候选验证器当成已实现的解析器。此次术语统一不顺带迁移这些 ID，也不改变 `op` 字段。

L2 解析 PureFunctionManifest、签名和依赖版本；L3 按已锁定依赖绑定实现。V1 不因此引入参数化 Named Expression 语言或任意脚本。

## Manifest、能力来源与代码治理 {#l2-manifests}

Manifest 是可供静态检查的契约，不是可执行实现。三类能力均需要约定接口，但不要求三类代码都进入同一个平台仓库。以下名称与字段是候选接口草图：

```typescript
type CapabilityCatalog = {
  materials: Record<string, MaterialManifest>;
  pureFunctions: Record<string, PureFunctionManifest>;
  host?: HostContract;
};

type PureFunctionManifest = {
  id: string;
  version: string;
  parameters: TypeSignature[];
  returns: TypeSignature;
  // 同步、确定性、无副作用是类别的强制契约。
};
```

MaterialManifest 沿用 `propsSchema / bindings / slots / events`。同一语义版本的不同端实现保持端口契约一致。HostContract 可以由宿主维护或构建时导出，用于增强静态检查；不强制把 Host 代码发布到平台。

| 来源 | 源码 | 契约获取 | 执行代码获取 |
| --- | --- | --- | --- |
| Core Built-in | Runtime SDK | 内置 Pure Function Set Manifest / Catalog | 随 SDK 安装 |
| 应用本地注册 | 宿主 / 业务仓库 | 类型化声明或 JSON 导出 | 随应用包构建 |
| 平台发布能力 | Git 仓库 | Registry 中的版本化 Manifest | 包仓库 / 对象存储中的不可变制品 |

源码由 Git 管理，CI 构建和测试，制品仓库存构建产物，平台数据库记录元数据、Manifest、制品地址、摘要、发布状态与权限。不默认在数据库中保存任意 JavaScript 字符串并在客户端 eval。

Manifest 可检查签名与目标端可用性，不能自动证明实现没有副作用，也不能证明物料遵守事件语义；仍需代码审查、契约测试、执行环境限制与必要的运行时防护。不可信第三方扩展另需可信来源、完整性校验、签名 / 审核及隔离 / 权限策略。

## Host 运行时注册与依赖要求 {#l2-host}

宿主在应用运行时提供实现；L2 提取静态需求，获得 HostContract 时再检查名称与签名。缺少静态声明不能被当成实现必然不存在。

```typescript
interface FormHost {
  validators?: Record<string, HostValidator>;
  events?: Record<string, HostEventHandler>;
  services?: Record<string, HostService>;
}

createFormRuntime({
  preparedForm,
  host: {
    validators: { 'insurance.eligibility': checkEligibility },
    events: {
      'quote.recalculate': recalculateQuote,
      'insurance.submit': submitInsurance
    }
  }
});
```

L2 从 External Constraint、`host.emit` 与 Material Manifest 声明的服务依赖提取 Host Requirements。以下为交付摘要示意，不是 L1 新顶层字段，也不冻结 Host 注册 API：

```json
{
  "hostRequirements": {
    "validators": [{ "id": "insurance.eligibility", "requiredForSubmit": true }],
    "events": [{ "id": "quote.recalculate" }]
  }
}
```

| 场景 | 编译期 | 运行时 |
| --- | --- | --- |
| 有 HostContract | 检查名称、参数与事件 Payload | 核对已注册、兼容且按约执行 |
| 无 HostContract | 生成明确 Requirements，报告不能证明的兼容性 | 按 Host API 检查存在性及请求 / 响应形态 |
| 必需外部 Validator 未就绪 | 记录提交阻塞要求 | 不得绕过义务直接 Ready / Submit |
| 可选埋点缺失 | 记录可选依赖，可选性规则待固化 | 依声明策略跳过并记录诊断 |

`requiredForSubmit` 已有 L1 语义；一般 Host Event 缺失是阻断初始化还是调用时报错、如何重试和分级，仍需统一。不能承诺所有 Handler 缺失行为相同。

Material 内部动态使用且从未声明的 Host Service 无法被 L2 发现。发布规范需要求声明可观察服务需求；未声明依赖如何禁止发布或由运行时检测报告，仍待固化。

## 两条构建链与发布锁定 {#l2-release}

```diagram
{
  "id":"figure-l2-release",
  "title":"代码构建与 Definition 编译分别进行，Form Release 汇聚结果",
  "rows":[
    [{"title":"能力代码流水线","body":"TS / React / Vue / Dart → Build + Test → 平台 Package + Manifest"},{"title":"Definition 流水线","body":"L1 JSON + 确定 Catalog Snapshot → L2 Compile → PreparedForm"}],
    [{"title":"Form Release","body":"Definition、Prepared Artifact、Material / Pure Function Lock、Host Requirements、目标平台 / Profile","major":true}],
    [{"title":"运行时交付","body":"按锁定制品加载与预检查；保留版本和摘要追踪；回滚到旧 Release Artifact"}]
  ],
  "arrows":["↓","↓"],
  "note":"同一能力 ID / 版本保证语义和契约一致，不要求 Web Bundle 与 Flutter 二进制形式一致；纯函数尤其需要共同的输入输出测试向量。"
}
```

L1 可以声明不带版本的逻辑能力 ID，不要求每个 ViewNode 手写依赖版本。Release 构建在指定 Catalog Snapshot、目标平台 / Profile 下选择唯一版本与制品，L2 接收确定快照并保留解析结果；版本选择和锁定应在正式编译前确定，Release Manager 负责不可变登记与分发。

```json
{
  "form": { "id": "insurance-application", "version": "3.2.0" },
  "target": { "platform": "web", "profile": "mobile" },
  "protocolVersion": "1.0",
  "preparedFormatVersion": "1.0",
  "compilerVersion": "0.6.3",
  "capabilityLock": {
    "corePureFunctionSet": "1.0.0",
    "materials": {
      "text-input": { "version": "2.1.0", "digest": "sha256:<artifact-digest>" },
      "insurance-card": { "version": "3.0.2", "digest": "sha256:<artifact-digest>" }
    },
    "pureFunctions": {
      "insurance.validateIdentity": {
        "version": "1.2.0", "digest": "sha256:<artifact-digest>"
      }
    }
  }
}
```

以上字段、版本及摘要均为示意。真实发布还需明确摘要标识 Manifest、执行制品还是完整 Bundle；内置函数集也需关联可核对的不可变 SDK / 制品身份。

能力升级不能自动改变已发布表单；回滚读取旧 Release Artifact，不能根据当前最新 Catalog 重新组装。静态可发现的 Port 移除、参数类型变化触发重新检查 / 编译；运行时代码语义兼容性还依赖版本策略、契约测试和灰度验证。`latest` 或 `^1.2.0` 单独不足以复现旧发布。

## 版本维度与兼容性 {#l2-versions}

| 版本 | 含义 | 例子 | 独立原因 |
| --- | --- | --- | --- |
| protocolVersion | L1 Definition 语法与语义 | 1.0 | 表单声明格式演进 |
| definitionVersion | 某张业务表单配置版本 | 3.2.0 | 内容独立修订 |
| compilerVersion | L2 实现版本 | 0.6.3 | 构建追踪、缓存失效 |
| preparedFormatVersion | Prepared Artifact 读取契约 / ABI | 1.0 | L3 / L4 可独立升级 |
| capabilityVersion | Material / Pure Function 语义与代码契约 | 2.3.0 | 能力单独发布与回滚 |
| Host Integration API Version | 宿主接入 SDK 契约 | 待固化 | 不强制每个业务 Handler 进入平台注册 |

版本号之外还需不可变制品摘要；Runtime 初始化时核对目标格式、所需能力及锁定实现，拒绝不兼容产物。Prepared Format 的兼容矩阵、升级策略和消费端 feature 标识尚未冻结。

## 编译输入、输出与四项核心工作 {#l2-compile}

以下 TypeScript 是工程契约方向，引用的类型仍待正式定义，字段名不作为最终对外 API：

```typescript
interface CompileInput {
  definition: FormDefinition;
  target: { platform: 'web' | 'flutter' | string; profile: string };
  contracts: {
    materials: MaterialCatalogSnapshot;
    pureFunctions: PureFunctionCatalogSnapshot;
    host?: HostContract;
  };
  preparedTarget: RuntimeFormatRequirement;
}

interface CompileResult {
  preparedForm?: PreparedForm;
  diagnostics: Diagnostic[];
}

interface PreparedForm {
  formatVersion: string;
  identity: {
    definitionId: string;
    definitionVersion: string;
    profile: string;
    platform: string;
  };
  formPlan: PreparedFormPlan;
  viewPlan: PreparedViewPlan;
  dependencyPlan: PreparedDependencyPlan; // 概念关联；打包位置与字段仍待 ABI 固化
  capabilityLock: CapabilityLock;
  hostRequirements: HostRequirements;
}
```

| 工作 | 内容 | 产物 |
| --- | --- | --- |
| Validate | L1 结构、Reference / Scope、Expression 签名、Material / Pure Function Contract、可选 HostContract | Diagnostics 与类型检查结论 |
| Analyze | 递归读取分析、按使用位置解释 watch、write / use / scope 关系、静态循环 | Typed Dependency Graph、风险告警 |
| Transform | 消除 Authoring 简写、解析符号、保留 Scope 模式、形成静态观察关系 | Form Plan、View Plan、Dependency Plan、已解析引用 |
| Package | 选择 Profile 与必要 Template 依赖，保留共享业务规则，携带能力锁和 Host 需求 | Prepared Artifact |

四项是逻辑职责，不要求四个服务或多套中间 AST；解析、检查与依赖构建可以共享遍历。Prepared Artifact 应可序列化，不将 JS 闭包、实例数据、当前 Issues 或请求状态放入交付格式。L2 准备纯函数引用与索引，不执行 Expression / Command / Reaction。

Diagnostic 至少包含源位置、代码、严重程度与可读原因；“静态无法证明兼容”与“明确类型错误”必须区分。内容、编译器、目标和锁定依赖共同决定缓存身份；准备产物可被多个实例安全复用。

## 有类型的依赖关系与环检测 {#l2-dependencies}

| 关系 | 示例 | 含义 |
| --- | --- | --- |
| read | Expression 读取 `/price` | 读取依赖，不自动成为 Reaction 触发依赖 |
| watch | Reaction.watch 监听 `/quantity` | 按 L1 匹配语义筛选触发候选 |
| write | Command.set 可能修改 `/total` | 修改可能影响观察者 |
| use | Expression 引用命名表达式，View 引用 Template | 符号复用，不直接修改数据 |
| scope | `insureds[*]` 局部绑定与内部路径模式 | 引用归属与实例化依据 |

例如 Reaction 只 watch `/quantity`，when 读取 `/price`，then 写 `/discount`：不能把 `/price` 自动追加到 watch，否则改变业务语义。内部 `/insureds/*/age` 只是 IR 路径模式，`*` 不是 L1 JSON Pointer 语法；父级更新、数组插入、删除和重排需保守分析影响范围。

仅凭 `host.emit('quote.recalculate')` 无法推断 Handler 最终写哪些字段。Host 显式通过 Command 写回后，由 L3 按实际变化处理。

| 场景 | 静态结论 | 处理 |
| --- | --- | --- |
| Named Expression A → B → A | 确定符号引用环 | Error |
| 静态 View Template A → B → A | V1 无递归终止协议 | Error |
| JSON Schema 合法递归 `$ref` | 不属于上述引用环 | 不误判为表达式 / 模板错误 |
| Reaction A 写 B，B 的观察者又写 A | 潜在触发环，无法证明必然无限执行 | 默认 Warning，报告环链及源位置 |
| when、同值写入、Scope 实例影响终止 | 静态不能保证实际执行结果 | L3 负责执行、防环、预算与诊断 |

可使用 DFS / 强连通分量检查，但不因出现潜在 Reaction 环就默认拒绝 Definition；部署策略可按风险提升诊断等级。L2 将风险前移，不能替代 L3 运行时保护。

### 类型引导的递归分析与使用位置解释

读取集不是订阅集。L2 先从合法 Expression / ValueSpec 递归收集可能读取，再按 [L1 使用位置矩阵](l1/03-expression-validation.md#expression) 编译触发关系：

| 分析对象 | 必须完成 |
| --- | --- |
| ref / use / op + args | 解析来源与词法引用；递归 Named Expression 及全部参数；命名引用环报错 |
| 嵌套 ValueSpec | 遍历合法对象、数组与 `$expr`；Literal / 普通 JsonValue 不识别为表达式 |
| 条件 / 短路计算 | 合并所有可能输入，不能按某个实例当前分支裁剪 |
| Pure Function | 只分析参数，不执行代码或窥探实现；整对象参数按子树观察 |
| 缓存 | 包含词法 Scope、Template 参数和编译上下文；全局 Named Expression 不捕获局部 Scope |
| Schema / 动态路径 | 局部规则尽量精确；条件无法证明时退到对象 / 子树；未来动态路径须明确依赖契约或拒绝 |

Reaction 只使用显式 watch；when / then 的读取保留作求值与诊断，不自动追加。Internal Constraint 合并 when 与 assert；External Constraint 合并显式 watch 与 when 的读取，以决定旧结论失效，不决定请求时机。Issue / external target 只是定位。当前 External 没有 Payload 字段；不能根据来源稿的建议自行扩展协议。

View Binding 与动态 Props 自动形成视图计划；Command Value 和事件 Payload 只在执行 / 事件时求值，不因其读取变化触发事件。ScopeBinder.from 保留结构性关系；Template 参数按已绑定 DataReference 解析，不形成独立可变状态域。

### 静态 Dependency Plan 与 Scope 模式

PreparedForm 携带可复用静态观察描述，信息包括 owner（Reaction / Constraint / View）、触发依赖、已解析引用与 Scope Pattern、由 Runtime 或 View 挂载负责激活。Prepared View 可引用计划 ID 或内嵌紧凑依赖集合；正式字段、条目存储和节点 / 属性粒度仍待固化，见 [最小计划草图](dependency-reactivity.md#dependency-plan)。

计划只保存静态关系与求值入口，不保存回调、组件、当前数组长度、实例 ID 或已执行纯函数结果。Validation / Field Meta 等运行时状态观察由 L3 接入契约描述，不扩展 L1 Reference.source；数组结构观察的编码方式尚未冻结。

L2 知道 `insured(each).age → 该项 Constraint` 的模式；L3 将其绑定为 A.age → Constraint A、B.age → Constraint B；L4 仅激活真实挂载 View 的计划。插入创建业务实例、删除释放无效关系、移动跟随稳定身份、整组替换按身份契约处理，不在编译期推断当前成员。静态统一不意味着 L3 初始化预注册全部 View。

## 投保发布的端到端例子 {#l2-example}

假设 `insurance-application@3.2.0` 使用 `insurance-card`、`core.gte` 和 `insurance.validateIdentity`，声明必需外部 Validator `insurance.eligibility` 与 Host Event `quote.recalculate`。

1. 业务团队提交仅声明逻辑能力 ID 的 L1 FormDefinition。
2. Capability Registry 提供指定平台兼容的 Manifest 与候选不可变能力 Release；Release 构建选择并固定 Catalog Snapshot、版本与制品身份。
3. L2 检查引用、Constraint 的 boolean 返回、Binding Port、Profile、依赖及环，输出 Prepared Artifact、Diagnostics 和依赖信息。
4. Release Manager 登记能力锁、Prepared Artifact 与 Host Requirements；多平台 / Profile 分别形成确定制品。
5. 宿主部署对应 SDK、Material、Pure Function 实现，并在初始化时注册 Host Handler。
6. Runtime 做兼容与能力预检查；必需 Validator 缺失不能被当作通过。Host 执行请求，需改业务数据时经受控 Command 写回，外部义务报告还需有效性检查。

```json
{
  "materials": ["insurance-card"],
  "pureFunctions": ["core.gte", "insurance.validateIdentity"],
  "hostRequirements": {
    "validators": ["insurance.eligibility"],
    "events": ["quote.recalculate"]
  }
}
```

这是概念发布摘要，不是新增 L1 字段。实际 PreparedForm 分别携带 Form / View Plan、Scope / Reference 准备结果、锁定与 Host 要求；Runtime 的具体初始化 API 仍待 L3 固化。

## 失败路径、治理与验收 {#l2-acceptance}

| 故障 | L2 / 平台 | Runtime |
| --- | --- | --- |
| 未注册 `insurance.validateIdentity` | 编译错误，不猜测映射 | 不装载缺少必需纯函数的产物 |
| 同 ID 存在不兼容能力 Release | 构建时选择唯一锁定版本 | 匹配已锁定实现 |
| Flutter 缺少 Material 实现 | 针对目标平台 / Profile 报不可用 | 不静默使用 Web Bundle |
| 纯函数签名变化 | 重检 / 重编受影响 Definition | 版本 / ABI 不匹配拒绝加载 |
| 必需 Host Validator 未注册 | Requirements 记录阻塞义务 | 不得绕过义务进入提交 Ready |
| Host Event 无静态契约 | 提取名称与有限信息，说明不可证明项 | 执行前 / 调用时检查，明确诊断 |
| 纯函数代码有副作用或语义漂移 | 契约测试、审核、发布控制 | 必要隔离与故障处理 |
| Reaction 潜在环 | 定位环链并告警 | 按实际变化调度，防环与诊断 |
| Prepared Format 不兼容 | 选择匹配目标格式 | 启动时拒绝不兼容制品 |
| 旧发布依赖 latest | 发布流水线拒绝不确定依赖 | 不静默热替换 |

保留 Definition → Compiler Version → Catalog Snapshot → Capability Lock → Prepared Artifact → Runtime Version 的追踪链，才能解释同一表单在不同客户端的差异。

成功标准：锁定输入可复现；已知静态错误具有精确 Diagnostic；未预先注册的 Host 依赖明确表达并在运行时可靠检查；不把 L3 / L4 或平台发布职责移入编译器。现有 L1 五组基线与补充样本可作为后续验收输入，候选验证器尚未验收本篇的 L2 / Release / ABI 契约。

## 决策记录与待固化接口 {#l2-decisions}

| 编号 | 决策 | 状态 |
| --- | --- | --- |
| D01 | L2 是平台静态协议编译能力，平台管理能力另有归属 | 已收敛 |
| D02 | AOT、服务端按需、客户端加载可共用编译语义，独立于实例业务数据 | 已收敛 |
| D03 | Form Registry、Capability Registry、Compiler、Release Management 分工 | 已收敛 |
| D04 | 能力分为 Material / Pure Function / Host | 已收敛 |
| D05 | Pure Function 为同步纯计算；复杂同步自定义校验直接复用 | 已收敛 |
| D06 | 内置 `core.*` 与注册纯函数共用 Expression 调用协议，禁止覆盖 | 已收敛，具体别名映射待固化 |
| D07 | Material / Pure Function 有静态 Manifest，Host 静态契约可选 | 已收敛 |
| D08 | Host 运行时注册；L2 提取 Requirements，不强制托管 Host 代码 | 已收敛 |
| D09 | 能力代码构建与 Definition 编译为两条链路 | 已收敛 |
| D10 | Form Release 锁定能力版本和不可变制品身份 | 已收敛 |
| D11 | L1 Protocol 与 Prepared Runtime Format 分开版本化 | 已收敛 |
| D12 | 按关系类型分析依赖；符号引用环 Error，潜在 Reaction 环默认 Warning | 已收敛 |
| D13 | 输出 PreparedForm、Diagnostics、能力依赖与 Host Requirements | 结构方向已收敛，字段待固化 |
| D14 | 所有现行及历史阅读文档统一使用 Pure Function / 纯函数术语；原始来源保留追溯 | 本次架构决策，2026.10.17 |
| D15 | 类型引导递归收集读取，再按使用位置编译触发关系；不执行纯函数发现依赖 | 跨层设计基线，2026.10.17 |
| D16 | Prepared 交付 Dependency Plan 与 Scope Pattern；Runtime 规则和 View 采用不同激活归属 | 结构方向已收敛，正式字段 / ABI 待固化 |

| 待固化项 | 当前方向 | 判定标准 |
| --- | --- | --- |
| Expression `op` vs `call` | 本次保留 `op + args` | 若迁移，作为独立 L1 版本变更统一处理 |
| 内置别名与 Canonical ID | 短名只作明确别名，完整 `core.*` 为规范化方向 | 白名单、映射、内置签名及现有样本迁移 |
| Host 缺失处理 | 必需 Validator 不得绕过；可选遥测按声明跳过；一般事件必须可诊断 | 可选性、阻断时机、重试和错误等级 |
| PureFunctionManifest 最小签名 | ID、版本、输入输出、目标端可用性 | JSON Schema / TypeSignature 的可判定交集 |
| Capability Release Lock | 版本 + 不可变摘要；按平台 / Profile 解析 | 摘要覆盖对象及 Runtime 核对方式 |
| Prepared ABI | 独立 formatVersion | 兼容矩阵、升级策略、feature 标识 |
| Dependency Plan | owner、watch、Scope Pattern 与激活归属；与 Form / View Plan 关联 | 序列化、状态引用、结构观察编码、节点粒度及格式迁移 |
| Material 的 Host Service | Manifest 声明可观察依赖 | 未声明依赖的发布限制或运行时报告 |

这些是规范落地时的接口决策，不重新开放已经收敛的职责分工。

## 后续交付与来源 {#l2-delivery}

下一阶段优先固化以下四类交付；当前任务只整合设计，不创建概念性的生产发布包：

1. `capability-contracts.ts`：Material / Pure Function / Host Contract 的 ID、签名、平台与版本规则。
2. `prepare.ts` 与 `prepared-form.types.ts`：编译输入、Diagnostics、Prepared 输出与 Format 兼容约束。
3. `release-manifest.schema.json`：能力锁、Prepared Artifact 身份、目标平台 / Profile 与不可变性。
4. 验收用例：未注册纯函数、端口不兼容、Template 环、Reaction 潜在环、版本不匹配、Host 缺失及跨端制品兼容；用现有 L1 基线反向验证。

原始依据为用户提供的《L2 Preparation · 平台能力治理与编译发布架构 · 决策归档 V0.1》，21 节讨论内容已按职责整合到本篇；类型 / JSON 草图保留候选状态，并对齐现行类型化 Reference。原始附件与术语统一前的历史阅读文件见 [来源归档](../history/README.md#l2-integration)。现行内容发生冲突时，以本篇和相应 L1 主题为准。

后续跨层模型补充的读取 / 触发区分、递归分析、Dependency Plan 和 Scope 分工已整合至本篇；原件与整合前正文见 [跨层模型来源](../history/README.md#dependency-integration)。先用跨字段 Constraint、嵌套 Expression 和 scoped View 检验最小消费契约，再深入变化调度，不将候选验证器包装成编译器实现。
