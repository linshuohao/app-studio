"""Shared reading shell; independent of Markdown and validation dependencies."""
from __future__ import annotations

import html
import os
from pathlib import Path
from string import Template
from urllib.parse import quote

ROOT = Path(__file__).resolve().parents[2]
ASSETS = ROOT / "docs/reading/assets"
NAVIGATION = [
    ("整体架构", "docs/reading/architecture.html"),
    ("L1 定义协议", "docs/reading/l1-definition-protocol-v1.html"),
    ("L2 编译与发布", "docs/reading/l2-preparation.html"),
    ("依赖与订阅", "docs/reading/dependency-reactivity.html"),
    ("协议样例", "docs/validation/index.html"),
]


def relative(target: Path, output: Path) -> str:
    return quote(os.path.relpath(target, output.parent), safe="/.-_")


def section_heading(title: str, number: int, status: str = "", level: int = 2) -> str:
    badge = ('<span class="status' + (' open' if status == '待固化' else '') + '">' + html.escape(status) + '</span>') if status else ''
    return f'<div class="section-head"><div class="kicker">{number:02d} · FORM ENGINE</div><div class="section-title"><h{level}>{html.escape(title)}</h{level}>{badge}</div></div>'


def render_document(*, output: Path, title: str, body: str,
                    toc: list[tuple[str, str]], eyebrow: str,
                    lead: str = "", subtitle: str = "", source: Path | None = None,
                    wide: bool = False, extra_css: str = "",
                    toc_groups: list[tuple[str, list[tuple[str, str]]]] | None = None) -> str:
    nav = []
    for label, path in NAVIGATION:
        current = ROOT / path == output
        nav.append(f'<a href="{relative(ROOT / path, output)}"' + (' class="active" aria-current="page"' if current else '') + f'>{html.escape(label)}</a>')
    chapter_titles = dict(toc)

    def toc_link(anchor: str, label: str, number: int) -> str:
        title = html.escape(chapter_titles.get(anchor, label), quote=True)
        return f'<a href="#{html.escape(anchor, quote=True)}" data-to="{html.escape(anchor, quote=True)}" title="{title}"><span class="nav-num">{number:02d}</span><span>{html.escape(label)}</span></a>'

    links = []
    if toc_groups:
        number = 0
        for group_number, (label, entries) in enumerate(toc_groups, 1):
            children = []
            for anchor, entry_title in entries:
                number += 1
                children.append(toc_link(anchor, entry_title, number))
            expanded = ' open' if group_number == 1 else ''
            links.append(f'<details class="toc-group"{expanded}><summary><span class="nav-num">{group_number:02d}</span><span>{html.escape(label)}</span></summary><div class="toc-items">' + '\n'.join(children) + '</div></details>')
    else:
        links = [toc_link(anchor, label, i) for i, (anchor, label) in enumerate(toc, 1)]
    source_action = f'<a class="btn source-btn" href="{relative(source, output)}">查看源文</a>' if source else ''
    values = {
        "title": html.escape(title),
        "home": relative(ROOT / "docs/reading/architecture.html", output),
        "archive": relative(ROOT / "docs/history/index.html", output),
        "stylesheet": relative(ASSETS / "documentation.css", output),
        "script": relative(ASSETS / "documentation.js", output),
        "extra_stylesheet": f'<link rel="stylesheet" href="{relative(ASSETS / extra_css, output)}">' if extra_css else '',
        "navigation": '\n'.join(nav),
        "toc": '\n'.join(links),
        "eyebrow": html.escape(eyebrow),
        "subtitle": f'<span class="subtitle">{html.escape(subtitle)}</span>' if subtitle else '',
        "lead": f'<div class="desc">{lead}</div>' if lead else '',
        "body": body,
        "source_action": source_action,
        "content_class": 'content content--wide examples' if wide else 'content',
    }
    template = (Path(__file__).parent / "templates/document.html").read_text(encoding="utf-8")
    return Template(template).substitute(values)
