# 复杂动态表单与数据录入引擎

当前处于方案设计与规范固化阶段，主阅读入口如下：

- [使用与开发指南](docs/reading/usage-guide.html)：从最小字段逐步理解计算校验、联动、重复项、宿主接入、排障和参与开发。
- [设计者指南 · 整体架构](docs/reading/architecture.html)：设计思想、概念、完整分层与图示、机制、取舍、交付物和验收路线。
- [L1 定义协议](docs/reading/l1-definition-protocol-v1.html)：设计正文、示例、决策与待固化项，主题目录直接放在侧栏。
- [L2 编译与发布](docs/reading/l2-preparation.html)：平台能力治理、Pure Function、Host 注册、静态编译与不可变发布。
- [依赖与订阅](docs/reading/dependency-reactivity.html)：原始 / 编译后协议、显式 Watch 与作者确认、统一观察、挂载生命周期及跨层验收。
- [L3 执行与诊断](docs/reading/l3-reactive-engine.html)：逐 Command Data / Scope 比较、新实例激活、稳定快照、Runtime / Host 业务边界、整体 Flush 与临时 Trace。
- [L3 校验与结果](docs/reading/l3-validation.html)：完整 Schema、增量任务、本轮前置、异步有效性、字段 Issue 聚合与完整校验边界。
- [协议样例](docs/validation/index.html)：完整 Definition、结构关系、变化流程与验证证据。

Markdown 是设计正文，HTML 由正文生成。上下文读取与维护方式见 [文档维护](docs/README.md)，协作约定见 [AGENTS.md](AGENTS.md)。
