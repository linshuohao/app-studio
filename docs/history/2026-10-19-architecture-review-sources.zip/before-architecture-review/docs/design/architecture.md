# 设计者指南：整体架构与设计取舍

复杂动态表单与数据录入引擎采用 Definition → Preparation → Runtime → Renderer 四层架构。本指南面向架构设计、方案评审与核心实现，展开思想、概念、各层服务对象、职责、机制、完整图示、取舍、交付物和验收路线。希望从普通字段逐步了解和接入框架时，先读 [使用与开发指南](usage-guide.md)。两份指南共用 L1 / L2 / 依赖订阅 / L3 专题作为详细契约，避免平行维护两套规范。

四层边界、L1 主体语义、L2 静态编译与发布治理、跨层依赖职责已收敛。2026.10.18 进一步确认不可变 Working Data、逐 Command 即时生效、Reaction 最新状态收敛、延迟启动同步 Flush 和临时 Trace。V0.5 进一步确认 L1 / PreparedForm 两份结构、L3 唯一 Prepared 执行入口、作者确认 Watch 建议、可隔离 Command 错误继续与整体 Flush 熔断，替代局部 Health 传播。V0.6 收敛逐 Command 检测、相对 Scope 与首次激活；后续用户修订已确认常规 Reaction 只响应有效 Watch 变化、runOnActivate 仅新实例首次激活，Dirty / 业务 Baseline / Reset 策略归 Host，替代 Runtime 自动基准和主动重算。稳定快照 SDK、激活默认值、通知、排序、Pending、Validation / Submit、ABI 与 L4 适配继续固化，索引候选仍保留推荐状态。图中的流程不代表生产实现已经完成。

## 产品能力边界 {#boundary}

我们建设的是复杂动态表单与数据录入引擎。所有原生能力都应服务于表单式数据交互，避免扩张为通用页面搭建器、任意脚本平台或完整 BPM 系统。

| 能力范围 | 处理方式 | 原因与边界 |
| --- | --- | --- |
| 字段定义、数据绑定、布局分组 | L1 + Runtime + Material | 表单基础能力；数据和视图具有不同身份 |
| 条件显隐、必填、禁用 | Expression / Constraint + View Props | 展示条件与数据合法性分别表达，不依赖控件单独保证业务规则 |
| 跨字段计算、动态校验、同步联动 | 核心原生 | 纯计算不写数据；实际修改通过 Command / Reaction |
| 嵌套对象、动态数组、重复区块 | 核心原生 | 需要统一寻址、词法作用域和稳定实例身份 |
| 数据加载、实例装载、批量赋值与业务恢复 | Host 编排 + L3 初始输入 / Command | Host 管业务 Baseline / Dirty / Reset；L3 管实际数据变化和新实例激活 |
| 异步选项、远程查询、外部业务校验 | Host / 物料服务 | Host 管请求、缓存与重试；Runtime 接收有效校验事实 |
| 分步骤表单 | View 容器 + Host / 生命周期 API | 不等于核心内置工作流，切换步骤不自动删除共享规则 |
| 自定义复杂业务字段 | Material 扩展 | 隔离领域交互，但最终业务值必须通过 Binding / Command 交付 |
| 报价、核保、审批、支付、生成保单 | 宿主业务服务 | 保留服务端权威状态，不放入核心同步调度 |
| 任意页面搭建、营销动效、通用 BPM | 不作为核心目标 | 成本与表单引擎的主要价值不匹配 |

被保人录入、条件联动、资格校验和异步报价展示可以组合在同一业务页面。它们由不同职责协作完成，不必因此全部成为 Runtime 的内部能力。

贯穿方案的思想是让稳定业务语义可声明、可分析、跨端复用，同时把实例状态、界面交互与外部业务放在各自边界内。

| 思想 | 具体设计 | 接受的代价 / 约束 |
| --- | --- | --- |
| 业务数据只有一个权威源 | Data / View 分离，多 Profile 共用 Runtime | Renderer 不另算业务或绕过 Command 修改数据 |
| 先声明语义，再准备执行 | L1 受控 DSL，L2 静态计划，L3 绑定真实实例 | 禁止任意脚本；正式 Prepared ABI 需要单独固化 |
| 输入即时生效，联动趋于最新状态 | 不可变 Root、结构共享、pending 合并与 Flush | 中间状态可存在；提交需检查所需联动、校验与输出完成边界 |
| 匹配共用，消费与生命周期分别负责 | Reaction / Validation / View 共享观察基础 | Flush 完成不代表外部校验或 UI 完成 |
| 有限执行、事实可追踪 | 整体 Flush 预算、临时 Trace、真实异常结果与报告 | 无通用终止证明；完整重放和复杂调度延期 |

## 整体架构：四层核心、受控扩展与宿主边界 {#architecture}

先划定逻辑职责，再决定代码模块、包边界和部署形态。下图恢复整体层次及 Runtime 内部模块的关系。

```diagram
{
  "id": "figure-architecture",
  "title": "图 1 · Logical Architecture：四层核心与横向协作",
  "rows": [
    [{"title":"Tooling / Form Studio / Platform","body":"配置编辑 · 预览 · Diagnostics · Devtools · Form / Capability Registry · 发布治理"}],
    [{"title":"L1 · Definition / 表单定义","body":"Data Schema · Reference / Scope · Expression · Constraint · Command / Reaction · Views / Templates"}],
    [{"title":"L2 · Preparation / 静态协议编译","body":"原始 Definition + 契约快照 + Target → PreparedForm / 确定依赖与执行计划"}],
    [{"title":"L3 · Form Runtime / 表单运行时","body":"唯一不可变 Working Data · 即时 Command · 统一观察与最新状态 Flush；对外 read / snapshot / dispatch / subscribe","major":true,"items":["Data / Field State","Scope / Relative Position","Expression Evaluation","Dependency Matching / Flush","Command / Reaction","Validation / Readiness","Flush Outcome / Diagnostics","Instance Lifecycle"]}],
    [{"title":"L4 · Renderer / Material Adapter","body":"Web / Flutter · Material 实例 · Binding 连接 · 挂载 / 改绑 / 卸载订阅 · 局部 UI State"}],
    [{"title":"Material Registry","body":"Props、Binding Ports、Slots、Events 的 Manifest 与平台实现"},{"title":"Pure Function Catalog","body":"内置与注册的同步纯函数、签名、版本与跨端实现"},{"title":"Host Integration","body":"外部校验执行 · host.emit · 注入的物料服务"}],
    [{"title":"Host Application / Backend","body":"异步加载 · 业务 Baseline / Dirty / Reset · 保存 / 提交 · 权限 / 外部业务"}]
  ],
  "arrows":["↓","↓","↓","↕","↕","↕"],
  "note":"这是职责关系图，不是逐跳调用顺序。平台管理资产与不可变发布，L2 消费契约，L3/L4 绑定已锁定实现；Host 管外部请求，需改数据时显式提交 Command。"
}
```

| 层 / 协作方 | 核心问题 | 主要服务对象 |
| --- | --- | --- |
| L1 · Definition | 表单是什么？数据与业务规则是什么？ | 配置者、设计器、Preparation |
| L2 · Preparation | 定义是否合法？如何形成可消费的准备产物？ | Runtime、开发工具、发布流程 |
| L3 · Runtime | 数据如何变化、传播、校验并形成可观察状态？ | Renderer、Host、调试工具 |
| L4 · Renderer | 如何呈现语义、适配输入并管理组件实例？ | 最终用户、平台与物料开发者 |
| Material Registry | 如何声明、检查和加载可复用的 UI 能力？ | 设计器、L2、Renderer |
| Pure Function Catalog | 如何统一检查和绑定内置、领域纯计算能力？ | L2、Runtime、能力开发者 |
| Host | 如何连接请求、业务与服务端权威状态？ | 宿主应用、业务服务、自定义物料 |
| Tooling | 如何配置、诊断、验证、调试和发布？ | 配置者、开发者、交付团队 |

**状态归属只有一个权威源。**每个 Form Instance 只有一份 Working Data。Renderer 不保存第二份权威业务数据，也不另行解释业务规则。

**不要求交付多个独立引擎。**不预建独立 View Engine、Workflow Engine 或复杂双向桥接平台。外部流程通过 Host 集成；内部纯计算通过受控 Pure Function 扩展。

**两份结构，一条执行路径。**FormDefinition 供业务作者编辑和审查，PreparedForm 是编译后的运行输入；Canonical / Authoring 仍属于 L1，不是第三套业务协议。L3 只消费兼容 PreparedForm，不在失败时退回直接解释 L1。编辑期调用 L2 给出建议，作者确认后修改定义再编译；Prepared 的执行依赖在编译时确定。完整对照见 [原始与编译后协议](dependency-reactivity.md#dependency-compiled-protocol)。

## 各层总览：能力、取舍与责任边界 {#overview}

| 层次 | 核心能力 | 重要取舍 | 不应该负责 |
| --- | --- | --- | --- |
| Definition | 数据、引用、纯表达式、约束、命令、联动与视图声明 | 配置友好与协议复杂度 | 求值队列、事务波次、网络调度、DOM |
| Preparation | 规范化、静态诊断、词法与模板解析、依赖分析、索引 | 预处理深度与维护成本 | 用户输入、交互状态、当前请求和会话 |
| Runtime | Working Data、稳定快照、Scope、新实例激活、变化驱动规则、Validation 与 Flush | 协议执行正确性、性能和可解释性 | DOM、请求、Dirty / 业务 Baseline / Reset 策略、主动修复业务结果 |
| Renderer | 物料树、绑定与事件适配、订阅、局部交互 | 跨端语义与平台体验 | 独立业务求值、绕过 Command 写 Store |
| Material | UI 契约、容器组合、领域组件、平台实现 | 灵活性与契约约束 | 篡改内部状态、隐式增加协议语义 |
| Pure Function | 同步确定性计算、类型签名、内置与领域扩展 | 复杂算法复用与跨端一致性 | I/O、外部可变状态、数据写入和校验状态管理 |
| Host Integration | 查询、上传、外部校验、提交和业务流程 | 通用接入与业务差异 | 替代核心数据命令或服务端权限控制 |
| Tooling | 编辑、预览、测试、Trace、版本治理 | 作者体验与建设成本 | 成为线上执行的必需依赖 |

总体分层与 L3 执行基线已确定，不等于内部实现全部冻结。后文保留模块图、修改与 Flush 流程和接口草图，具体缓存、错误分类接口、通知重入、精确顺序和 SDK 返回值仍需契约与验收。旧事务候选由即时 Command + 非原子 batch + 独立 Flush 取代，历史原稿保留追溯。

**跨层依赖基线：**读取依赖描述可能用到的输入，触发依赖描述哪些变化需要响应，活跃订阅描述此刻正在观察的消费者。L2 统一编译 Dependency Plan，L3 按状态来源、引用和 Scope 实例统一匹配；Reaction / Constraint 随 Runtime 激活，View 随 L4 实际挂载订阅。完整使用位置、计划、生命周期、方案比较和验收见 [跨层依赖编译与响应式订阅](dependency-reactivity.md)。

**运行执行基线：**Command 即时写入，待执行 Reaction 实例合并后读取最新状态，同步级联留在当前 Flush。可隔离 Command 错误记录后继续独立行为，安全预算超限停止整轮，已写 Data 保留；有序 Trace 记录事实，图由开发工具派生。完整状态所有权、取舍、26 项决策与 18 个验收场景见 [L3 Reactive Engine](l3-reactive-engine.md)。

**执行资格与业务编辑分开。**常规 Reaction 仅因显式 Watch 的有效观察值变化新增入队；runOnActivate 只用于新规则实例首次激活。导入 age25 / premium80 覆盖 age25 / premium150，若只 watch age 且没有先前 pending，Runtime 保留导入的 80，不自动修复为 150。Runtime 保证协议执行与声明校验，Host 决定编辑、业务基准、恢复与保存期望；snapshot 只读取稳定数据，不标 Clean 或重算。Context 保留现行只读 / Data-only Watch 契约。

## L1 · Definition：领域模型与协议层 {#definition}

L1 决定配置者需要理解多少概念，以及新业务需求是否会不断迫使协议膨胀。优先追求语义清晰、可组合、可静态检查和简单场景低成本。完整定义、类型关系、例子与决策理由集中在 [L1 Definition Protocol V1.0](l1/README.md)，本节展开它在整体架构中的作用。

### 服务对象与核心目标

| 服务对象 | 需要的能力 |
| --- | --- |
| 业务配置者 | 简单地表达字段、展示条件、同步联动与合法性 |
| 可视化设计器 | 创建、定位、组合、编辑和检查配置节点 |
| Preparation | 将声明规范化并解析为可检查、可准备的结构 |
| Runtime / Renderer | 在一致语义下执行数据规则并消费视图定义 |

### 领域概念如何组合

```diagram
{
  "id":"figure-definition",
  "title":"图 2 · Form Definition Domain Model：当前语义概念的组合",
  "rows":[
    [{"title":"FormDefinition","body":"一份共享业务定义，可通过具名 Profile 选择不同视图","major":true}],
    [{"title":"Data / JSON Schema","body":"数据形状、静态约束、默认值与输出契约"},{"title":"Reference / Scope","body":"统一寻址、局部词法绑定；稳定实例身份归 L3"}],
    [{"title":"Expression / ValueSpec","body":"纯 AST、命名表达式与递归显式 $expr"},{"title":"Constraint","body":"内部断言、外部校验义务与 Issue 归属"}],
    [{"title":"Command / Reaction","body":"受控数据修改与 watch / when / then 同步联动"},{"title":"View / Template","body":"MaterialNode、ScopeNode、TemplateUse；Props、Bindings、Slots、Events"}]
  ],
  "arrows":["↓","↕","↕"],
  "note":"这是概念关系图，不增加 FormDefinition 顶层字段。最初图中的独立 Resource 已由后续决策移出核心，外部能力通过 Host 集成。"
}
```

Data 与 View 在语义上分离，在设计器中可以统一编辑。用户添加一个“年龄输入框”时，工具可以同时创建数据字段和物料节点；两者仍有不同身份。这支持一个字段被输入框和摘要同时消费，也支持日期范围、地址等一个物料绑定多个数据位置。

- JSON Schema 定义数据结构与基础约束；Working Data 可暂时不合法，Normalized Output 单独校验。
- Reference 统一寻址；ScopeBinder 建立词法名称。ScopeHandle 用于实例命令，模板参数传 Typed DataReference，不能把 Handle 当作业务 ID 发送给服务端。
- Expression 为纯 AST，ValueSpec 通过显式 `$expr` 递归嵌入计算。Constraint 不写数据，Reaction 的变化传播只消费内部 Data Change；显式首次激活是独立入队原因，不是外部异步业务 Reaction。
- View 由 MaterialNode / ScopeNode / TemplateUse 构成；具名 Profile 的值直接为 ViewNode，共享业务规则不因隐藏或 Profile 切换而裁剪。
- Canonical 使用具名 `bindings` 和数组 `slots`；`bind`、`children` 只属于 Authoring 简写。

`protocolVersion`、`id`、`version` 与 `metadata` 合并展示为“定义信息”仅是阅读分组，字段仍在顶层。Profile 名 `default` 与物料 `slots.default` 分属不同层次。

### 配置友好与语义严谨的取舍

| 设计问题 | 当前方向 | 取舍理由 |
| --- | --- | --- |
| 数据与 UI | 语义分离，设计器可合并编辑体验 | 数据不受控件树限制，支持多视图与复合端口 |
| 表达式 | 纯 AST + 受控 Pure Function | 可静态分析并约束跨端求值，避免任意脚本 |
| 展示派生与数据修改 | Expression 计算；Command / Reaction 显式修改 | 避免为了显示信息复制一份业务状态 |
| 业务合法性 | Schema + Internal / External Constraint | 不把合法性藏在组件 Props 中 |
| 结构复用 | 静态 Template + `schemaRef` / DataReference 参数 | 复用视图而不共享 UI 实例或复制业务数据 |
| 外部业务 | Host 三条集成路径 | 不把请求、重试、上传和提交扩展成核心 DSL |
| 数据标准 | 复用 JSON Schema，独立表达交互 | 数据约束标准化，表单交互保留必要语义 |

配置者可以表达“未满 18 岁时显示监护人姓名，并要求填写”，但底层必须区分展示和合法性：

```text
纯表达式：isMinor = age < 18
View Props：guardianName 的显示条件读取 isMinor
Constraint：isMinor 为 true 时，guardianName 必须非空

显示/隐藏不会自动删除数据，也不会取消共享 Constraint。
如需清空某个业务字段，应由明确的 Reaction / Command 表达。
```

字段缺失、null、空字符串、空数组和无法解析的输入需要明确的数据语义；不能交给不同组件各自决定。Definition 不描述内部队列、Dirty Set、网络调度器或 UI 订阅机制。

**本层详细设计交付物：**Canonical Type、JSON Schema、Reference / Union / Literal 消歧、Pure Function 与 Material 版本契约、正反例及兼容规则。架构收敛不等于这些发布产物已经完成；具体清单见 [待固化事项](l1/08-decisions-release.md#boundaries) 与 [发布验收](l1/08-decisions-release.md#release)。

## L2 · Preparation：定义预处理层 {#preparation}

Preparation 将易编辑的定义安全、稳定地转成 Runtime 可消费的 Prepared Form。它服务 Runtime、设计器、发布流程和测试工具；配置者主要消费它输出的诊断信息。

**2026.10.17 设计基线已收敛：**L2 是静态协议编译能力；平台另行管理 Form Registry、Capability Registry、代码构建与 Release Management。内置与注册纯计算能力统一称为 Pure Function，Host 在应用运行时注册实现。完整职责、契约草图、发布例子、决策及待固化项见 [L2 平台能力治理与编译发布](l2-preparation.md)。

L2 可以在发布期 AOT、服务端按需或客户端加载时调用，不读取实例 Working Data，也不执行业务纯函数、Command 或 Reaction。平台先提供确定的 Material / Pure Function 契约快照、目标平台 / Profile 与格式要求；Host 静态契约可选，缺失时提取需求并说明无法证明的兼容性，不能据此认定运行时实现不存在。

### 预处理流水线

```diagram
{
  "id":"figure-preparation",
  "title":"图 3 · Preparation Pipeline：从定义到准备产物",
  "flow":true,
  "rows":[
    [{"title":"Definition + Catalog Snapshot + Target","body":"Authoring / Canonical 与确定的能力契约"},{"title":"Normalize / Validate","body":"规范化并检查结构、类型与端口契约"},{"title":"Resolve","body":"Reference、Scope、Template、Material / Pure Function 与可选 Host 契约"}],
    [{"title":"Analyze","body":"递归读取 → 使用位置解释；read / watch / write / use / scope、静态环"},{"title":"Diagnostics","body":"定位错误与风险；Reads / Watch 差异给作者建议，确认修改 L1 后重编"},{"title":"Transform / Package","body":"确定 Form / View / Dependency Plan、Scope 模式、Profile 与共享规则"}],
    [{"title":"PreparedForm / Profile Bundle","body":"可序列化准备结构 + Capability Lock + Host Requirements；交由 Release 管理不可变发布","major":true}]
  ],
  "arrows":["↓","↓"],
  "note":"Validate / Analyze / Transform / Package 是逻辑职责，不强制四个服务或四次遍历。结构方向已收敛，具体字段、增量与缓存契约仍待固化。"
}
```

### 需要设计的内容

1. **规范化与诊断。**Authoring 简写如何转为唯一 Canonical；错误怎样关联文件、节点和引用位置；错误与警告如何分类。
2. **词法与模板解析。**Scope 链顺序、别名可见性、模板参数 `schemaRef` 兼容性、静态 `$use` 及 Profile 依赖闭包。
3. **表达式发现与依赖。**只在规定的 Expression / ValueSpec 位置识别表达式，递归识别显式 `$expr`；不扫描执行 Working Data、Schema default、结构字段或外部原始 JSON。Named Expression 不无限展开，也不捕获调用者的局部 Scope。
4. **契约与成本检查。**Material 的 Props / Binding / Slot / Event 端口、Pure Function 签名与版本、表达式环、可达图和复杂度上限；有 HostContract 时增加静态签名检查。
5. **交付与缓存。**按 Definition 内容、Compiler / Format 版本、目标与锁定依赖确定缓存；交付当前 Profile 的视图闭包，完整保留共享 Schema / Constraint / Reaction，并携带能力锁与 Host Requirements。精确字段和摘要覆盖范围继续固化。

读取分析覆盖嵌套 ValueSpec、Named use 和全部可能分支，Literal 不参与。随后按 L1 使用位置解释：Internal Constraint 合并 when + assert；External 合并显式 watch 与 when；Reaction 不追加 when / then 读取；View Binding / 动态 Props 自动观察，事件 Payload 只在事件时求值。L2 不执行纯函数发现依赖；整对象输入与无法精确推导的 Schema 条件按子树保守覆盖。

Dependency Plan 保存行为身份、触发引用、Scope Pattern、激活归属和 Prepared 求值关联，不保存真实数组成员、回调或组件。L2 知道 each 模式，L3 知道实例，L4 知道挂载节点；View 可关联计划 ID 或内嵌静态依赖，正式 ABI 仍待固化。

配置编辑复用同一 L2 分析能力。Reads 不在 Watch 中时提供风险与补全建议，不静默改写配置或 Prepared 计划；作者可确认保持现有触发意图。产品变化清空选项，即使计算不读取产品也应保留显式 Watch。推荐编辑期增量检查、发布期完整编译，并用 Source Map 关联 L1 来源，详见 [编辑与编译闭环](l2-preparation.md#l2-authoring-diagnostics)。

### 复杂度取舍

| 问题 | 设计方向 | 暂不默认引入 |
| --- | --- | --- |
| 解释 vs 预处理 | 加载或发布时准备，运行时消费索引 | 每次字段变化重读整份配置 |
| 编译深度 | Validate / Analyze / Transform / Package，复用规范化、解析与索引 | 完整代码生成与重型优化器 |
| 依赖关系 | 区分 read / watch / write / use / scope；实例化时关联 Scope | 将所有读取自动变成 Reaction watch |
| 物料检查 | 检查 Manifest、版本、端口和类型 | 执行物料内部代码来推断契约 |
| 循环与成本 | 表达式 / 模板静态环 Error，潜在 Reaction 环默认 Warning；L3 另有保护 | 将合法 Schema 递归或全部潜在环判为非法 |
| 产物缓存 | 版本、目标、内容 Hash 与锁定依赖关联 | 先建设复杂编译集群 |

例如 500 个字段、200 条表达式的表单，应能根据索引定位受影响节点；实际收益需要基准验证，不能把目标直接写成性能结论。

**Prepared Form 不是第二套 Runtime。**它可以包含规范化定义、已解析引用、准备后的表达式与规则、依赖索引和契约版本；不包含用户输入、焦点、当前 Issues、请求状态或会话。一个准备产物应允许多个实例安全复用。

**代码构建与 Definition 编译分开。**CI 将能力源码构建为各平台 Package + Manifest；L2 将 Definition + 契约快照编译为 Prepared Artifact。Release Manager 汇聚制品并锁定能力版本与摘要，升级能力不自动改变旧发布，回滚读取旧 Release Artifact。共同能力 ID / 版本保证语义一致，不要求 Web 与 Flutter 共用二进制。

**本层交付物与验收：**Prepared 结构、诊断格式、依赖/规则索引、Profile Bundle、Capability Lock、Host Requirements 和缓存键；验证非法引用、Scope 越界、模板类型、端口不兼容、版本缺失、锁定输入可复现、多实例复用隔离、Host 缺失及目标格式 / 跨端制品兼容。完整 [待固化接口与工程交付](l2-preparation.md#l2-decisions) 尚未实现。

## L3 · Runtime：状态、身份与内部执行 {#runtime}

核心投入集中在复杂表单的状态一致性、动态数组、依赖传播和时序边界。Runtime 拥有唯一可写 Working Data；不拥有业务网络请求、Resource Store 或通用外部动作执行器。

| 内部模块 | 需要设计的内容 | 边界 |
| --- | --- | --- |
| Data / Field State | 工作态、读取、字段状态、订阅与输出 | 允许无效工作态，不保留第二份可写业务真相 |
| Scope / Identity | 实例身份、数组增删移动、词法引用关联 | 下标不是永久身份，不强制注入业务 `__id` |
| Expression / Dependencies | 纯求值、依赖失效、缓存和成本保护 | 不发请求、不写数据、不执行任意脚本 |
| Reactive Engine | 消费 L2 计划，按来源 / 引用 / Scope 匹配统一订阅；按生命周期激活 | 不重复扫描 AST，不统一各消费者的执行策略或直接刷新组件 |
| Command / Reaction | 数据修改、实际变化、触发候选、门控和同步级联 | 不增加异步 Reaction 或业务事件总线 |
| Validation / Readiness | Schema、内部约束、外部义务、Issues 和有效性 | 不执行远程校验或替代 Host 提交许可 |
| Flush Outcome / Diagnostics | 本轮执行结果、临时 Trace、整体预算和异常报告 | 不做局部 Health / 影响链传播，不逐步保存生产全量快照 |
| Instance Lifecycle | 实例装载、真实 Scope / 规则新建、替换与销毁 | runOnActivate 仅新实例；业务编辑 / 恢复策略归 Host |

### State Store：数据与状态如何分开

| 类别 | 示例 | 所有权与提交关系 |
| --- | --- | --- |
| Working Data | 年龄、姓名、目的地、被保人数组 | Runtime 中唯一业务数据；工作态可不合法 |
| 纯求值结果 | isMinor、动态摘要、View Props 值 | 可缓存，但不因此自动进入业务数据或输出 |
| 校验与 Field State | Schema / Constraint 状态、Issues、有效性 | Runtime 管理，经既有 Binding 供物料消费 |
| 业务编辑状态 | Dirty、业务 Baseline、Reset 意图 | Host 自行定义和保存，不属于 Runtime 核心状态 |
| 局部 UI State | touched、焦点、输入法组合态、弹层开闭 | Renderer / Material 管理，不成为第二份 Working Data |
| 外部请求状态 | loading、error、候选列表、报价结果 | Host / 物料服务管理；写业务字段时显式 Command |
| Normalized Output | 提交所需的规范化数据 | 与工作态分开构造和校验，由 Host 执行提交 |

2026.10.18 已选择不可变 Working Data Root + 结构共享：有效 Command 同步发布新 Root，旧 Snapshot 保持稳定，未变化子树可复用。此前可变 JSON + 按需 Snapshot 的候选被替代，仍保存在历史来源中。每条 Command 保留前后 Root 进行观察比较；推荐 Object.is 比较观察值，子路径同值跳过、对象 / 数组新引用保守失效，不逐步深比较全表。具体更新、缓存、防御外部原地修改、存在性与跨端等值仍需验证；不可变语义不要求每步深拷贝全表，也不要求永久保留所有旧 Root。

Data / Scope 与活跃观察者跨轮存在，稳定快照可由消费者持有；Host 可自行保存业务 Baseline 和 Dirty；计数与完整 Trace 仅属于本轮 Flush Context；Validation 自管 Issues / 新鲜度；异常在清理前提取报告交 Host。V0.4 的局部不可信范围和 Health 传播被 V0.5 替代，不建立父子规则控制与链级恢复。状态所有权继续分别管理，详见 [状态所有权](l3-reactive-engine.md#l3-ownership)。

Typed Read 失败不能静默回退旧值；Missing、null、空字符串、0 与 false 分开。初始化缺失时由业务 when / Pure Function 明确跳过或返回 null，用户清空时如需清空派生值必须显式写回；跳过不会自动清旧值。不建立通用 Reaction Ready 状态机；首次激活已确认显式可配置，字段默认值与初始化 API 仍待固化。读取结果和诊断的准确 SDK 形状仍需固化。

### Scope & Identity：动态数组不是普通 splice

```text
Form Instance
└─ insuredList
   ├─ Runtime Item ID: a1
   │  ├─ age
   │  └─ guardianName
   └─ Runtime Item ID: b2
      ├─ age
      └─ guardianName

删除 a1 后：b2 的当前数组路径改变，实例身份不应串项。
字段身份方向：Scope Instance Identity + Field Definition Identity。
当前 Data Path 是可变地址，不是永久身份，也不是业务 ID。
```

详细设计包括数组插入、删除、移动、替换、嵌套 Scope、注册销毁与状态回收，以及错误、外部义务、订阅、Trace 和组件实例如何跟随身份。单次结构操作不能暴露 Data 与身份映射的半完成状态；执行前取消已删除 Scope 的过期任务。必须用兄弟项隔离、重排、替换和删除后异步结果等用例验证。

V0.6 明确位置事实存为父 Scope + 相对集合位置 + 本层位置，完整路径按需向上解析；父被保人移动时，不重写其全部受益人的绝对路径。相对年龄观察沿同一 ScopeId 比较，固定索引观察沿同一物理位置比较。结构操作前推荐短暂保存受影响集合的旧位置视图，提交后完成比较即释放，不能只保留同一个可变 Registry 引用；旧 ScopeChange 不传入 pending 或沿规则链传播。整数组替换默认重建是推荐，具体身份协调须验收，见 [Scope Index 与旧视图](l3-reactive-engine.md#l3-scope-index)。

### Dependency & Rules：纯派生与修改分开

```diagram
{
  "id":"figure-dependency",
  "title":"图 4 · Dependency Plan → Subscription：同一输入参与不同消费者",
  "rows":[
    [{"title":"L1 · 年龄与监护人姓名","body":"isMinor = age < 18；Constraint when + assert；View 动态 Props"}],
    [{"title":"L2 · 递归分析与静态计划","body":"Constraint 观察 age + guardianName；父 View 观察 age；保留 Scope 模式"}],
    [{"title":"L3 · Data + Reactive Engine","body":"按状态来源、引用与真实实例匹配已激活订阅","major":true}],
    [{"title":"guardianName 的 View Props","body":"L4 随挂载订阅；父级条件观察者负责创建子视图"},{"title":"guardianName 的 Constraint","body":"L3 随 Scope 激活；未成年姓名非空，独立于 View 生命周期"}]
  ],
  "arrows":["↓","↓","↕"],
  "note":"纯表达式自身没有订阅生命周期，读取不必然触发业务行为。图中的 required 不新增数据字段；校验状态变化不触发只观察 Data 的 Reaction。需要保存计算值时另行声明 Command。"
}
```

高频、确定性的展示派生优先纯计算。表达式不发请求、埋点或任意修改其他数据；业务字段需要修改时使用 Command / Reaction。

| 设计点 | 方向与待验证项 |
| --- | --- |
| 依赖追踪 | 消费 L2 静态 Dependency Plan，统一按状态来源、引用与实例匹配；定义缓存失效 |
| 全量与增量 | 初始化建立业务观察关系，L4 按挂载激活 View；首次校验与读取有独立入口 |
| watch / when | Reaction 只用显式 watch；Constraint 按使用位置合并 when / assert 或 external watch；失效不等于请求 |
| then 顺序 | 同步、有序 Command；同目标后写覆盖，不默认引入 priority 或冲突仲裁 DSL |
| Reaction 交付 | 最新状态收敛；同实例 pending 合并，执行后再次失效可重新入队；每次执行读取最新 Data |
| 循环与成本 | 纯表达式环尽早诊断；同值短路、单实例与本轮次数保护；潜在规则环不等于死循环 |
| 等值与索引 | 一次对象替换命中已有观察子树，再比较前后观察值；Object.is / Trie 模板为推荐，索引命中不等于失效 |

纯表达式本身不写数据，因此不能沿用最初稿“多个纯派生规则写同目标一律报错”的假设。对 Command / Reaction 的潜在写入可以做诊断，但合理的有序覆盖不能自动当作非法协议。

L3 概念入口为 read / dispatch / subscribe，支持 Prepared 计划 + Scope，或 Host / 调试器给出的明确引用；释放函数随调用方生命周期管理。正式状态引用、Prepared Expression 求值和快照协议仍待固化，不据此向 L1 增加 Validation Reference。只改变 Issue 不使 Data-only Reaction 重跑；新 Reaction Command 继续经同一数据入口传播。有效 Change 与 Flush 的职责已明确，底层路径 / 事件编码、ID 与正式接口仍需固化。

### Command & Flush：即时修改与独立收敛边界

```diagram
{
  "id":"figure-transaction",
  "title":"图 5 · Command / Flush：即时数据更新与联动收敛",
  "flow":true,
  "rows":[
    [{"title":"Operation → Command","body":"保留来源与显式动作次数；batch / then 按序执行"},{"title":"即时更新 Data + Scope","body":"不可变 Root、结构共享；单次结构操作内部一致"},{"title":"索引候选 → 观察值比较","body":"临时前后 Data / Scope；只投递失效标识与必要 ChangeId"}],
    [{"title":"延迟启动同步 Flush","body":"逐 Command 检测与 pending 去重；执行时读最新 Data / Scope，内部写回留在本轮"},{"title":"收敛或保护停止","body":"同值短路、次数预算；可隔离错误继续独立行为；超限整体停止，保留已写数据"},{"title":"追踪 / 通知 / 释放","body":"临时有序事实与 Change 来源；异常提取报告；通知重入待定","major":true}]
  ],
  "arrows":["↓"],
  "note":"取代早期候选树 / 整组原子提交议题图，保留原图 ID。Flush 不提交或回滚整轮数据；默认 batch 非原子。单命令可隔离错误继续、整体熔断已确认；精确排序、通知重入和 Pending 再触发仍待固化。"
}
```

Command 保留修改意图、顺序与次数。两次添加被保人不能因为目标路径相同就合并成一次；一次替换对象也不一定只产生一条变化引用。

来源不改变检测语义：Host 导入、用户输入、Reaction 写回都在每条 Command 内一致更新 Data / Scope、查候选并比较逻辑观察值；不建立派生字段所有权。Trie / 路径模板只定位已有观察路径，父对象导入不需遍历全部数据字段。Reaction、Validation、View、Host 共享数据检测，执行完成 / 中止 / Error 事件经独立事件观察或 Trace，不进入 Data Trie。完整前后读取、索引、逐命令合并轨迹见 [L3 数据变更链路](l3-reactive-engine.md#l3-change-detection)。

统一订阅不统一完成条件：Renderer 可读取最新状态，Reaction 按最新状态收敛，待执行时合并重复失效；需要每次执行的新增或副作用应明确发出 Command / Host 事件。V1 延迟一次启动 Flush，同步执行直到结束；多个外部 Operation 可合并一轮，内部联动留在当前轮，后续异步操作另起一轮。数据即时写入不保证 UI 先绘制，也不冻结所有订阅的同步交付顺序，见 [跨层时序](dependency-reactivity.md#dependency-scheduling) 和 [L3 归属边界](l3-reactive-engine.md#l3-flush)。

应验证即时读取与旧快照稳定、单次结构操作的身份一致、pending 合并、同轮级联、显式动作次数、预算停止及异常恢复。默认 batch 与 then[] 有序实时写入，不默认整体回滚，允许存在尚未联动完成的工作态；业务不合法由 Validation 报告，不能当作结构性执行失败。可隔离错误不自动阻断后续独立子命令和规则，后续触发只看真实 Change / 自身 Watch，不检查上游成功状态；精确错误类型和接口继续固化。

外部 I/O 由 Host 管理。`array.insert` / `array.move` 的位置语法及准确失败契约仍见 L1 待固化清单。超限统一中止整个 Flush，不能自动把遗留任务搬到下一轮无限重试，也不能把中止记成正常收敛。V0.5 不做局部熔断、下游禁用或 Health 影响链；Pending / 再触发与 Submit 衔接仍待定，详见 [错误与整体熔断](l3-reactive-engine.md#l3-errors)。

### Validation：合法性不能只依赖 UI {#validation}

Runtime 管理完整根 Schema、内部 / 外部 Constraint、来源 Issues 和有效性。V0.7 以完整 Schema + 本轮增量 Constraint + 字段聚合明确执行方向，物料经既有 Binding 读取聚合结果，不新建 `validationBind`、`errorBind` 或独立 ValidationMetadata DSL。

- UI 负责必填提示、错误展示和校验中反馈；这些投影不能替代独立的数据约束。
- Host 执行外部校验并上报，Runtime 按实例与当前有效依赖接收结论；unverified、pending、error 不可冒充 valid。
- Data Change 阶段复用依赖索引登记去重 Pending，正常 Reaction 收敛后执行完整根 Schema / 本轮 Constraint；前置在本轮检查并必要重排，不建结果 PubSub 或通用异步 DAG。
- 推荐按 Source 原子替换 Issue，以稳定 Scope + 相对路径派生字段聚合；对象 / 数组可报告容器错误。通知只关注实际聚合变化，内部执行完备性仍需维护。
- 隐藏不自动清空或排除业务字段，也不删除共享约束；具体输出语义由数据契约与 Host 决定。
- Readiness 需要相关 Reaction 可靠收敛，且 Schema、内部约束、当前适用且必需的外部约束与输出有效性满足要求；异常轮次如何影响提交仍待完成契约，不建立局部受损范围传播，不替代 Host 的权限、风控和真实提交。

完整 Schema 不自动拆分局部单元；Adapter 统一标准化 Issue，Web 复用编译函数、Dart 用等价契约实现。消息模板 + 局部覆盖、Source Store / 字段索引为推荐；requires / 消息覆盖语法、严格缺失前置的增量兼容、完整返回与跨端性能尚待验证。完整职责、取舍、19 项来源状态和 16 个案例见 [L3 校验专题](l3-validation.md)。

### 外部竞态与表单生命周期

```text
destination = JP → Host 发起 requestQuote(JP)  // 请求 A
destination = SG → Host 发起 requestQuote(SG)  // 请求 B

A 晚于 B 返回：
  Host 检查它仍适用于当前实例和依赖，不能覆盖当前报价。
  若结果只供展示，留在外部状态；若要写业务字段，显式提交 Command。
  外部校验报告还要由 Runtime 检查登记义务与依赖有效性。
```

请求取消、去重、超时、重试、Loading/Error 和 Cache 归 Host；不能为恢复原图而把 Resource Manager 放回 Runtime。实例销毁、重初始化、数组项替换、同值往返和 ABA 等有效性问题仍需跨层共同验证。

| 生命周期操作 | 语义 / 设计边界 | 仍需设计 |
| --- | --- | --- |
| 实例装载 | Host 初始输入 / 缺失默认语义；创建 Scope 与规则，新实例按 runOnActivate 首次运行 | 激活默认值、稳定快照与实例 / 完成 SDK；无自动业务基准 |
| Update | 修改当前 Working Data | 批量边界、诊断、失败与通知契约 |
| 新外部数据 / 实例替换 | Host 明确选择普通 Command 或真实替换实例；不把已有实例当作首次激活重跑 | 身份、订阅、校验与外部义务的生命周期 |
| Host Reset 便捷封装 | Host 根据业务意图生成普通 Command，已有规则只响应有效 Watch 变化 | 业务 Baseline / Dirty 策略由 Host 决定；不设 Runtime 重算模式 |
| 实例销毁（SDK 名称待设计） | 释放实例、订阅及适用性关联 | 与 Host 请求和 Renderer 销毁的协作 |

Host 管异步加载和防止迟到输入覆盖编辑；Runtime 只装载明确输入、管理真实实例并提供稳定 snapshot。Host 可在所需联动完成后自选快照为业务基准，Dirty 和 Reset 策略也归 Host。Reset 仅生成普通恢复 Command，Watch 未变就不新增已有规则任务；不增加主动重算或编辑来源分类。当前 Command 的 previousRoot 与 Flush Trace 继续只为比较和诊断，详见 [实例初始化与业务基准](l3-reactive-engine.md#l3-initialization-baseline)。

**本层交付物与验收：**不可变数据与状态模型、身份规范、Command / 订阅 / 快照 API、Flush 时序、预算、可隔离错误契约与整体熔断、Outcome / Trace、校验有效性及生命周期契约。重点验证多级联动、兄弟项隔离、重排替换、同目标有序覆盖、过期结果、重初始化与异常恢复；[C01–C18](l3-reactive-engine.md#l3-acceptance) 是设计验收，尚非实现通过记录。

## L4 · Renderer：呈现与交互适配层 {#renderer}

Renderer 应当轻量，但不能薄到只有 `componentMap[name]`。真实接入还包括值适配、输入事件、校验展示、订阅、焦点、平台与组件生命周期。

### 服务对象与主要模块

| 模块 | 职责 |
| --- | --- |
| Form Renderer | 消费当前 Profile 的 ViewNode，组织整体物料树 |
| Binding Adapter / Field Controller | 连接数据端口、Field State、输入和受控修改 |
| Material Registry Adapter | 将确定的物料契约与版本映射到平台实现 |
| Container / Slot Composition | 组合布局、分组、步骤、弹层及复合物料 |
| Scope Adapter | 关联重复区块的实例身份与词法上下文 |
| Platform Adapter | 处理框架订阅、挂载销毁、输入法及原生交互差异 |

ViewNode 只有 MaterialNode、ScopeNode 和 TemplateUse。具名 Profile 直接对应 ViewNode，不使用 `entry` 包装。Template 静态 `$use`，参数传 Typed DataReference；共享结构不共享组件实例、UI State 或额外业务 Store。

### View 订阅的激活与释放

采用 L2 编译 + L4 挂载订阅：L4 通过 L3 的统一 API 使用 Prepared View 计划，不自行解析 AST；L3 不在初始化时预注册所有 View。全部预注册会增加隐藏和虚拟节点成本，各 Renderer 自行分析则重复编译并造成跨端语义差异，完整比较见 [跨层视图方案](dependency-reactivity.md#dependency-view)。

Mount 绑定 Scope、建立订阅并取得最新状态；Update 重读或在计划 / Scope 改绑时替换旧订阅；Unmount 释放 View 观察与局部状态。父级可见性观察者必须存活才能创建尚未挂载的子树；虚拟列表只订阅可见行，L3 业务规则始终按实例生命周期生效。Profile 切换不重建共享校验义务。

动态 Props 经统一 Prepared 求值能力或共享契约读取；框架 Store Adapter 保证订阅、首次读取与改绑交接不漏更新。节点合并还是属性拆分、快照一致性与正式表达式读取 API 待固化。FieldController 是这个统一入口的上层接入适配，不是第二个匹配引擎。

### 字段接入接口需要解决什么

以下保留最初架构稿中的接口讨论方式，作为 L3/L4 协作草图，不是正式 SDK 或新增 L1 类型：

```typescript
interface FieldController<T> {
  readonly id: string;
  getSnapshot(): FieldSnapshot<T>;
  subscribe(listener: () => void): () => void;
  change(value: T): void;
  blur(): void;
}
```

需要决定快照的值与校验状态、只读/编辑能力、复合端口变更、错误传播、订阅注销及实例稳定性。`change` 转成受控数据修改，`blur` 的元状态行为待 API 固化；组件不能直接写内部 Store。

普通输入通过 Binding Port 更新，不额外重复要求 `on.change → form.command` 写入。业务按钮使用受限 `form.command` / `host.emit`；容器 Material 自主管理开闭、Portal、焦点和动画，不引入核心 `view.present/dismiss`。

### 关键取舍与跨端一致性

| 问题 | 方向 | 原因 |
| --- | --- | --- |
| 通用视图与分端呈现 | 共享业务定义，按 Profile 选择物料树 | 语义一致，同时允许平台体验不同 |
| 组件直连 Runtime | 经受控 Binding / Adapter 接入 | 不暴露依赖图和可变 Store |
| Renderer 保存字段值 | 不保存第二份权威数据 | 防止状态分裂 |
| Renderer 局部状态 | 允许输入法组合态、焦点、临时选择和开闭 | 必须定义交付/取消边界，不能成为隐式业务状态 |
| 组件与字段关系 | 不要求一一对应 | 支持多端口组合控件和只读摘要 |
| 更新方式 | 字段 / 端口订阅或 Selector，具体策略待验证 | 避免无关的全表更新 |
| 首版多端 | 先验证主目标端，再做同语义契约测试 | 控制交付成本，避免只统一外观 |

| 必须一致 | 允许不同 |
| --- | --- |
| 值类型、Reference、序列化与提交结构 | 组件视觉、布局与动画 |
| 共享 Constraint / Reaction 的业务结果 | 错误和 Loading 的展示方式 |
| 数组身份与数据操作语义 | 框架的组件实例实现 |
| 当前适用规则与 Field State 的消费含义 | 平台原生控件和局部交互 |

跨端首先要求同一数据、上下文与共享规则产生一致业务结果。Web 与 Flutter 不必复用同一源码，也不追求像素相同；执行实现差异用契约测试约束。

**本层交付物与验收：**Renderer / Binding / Platform Adapter Contract、Profile 与模板实例化、组件身份与卸载规范、跨端 Golden Tests。验证隐藏不删数据、Profile 切换不重放初始化、输入不重复写入及复合控件端口一致性。

## Material：物料体系与 UI 扩展 {#materials}

物料不是执行链中的单一层。设计器需要元信息，L2 检查 Manifest，Renderer 加载平台实现。基础物料、容器和领域组件共享同一套受控契约。

### 物料范围

| 类别 | 示例 | 主要价值 |
| --- | --- | --- |
| 基础字段与展示 | Input、Select、DatePicker、摘要 | 数据绑定与反馈 |
| 结构与容器 | Section、Tabs、Steps、Modal、Drawer、BottomSheet | 通过 Slots 组织视图，自管局部 UI State |
| 领域业务物料 | 证件上传、被保人卡片、地区选择、日期范围 | 封装交互，明确业务值交付与多端口绑定 |

### Manifest 与平台实现分开

以下是现行 L1 的契约方向，端口子类型与版本解析仍需正式规范固化：

```typescript
interface MaterialManifest {
  id: string;
  version: string;
  propsSchema?: JsonSchema;
  bindings?: Record<string, BindingPortContract>;
  slots?: Record<string, SlotContract>;
  events?: Record<string, EventContract>;
}
```

平台组件实现、编辑器属性面板与发布加载信息归注册/工具体系，不因可复用就都加入 FormDefinition。Capability Registry 可以共同治理 Material 与 Pure Function 资产，但二者保留不同契约与执行职责；Host Services 在应用中注入，不强制托管到平台，也不合并成通用 UI Material。

纯函数不承担物料 UI 或校验状态；复杂同步判断可由 Constraint 调用领域 Pure Function，网络与副作用留给 Host。Manifest 只能声明契约，纯净性、端口行为与跨端语义仍需代码审查、契约测试和必要防护。

| 契约 | 需要设计与验证的内容 |
| --- | --- |
| Props | Props Schema、递归 ValueSpec、输入限制与业务校验的区别 |
| Binding Ports | 值类型、单/多端口、只读/编辑能力、复合修改及错误传播 |
| Slots | 槽位名称、基数、节点组合、默认插槽简写及平台兼容 |
| Event Ports | Payload Schema、有效 Event Reference、捕获上下文与受限 Intent |
| Field State 消费 | 沿既有 Binding 展示字段、对象摘要、数组项 Issues，不建立独立校验 DSL |
| Version / Platform | 确定性版本锁定、平台实现匹配、缺失能力诊断与升级规则 |

物料的输入 `maxLength` 是交互限制，真正的姓名长度规则仍在 Schema / Constraint。复杂组件的关键业务值不能长期藏在组件内部。

| 取舍 | 方向 |
| --- | --- |
| 能否访问 Runtime 内部 | 不可以，通过受控接口协作 |
| 是否支持复杂领域组件 | 支持，但要求明确 Props / Binding / Slot / Event 契约 |
| 是否建设完整插件生命周期 | 按真实接入需求设计最小生命周期 |
| 物料内部远程需求 | 注入 Host Services，Host 管请求与授权 |
| 是否默认全动态加载 | 根据发布模式决定，不预设为默认 |
| 是否建设独立物料市场 | 第一阶段不作为前置条件 |

**本层交付物与验收：**Manifest 类型与检查、注册/版本解析、平台实现接入、作者元信息和兼容测试；覆盖日期范围多端口、容器 Slots、上传回写、错误展示及缺失平台实现。

## Host / View Adapter：外部能力与业务集成 {#capabilities}

本节保留最初 Capability 章节的接入问题与锚点，按当前职责更新：请求、取消、Loading / Error / Retry / Cache、上传和提交属于 Host。Runtime 管理内部状态及外部校验结论的有效性，不执行网络流程。

```diagram
{
  "id":"figure-host",
  "title":"图 6 · Host Integration：业务请求与受控回写",
  "rows":[
    [{"title":"Host 观察稳定数据 / 接收语义事件","body":"订阅当前数据，或接收 host.emit；决定是否发起业务操作"}],
    [{"title":"Host Adapter / 注入服务","body":"参数映射、鉴权、请求、取消、缓存、重试与超时"}],
    [{"title":"Business Service / Backend","body":"业务计算、权限、权威校验与持久化"}],
    [{"title":"Host 检查结果适用性","body":"核对实例、依赖与请求上下文，处理乱序和过期结果","major":true}],
    [{"title":"仅展示的外部结果","body":"选项、报价、Loading 等由 View / Material 消费"},{"title":"修改数据或报告校验","body":"显式 Command 写回；外部义务报告另经 Runtime 有效性检查"}]
  ],
  "arrows":["↓","↓","↓ Result","↓"],
  "note":"替代最初稿 Runtime → Capability → Resource Manager 的调度建议。Host 业务操作不是核心 Command；Command 只修改 Form Data。"
}
```

### 三条集成路径

| 路径 | Definition / 核心表达 | 外部负责 |
| --- | --- | --- |
| 外部 Constraint | 声明义务、依赖、目标与提交必需性 | 注册校验器、请求、上报结果与状态 |
| 用户触发业务 | Material Event → `host.emit` | 业务流程、权限、持久化与提交 |
| 物料内部服务 | Binding / Props + 外部服务契约 | 远端选项、文件上传等私有需求 |

Host 实现一般在运行时注册。L2 从外部 Constraint、`host.emit` 和 Material Manifest 声明的服务提取 Requirements；HostContract 可选，用于提前检查名称与 Payload。必需外部校验器未就绪时不能绕过提交义务；一般事件缺失的阻断时机和可选性继续固化。物料未声明的内部服务依赖无法由 L2 静态发现，见 [Host 注册与依赖边界](l2-preparation.md#l2-host)。

| 能力 | 典型场景 | 责任交接 |
| --- | --- | --- |
| Query / Resource | 城市列表、报价、搜索候选 | Host 观察依赖并管理结果；用户选择经 Binding / Command 写回 |
| Upload | 证件采集、文件上传 | 外部管理上传，最终业务值受控交付 |
| Business Operation | 保存草稿、提交录单、确认报价 | Host 执行，不能当作核心数据 Command |
| Context Provider | 用户、地区、渠道 | 提供只读上下文，不变成第二个数据写入入口 |
| External Validation | 唯一性、身份、资格 | Host 执行，Runtime 接受当前有效义务事实并汇总 Readiness |

插件不能无约束地拿到可变 Store；通过参数、只读快照、受控回写和显式报告协作。客户端能力注册不替代服务端权限验证。

分步填写、局部弹层与异步查询不需要完整工作流引擎。审批、核保和支付等长流程由 Host 集成外部 Workflow Service，不能为此向 L1 增加通用请求/工作流 DSL。

**本层交付物与验收：**Validator / Event / Host Services 契约、上下文与授权约束、回写和过期结果规则、错误恢复及提交一致性测试；覆盖后发先至、销毁后响应、数组项替换、同值往返和服务失败。

## Tooling：设计器、调试器、发布与治理 {#tooling}

先验证定义与运行时语义，再投入复杂拖拽设计器。第一阶段优先 Definition Editor、Preview、Diagnostics 和 Runtime Devtools，降低模型验证成本；以下是建设路线，不代表工具已经实现。

| 阶段 | 工具 | 直接价值 |
| --- | --- | --- |
| 一 | Definition Editor、Preview、Diagnostics | 快速验证配置、协议与适配 |
| 二 | Rule Builder、Runtime Trace | 解释读取、修改、触发、校验和失效因果 |
| 三 | 可视化 Form Studio | 降低业务作者门槛，组合数据与视图编辑体验 |
| 四 | Form / Capability Registry、Release Console | 表单及 Material / Pure Function 资产治理、依赖锁定、迁移与回滚 |

### 版本从第一阶段纳入设计

| 版本对象 | 意义 |
| --- | --- |
| Definition Version | 某份业务定义的修订，与协议独立 |
| Protocol Version | L1 声明格式与语义 |
| Compiler Version | L2 构建追踪与缓存失效 |
| Prepared Format Version | 准备产物的读取契约 / ABI，与 L1 独立 |
| Runtime Compatibility | 表单需要的执行能力与兼容范围 |
| Material / Pure Function Versions | 依赖契约及跨端实现的确定性选择 |
| Host Integration API Version | 宿主 SDK 接入契约，不强制每个 Handler 平台化 |
| Data Contract Version | 已保存草稿与输出数据的结构版本 |

发布产物不可变、运行中会话固定所用定义、配置迁移与历史数据迁移分开，是治理基线。Form Registry、Capability Registry、Compiler 与 Release Management 分工；Git 管源码、CI 构建测试、制品仓库存不可变 Package，平台记录 Manifest、摘要和发布状态。版本与摘要共同锁定依赖，不使用不受控的 latest。具体锁字段、ABI 兼容、迁移策略和工具仍需固化，见 [构建与发布](l2-preparation.md#l2-release)。

### 工程质量与可观测性

| 维度 | 要设计与验收的内容 |
| --- | --- |
| 静态质量 | 引用、类型、Scope、模板、端口、版本、表达式环与成本诊断 |
| Runtime 质量 | 稳定身份、即时不可变更新、同轮级联、等值、预算、可隔离错误继续与整体熔断后的再触发 |
| Host 集成 | 远程竞态、报告有效性、权限、业务恢复和真实提交 |
| 跨端契约 | 同输入、上下文和共享规则产生一致结果的 Golden Tests |
| 发布与观测 | 不可变产物、灰度/回滚、因果 Trace、性能指标、脱敏日志 |

**本层交付物：**作者工作流、诊断/Trace 模型、版本与发布规范、兼容矩阵、性能基准和真实业务回归集。Tooling 不应成为线上引擎运行的必需依赖。

Trace V1 采用本轮有序行为记录、实际 Change 与最小 triggeredBy 来源，生产热路径不实时建因果图。正常轮次释放完整记录，异常先提取受限报告；Devtools 可独立保存并事后构建时间线 / 规则环。执行预算与记录预算分别控制，截断不停止循环保护；精确 Replay 和历史数据恢复延期，详见 [Trace 与预算](l3-reactive-engine.md#l3-trace)。

## 完整案例：保险投保表单的一次交互 {#flow}

仍以目的地、投保人、被保人列表、监护人条件和动态报价贯穿各层。图中恢复从初始化到业务回写的完整交互路径，并把外部请求归属更新为 Host。

```diagram
{
  "id":"figure-interaction",
  "title":"图 7 · Interaction Timeline：投保录入的端到端路径",
  "rows":[
    [{"title":"01 · 准备定义并初始化","body":"Host 明确初始数据，L3 用 Prepared 建身份与规则，新实例按 runOnActivate；Host 按需读取 snapshot 自选业务基准"}],
    [{"title":"02 · 建立可观察状态","body":"明确入口处理初始校验；L4 挂载年龄字段与父条件观察者，读取数据、Props 和 Field State"}],
    [{"title":"03 · 用户修改被保人年龄","body":"Binding Adapter 提交 Command，即时发布新 Root 与一致身份；有效变化匹配观察者"}],
    [{"title":"04 · 联动收敛与消费者响应","body":"Reaction pending 合并并同步收敛；随后根 Schema / 本轮 Constraint 校验，字段 Issue 聚合；父条件按订阅响应"}],
    [{"title":"05 · Host 决定是否重新报价","body":"Host 自主管理请求，检查返回结果仍适用于当前实例和依赖"}],
    [{"title":"06 · 展示报价 / 受控回写 / 提交","body":"结果按适用性展示或 Command 回写；相关联动可信、校验有效后构建输出，再由 Host 核对许可提交"}]
  ],
  "arrows":["↓","↓","↓","↓","↓"],
  "note":"图示反映即时写入与独立 Flush；可隔离错误继续，预算超限整轮停止；通知重入与 SDK 方法名待固化。父条件成立后 L4 挂载监护人子节点并订阅；正常联动后校验方向已确认；外部请求时机、通知重入和 SDK 仍待固化。"
}
```

```text
Preparation → Prepared Form / Profile Bundle
Host        → Initialize(initialData)
Runtime     → Working Data / Scope / 注册规则 / 显式首次激活
Runtime     → 执行已入队初始规则 / 提供稳定 snapshot 与执行观察
Host        → 按需选择快照和时点 → 自行保存业务 Baseline / Dirty / Reset 策略
Renderer    ← 当前数据、Props 与 Field State

User        → Change insured.age
Renderer    → Binding Adapter → 受控 Command
Runtime     → 即时 Data Change / pending 合并 / Constraint 失效
Runtime     → 延迟启动同步 Flush / 最新状态 Reaction / 内部同轮写回
Runtime     → 正常收敛后根 Schema + 本轮 Constraint 链 → Source / 字段 Issue 聚合
Renderer    ← 按框架订阅读取最新 Data、Props、Field State 与诊断

Host        → 观察报价依赖 → Business Service
Business    → Quote Response
Host        → 适用性检查 → 外部展示，或显式 Command 回写

Host        → 执行已声明外部校验 → 上报结果
Runtime     → 检查义务与依赖有效性 → Report / Readiness / Output
Host        → 核对相关联动可信收敛、当前输出、校验与业务条件 → 实际提交
```

这条主路径不需要独立 Workflow Engine 或通用双向 View-Logic 桥接平台。内部执行失败、业务 Invalid 和网络失败要分别说明：网络失败不等于内部同步事务回滚，Host 负责请求恢复与业务补偿。

**过度设计判断：**新模块或调度机制应能提升这类主路径的可靠性、交付效率、性能或可维护性，并有可验证收益。这个标准用于控制新增抽象，不能据此删去解释已有架构的图示和设计内容。

对应的 [完整投保定义](l1/07-examples.md#sample) 与 [协议样例](../validation/index.html) 用于检查组合表达；现有候选静态检查与有界探针不代替生产事务、身份、异步和跨端实现验收。

## 六大设计方向映射到各层 {#mapping}

六个方向是贯穿各层的评审维度，不是六个新的纵向层级。

| 方向 | 主要涉及层次 | 核心问题 |
| --- | --- | --- |
| 协议灵活度与复杂度 | L1 + L2 | 简单配置简单，复杂场景能组合，扩展不破坏静态分析 |
| 逻辑编排与运行时 | L3 + Host 边界 | 内部状态如何稳定修改、观察和恢复，外部流程由谁拥有 |
| 跨端一致性 | L1 + L3 + L4 | 共享哪些规则，允许哪些 Profile / 平台差异 |
| 物料与扩展性 | Material + L4 + Host | 扩展契约明确，领域需求不侵入核心 |
| 版本兼容与演进 | L1 + L2 + Tooling | 定义、数据与依赖如何长期可用、迁移和回滚 |
| 工程治理与质量 | 所有层 | 每个关键语义可验证、可解释、可追踪 |

### 必须警惕的跨层破坏

- **协议任意 JS：**破坏纯计算、静态分析和跨端语义。
- **物料直接写 Store：**绕过受控命令、实际变化、校验失效和通知。
- **Renderer 自算业务：**造成跨端规则漂移与第二份权威数据。
- **索引不带定义/依赖版本：**破坏缓存、发布和回滚正确性。
- **外部结果不核对有效性：**将旧请求、已删除实例或过期校验当成当前事实。
- **把概念图当作已实现保证：**在未设计事务、身份或跨端契约前宣称生产验收通过。

## 架构决策与原稿演进 {#decisions}

产品范围、四层架构、唯一 Working Data、数据/视图分离和受控修改是现行边界；完整 L1 决策见 [核心决策表](l1/01-foundation.md#decisions)。2026.10.17 收敛 L2 / 平台分工、Pure Function 分类与发布锁定，见 [L2 决策](l2-preparation.md#l2-decisions)。2026.10.18 修订数据、batch、Reaction 与 Flush，并形成 Trace / 异常方向，见 [L3 决策 R01–R26](l3-reactive-engine.md#l3-decisions)。V0.5 进一步确认唯一 Prepared 执行路径、作者确认编译建议、可隔离错误继续与整体熔断，见 [跨层 D01–D22](dependency-reactivity.md#dependency-v05-decisions)。V0.6 明确变化索引与相对 Scope，见 [25 项来源记录及现行处理](l3-reactive-engine.md#l3-v06-decisions)。后续用户撤回 Runtime 业务基准和 Reset 重算，确认 [四条职责原则](l3-reactive-engine.md#l3-runtime-host-boundary)；激活默认值、稳定快照、通知 / Pending 等 SDK 仍待固化，业务编辑策略不再作为核心未决项。

本篇恢复了 [10 月 14 日完整架构稿](../history/2026-10-14/complex-dynamic-form-architecture-v1.html) 的 14 个主体议题、分层描述、图示和详细设计路线，并参考 [后续同步稿](../history/2026-10-16-before-v1-final/complex-dynamic-form-architecture-v1.html) 与现行 L1 更新职责。以下变化必须明确，不能直接把最初图中的候选机制恢复成当前规范：

| 早期稿中的表示 / 建议 | 现行处理 | 保留的设计问题 |
| --- | --- | --- |
| 独立 Resource 概念与 Runtime Resource Manager | 不进入 L1 / L3 核心；请求归 Host | 取消、竞态、失效、缓存和错误恢复仍要设计与验证 |
| 通用能力执行器 / 业务 Command | Material、Pure Function、Host 保留三类职责；平台可统一治理前两类资产 | 扩展、鉴权、版本与受控回写，不把 Registry 当 Runtime 执行器 |
| 通用 Structure / Field Controller 草图 | ViewNode 三类节点，Binding / Adapter 具体 API 待定 | 数据/UI 分离、复合端口、订阅与组件身份 |
| Profile entry、ScopeHandle 模板参数 | Profile 直接对应 ViewNode，模板传 Typed DataReference | 静态复用、词法边界、平台实例隔离 |
| 独立 Material Validation Metadata | Field State 经既有 Binding 消费，不新增 DSL | 字段、对象、数组项的状态与 Issue 展示 |
| 默认拒绝同目标写入与既定事务流水线 | 显式有序即时 Command，batch 默认非原子；同轮 Flush 收敛 | 覆盖、循环、预算、可隔离错误继续与整体熔断后的再触发 |
| 可变 JSON、每次触发独立执行、整轮候选树 | 不可变 Root 与结构共享、Reaction 最新状态合并、独立 Flush | 稳定 Snapshot、准确排序和异常影响范围 |
| 热路径因果图 / 长期正常历史 | 临时有序 Trace + Change 来源，异常上报，Devtools 派生分析 | 记录预算、参数策略和截断契约；精确 Replay 延期 |
| 将读取等同于触发、各规则 / View 自建观察系统 | L2 按位置编译，L3 统一匹配，L4 按挂载订阅 | 消费者各自的业务策略、首次执行与调度契约 |
| External Constraint.dependsOn | 现行草案统一为 watch，并合并 when 的读取 | 失效与 Host 请求分离，正式协议版本迁移待固化 |
| 原始配置与 Prepared 双轨执行、分析结果替代 watch | L3 唯一 Prepared 入口；显式 watch 由作者确认，建议回写后重编 | ABI、编辑增量与来源映射继续固化 |
| 局部 Health / 失败下游禁用 / 局部熔断 | 可隔离 Command 错误继续独立行为，预算超限停止整个 Flush | 不维护父子控制和局部影响链；Pending / 再触发待确认 |
| 每个观察者保存历史参数 / 持久绝对 Scope 路径 | Command 内前后 Root / 旧位置比较，相对 Scope Index 按需解析 | 不沿链传 ScopeChange；局部视图与索引真实性能需验收 |
| Runtime 自动建 Baseline、为 Reset 主动重算已有规则 | Host 自选稳定快照定义基准 / Dirty / Reset；恢复走普通 Command | 无有效 Watch 变化不重跑；runOnActivate 仅新实例；旧方案与理由保留归档 |

后续决策应记录目标、前提、替代方案、代价与重新评估条件；区分已收敛职责、待固化规范与待验证实现。历史阅读页同步统一纯函数术语，原始字节保存在 [来源归档](../history/README.md#l2-integration) 供追溯；现行架构通过正文和图示同时反映演进。

## 逐层讨论与详细设计路线 {#roadmap}

每个阶段都需要输出“设计什么、交付什么、怎样验收”，不能只列层名。逻辑执行顺序是 L1 → L2 → L3 → L4；详细设计需要反向验证，Prepared 结构和 Runtime 执行契约会迭代配合。

```diagram
{
  "id":"figure-roadmap",
  "title":"详细设计路线 · 六组工作及其交付物",
  "rows":[
    [{"title":"01 · Definition 规范固化","body":"将已收敛语义转为可验收规范，补齐位置命令、Union、类型兼容与版本规则","items":["Canonical Type / JSON Schema","Pure Function / Material Contract","正反例与兼容规则"]}],
    [{"title":"02 · Runtime 数据模型与状态管理","body":"按不可变 Root / 结构共享基线设计 Field State、Scope / Identity、快照、初始化与生命周期","items":["数据结构与不变量","状态 / 订阅 / 快照 API","生命周期与身份验收"]}],
    [{"title":"03 · Runtime 计算、Command 与 Flush","body":"按即时更新 / 最新状态收敛基线固化错误类型、通知重入、排序与整体停止后 Pending","items":["独立命令 / 规则与轮次结果","预算 / 停止 / Trace 契约","C01–C18 与复杂联动验收"]}],
    [{"title":"04 · Preparation 静态分析与执行准备","body":"按已收敛的平台分工，结合 Runtime 需要固化可序列化产物、静态分析与 Profile 交付","items":["PreparedForm / Form Plan / View Plan","类型化依赖 / Diagnostics / Host Requirements","Capability Lock / Format / 缓存契约"]}],
    [{"title":"05 · Renderer / Material / Host","body":"设计跨端输入绑定、组件实例、物料组合与外部业务接入","items":["Adapter Contract / Manifest","Validator / Event / Host Services","跨端与集成测试"]}],
    [{"title":"06 · 版本、工具与工程治理","body":"用真实业务贯穿迁移、编辑、预览、调试、性能和发布","items":["版本与迁移模型","测试矩阵 / Trace / 基准","发布规范和实施路线"]}]
  ],
  "arrows":["↓","↓","↕ 与 Runtime 反复验证","↓","↓"],
  "note":"这是设计工作分组，不要求先实现完整 Runtime 再讨论 L2。先形成 L2 最小消费契约，随 Runtime 状态与执行需求细化 Prepared；治理从第一阶段并行纳入。"
}
```

最初稿把 Preparation 详细设计放在 Runtime 之后，是为了避免先建设无用的重型编译器。当前仍保留这个取舍理由：先确认执行需要的事实，再固化索引和准备结构；同时让 L1、L2 与 L3 用代表性用例相互验证。

### 每个专题的统一讨论模板

| 维度 | 必须回答的问题 |
| --- | --- |
| 目标与对象 | 解决什么问题？为谁服务？有哪些非目标？ |
| 模型与职责 | 实体、状态、不变量是什么？谁拥有、谁消费？ |
| 接口与数据流 | 输入、输出、生命周期、版本和错误契约是什么？ |
| 核心机制 | 典型业务流程、时序、算法与伪代码如何表达？ |
| 方案取舍 | 选择什么，为什么，替代方案的成本是什么？ |
| 验收与演进 | 边界、失败路径、性能、测试和后续变化怎样验证？ |

下一步推进 [L1 正式发布前的固化与验收](l1/08-decisions-release.md#release) 及 [L2 能力 / 编译 / 发布契约交付](l2-preparation.md#l2-delivery)，用 Runtime 状态 / 执行需求验证 Prepared 最小结构。具体问题分别保留在 [L1 边界清单](l1/08-decisions-release.md#boundaries) 与 [L2 待固化接口](l2-preparation.md#l2-decisions)，不将设计路线误记为已经完成的实现。

依赖与订阅按 [跨层验收集](dependency-reactivity.md#dependency-acceptance) 确认位置矩阵、最小计划与 L4 挂载；L3 下一步可用 [V0.6 的 16 个场景](l3-reactive-engine.md#l3-v06-acceptance) 验证候选索引 → 前后 Data / Scope → 失效的闭环，再做性能基准，并验证 Host 恢复 Command 无有效依赖变化不重跑、稳定快照与新实例激活，再补通知、排序、Pending 与异常轮次的 Validation / Submit 衔接；校验的正常路径、字段聚合与异步有效性已进入 [L3 校验专题](l3-validation.md)，优先验证仅后置进入增量 Pending 的缺失前置问题；[验收与未决项](l3-reactive-engine.md#l3-acceptance) 不重开局部 Health 传播。跨层来源见 [2026.10.17 归档](../history/README.md#dependency-integration)，本轮原件与整合前完整正文见 [2026.10.18 归档](../history/README.md#l3-integration)。完整层级、模型、依赖、修改流程和 Host 设计继续保留，图文同步反映替代关系。

V0.5 附件原标日期为 2026.10.18，于 2026.10.19 整合，原始字节与本次修改前正文见 [V0.5 归档](../history/README.md#protocol-runtime-v05-integration)。
