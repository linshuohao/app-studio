# 生命周期与多视图交付

> L1 V1.0 架构与语义决策正文；正式类型、Schema 与发布验收状态见各节。

## 初始化、更新、重初始化与提交 {#lifecycle}

> 状态：已收敛

| 操作 | 语义约束 |
| --- | --- |
| Initialize | 创建当前 Form 实例基线；Host 数据优先，缺失位置按规则补默认值 |
| Update | 向当前 Working Data 提交受控数据修改；不是重新初始化 |
| Reinitialize | 用新的外部初始数据建立新的当前基线；不假扮逐字段用户编辑 |
| Reset | 回到当前初始化基线，不是必然回到第一次加载的旧基线 |
| Submit / Readiness | 相关联动可信收敛、内外约束与输出完整性符合要求后，由 Host 执行真实提交 |

Definition 不增加 `onInit`、`onReset`、`beforeSubmit` 等通用生命周期脚本。宿主 API 的具体返回值或事务流程属于 L3/Host 实现，但上述生命周期的语义差异必须保持。

Runtime 随 Form / Scope 激活业务 Reaction 与 Constraint；首次校验、主动校验与 Reaction 初始化策略分别有明确入口，不能把 subscribe 等同于首次执行。重初始化和销毁需要处理旧订阅与外部结果适用性，不能只替换 Data 而保留无效实例关联。

Initialize / 新 Scope 激活 / Reset 的首次 Reaction 具体时机仍待决策；缺失与清空由业务规则处理，不增加通用 Reaction Ready 状态机。不能因 Flush 已结束便视为可提交；异常 / 整体预算停止、Pending 再触发与 Validation / Submit 的衔接见 [L3 消费者边界](../l3-reactive-engine.md#l3-consumers)，不再采用局部 Health 传播候选。

## 多 Profile 与按需交付 {#profiles}

> 状态：已收敛

View Profile 表达同一业务数据在不同终端或场景下采用不同的物料树。服务端或 L2 可以按请求只准备当前 Profile 的入口与其静态引用依赖，但共享 Data Schema、Constraint、Reaction 不能仅因为某字段不可见就被裁剪掉。

Profile 切换只释放旧视图订阅并挂载新视图订阅及局部 UI 状态；同一 FormRuntime 的业务规则不随 View 切换反复注册或销毁。隐藏、虚拟列表未挂载与数据 / 校验有效性属于不同生命周期，见 [跨层激活归属](../dependency-reactivity.md#dependency-layers)。

**Profile 是选择入口，不是复制 Form Definition**

```json
{
  "views": {
    "expanded": {
      "$use": "expanded-form"
    },
    "compact": {
      "$use": "compact-form"
    }
  }
}
```
