# L3 Reactive Engine：数据更新、Flush 与异常诊断

本篇在 L3 V0.4 的 20 节、R01–R26 与 C01–C18 基础上，整合 V0.5 对 Prepared 唯一入口、可隔离错误继续、整体 Flush 熔断及缺失值的修订。旧局部 Health 传播候选已被替代，修订理由与原件保留追溯。来源状态、当前确认和未决事项分别表达；没有冻结正式接口，也不表示运行时已经实现。整体职责见 [设计者指南](architecture.md#runtime)，渐进理解见 [使用与开发指南](usage-guide.md#usage-updates)。

## 执行基线与设计状态 {#l3-baseline}

核心路径是：外部 Operation 发出 Command → Working Data 即时更新 → 有效变化使相关消费者失效 → 合并待执行 Reaction 实例 → 延迟启动一次 Flush → 同步执行到收敛或安全停止。Reaction 写回继续进入当前 Flush；前轮结束后到达的 Host 异步结果形成新的失效和轮次。

| 状态 | 内容 |
| --- | --- |
| 已确认 | L3 只消费 PreparedForm；不可变 Working Data / 即时 Command / 非原子 batch；最新状态合并与同轮级联；延迟启动同步 Flush；可隔离错误继续独立命令和规则；超限整体熔断；临时线性 Trace 与最小来源；首次入队建立 Context；缺失值由业务规则处理 |
| 已确认方向 | Devtools 可独立观察并保存执行历史，开启与关闭不改变语义 |
| 推荐 | 稳定规则顺序与首次入队顺序；Watch / Write 静态 SCC 的具体算法；Trace 溢出保留起点与尾部；编译 Source Map |
| 待决策 | 整体熔断后 Pending 与再触发；同步通知重入；精确排序；初始化 / 新 Scope / Reset 首次 Reaction；Validation / Submit 完成边界；准确错误分类和记录接口 |
| 待实现标定 | 执行次数、耗时、记录容量和上报限频阈值 |
| 延期 | 时间切片 / 优先级、全量或局部 Hash、高级因果图分析、历史 Snapshot 恢复与确定性 Replay |

可隔离错误继续与超限整体熔断已经确认，不再列为两种可自由选择的候选。后续优先验证初始化 / 动态 Scope 首次运行、通知交付和熔断后 Pending；记录容量、参数与阈值在实现中固化。来源中的后续会议建议和个人复核控件不改变决策状态。跨层 22 项来源决策见 [V0.5 总账](dependency-reactivity.md#dependency-v05-decisions)。

## 概念与状态所有权 {#l3-ownership}

| 概念 | 含义与身份 | 生命周期 |
| --- | --- | --- |
| Operation | 外部 dispatch 的来源，可有 Operation ID | 不独占一轮 Flush；未命中 Reaction 时可无需 Flush |
| Command | set / patch / remove / array.* / batch 数据修改意图 | 按顺序执行，保留显式动作次数 |
| Data Change | 真实有效变化；Change ID 关联目标 Scope / Path | 用于失效匹配与追踪；同值调用不虚构有效变化 |
| Reaction Instance | Reaction ID + 实际 Scope 身份 | 随 Form / Scope 激活，可在同轮多次执行 |
| Pending | 按 ReactionInstanceKey 去重的待执行集合 | 属于 Reactive Engine，执行或中止时消费 / 处理 |
| Flush | 一次消费待执行实例的过程，具有 Flush ID | 队列清空、执行错误处理或保护停止时结束 |
| Flush Context | 本轮计数、来源、临时 Trace、预算和异常标志 | 首次 Reaction 入队建立；结束后释放 |

| 所有者 | 状态 | 释放 / 更新条件 |
| --- | --- | --- |
| L3 Data / Scope | 当前不可变 Root、Baseline、数组稳定身份与索引映射 | Runtime 生命周期；有效 Command 更新当前状态 |
| Reactive Engine | 依赖索引、活跃观察者、pending、调度阶段 | 订阅 / Runtime 生命周期；不是全部放进 Context |
| Flush Context | 总执行数、单实例次数、外部重入标记、有序执行证据 | 本轮结束 / 中止；异常先提取报告 |
| Validation | Issues、校验状态、请求新鲜度及失效状态 | 独立于 Reaction Flush |
| Diagnostics / Host | 真实错误、整体预算停止原因、必要轮次报告 | Context 清理前提取；Host 可去重限频，不维护局部 Reaction Health 传播 |
| L4 / Host / Devtools | UI 状态与框架订阅、外部任务、可选历史 | 各自消费者生命周期 |

调度阶段与轮次结果分别表达。`idle / scheduled / flushing` 是阶段草图；`settled / aborted / completed_with_errors` 是结果草图，均非正式冻结枚举。可隔离错误继续其他独立行为已确认，但不能把出错或预算中止记为无异常收敛。V0.4 曾建议跨轮保存局部不可信范围，V0.5 明确不建立这套 Health、失败下游禁用或链级恢复状态；Submit 如何消费轮次结果继续单独固化。

Runtime 实例只根据兼容 PreparedForm 建立，按 Prepared Observation 匹配实际变化；不直接解释原始 L1，也不在运行时补 Watch。ABI 失败不得回退到原始定义解释器，见 [两份协议与唯一执行路径](dependency-reactivity.md#dependency-compiled-protocol)。

## 即时不可变数据与有序 Command {#l3-data}

五项不变量：

1. 业务值允许暂时不合法。清空必填项、超出年龄限制可以进入 Working Data，Validation 报告问题。
2. 有效 Command 同步生效。紧接着读取当前 Data 应看到修改，不等待 Reaction 或校验完成。
3. 每次更新形成不可变 Root，未变化子树可以结构共享；旧 Snapshot 保持稳定，不逐步深拷贝整张表单。
4. 单次数组结构操作同时保持 Data 与 Scope Identity 一致，不能暴露索引与身份映射错位的半完成状态。
5. 数据已更新不等于 Renderer 已绘制；调度延迟不保证浏览器先画一帧。

```text
读取 Snapshot v1：age = 20
执行 set age = 25
立即读取当前 Snapshot v2：age = 25
再次读取先前持有的 v1：仍为 age = 20
联动 premium 此刻可能尚未完成，需分别判断收敛状态。
```

默认 `batch` 和 Reaction 的 `then[]` 都按顺序执行 Command，各条有效修改实时生效，不默认回滚先前成功写入。该边界取代“候选数据树中完成整个 batch 后原子提交”的早期候选。业务 Invalid、Scope 已删除、非法数组位置、非法 Command 是不同结果；后几种属于结构性执行失败，单个结构操作仍须保持内部一致性。可隔离的单条 Command 失败应记录并报告，后续独立 Command 继续尝试，其他 Reaction 仍只由有效 Data Change 和自身 watch 决定；精确错误类型、返回值与无法继续的结构性条件待固化。

两条显式 `array.insert` 各执行一次，不能因目标相同被合并；待执行 Reaction 的多次失效可以合并，两者属于不同层次。同值短路放在实际变化判定中，基本值应避免无意义传播；对象不默认全量深比较，引用、替换与结构操作的准确等值契约仍待固化。

## Flush 生命周期与外部操作归属 {#l3-flush}

```diagram
{
  "id":"figure-l3-flush",
  "title":"即时写入与一轮联动收敛",
  "rows":[
    [{"title":"Operation → Command","body":"同步更新不可变 Root 与 Scope；按有效变化匹配依赖"}],
    [{"title":"idle → scheduled","body":"首次出现 pending 后安排一次启动，并建立 Context 保存起点"}],
    [{"title":"flushing · 取出实例","body":"从 pending 移除，读取最新 Data，求值 when，按序执行 then","major":true}],
    [{"title":"当前轮继续","body":"内部有效修改追加失效；同实例执行后可再次入队"},{"title":"本轮结束 / 停止","body":"队列空或整轮预算停止；可隔离错误继续，真实结果与异常报告分别记录"}],
    [{"title":"释放本轮 Context","body":"正常不留生产完整历史；异常先向 Host 提取报告；Devtools 自行保存"}]
  ],
  "arrows":["↓","↓","↕","↓"],
  "note":"Flush 是联动调度边界，数据在每条 Command 时已经生效。可隔离错误继续，超限整体中止；精确排序、通知重入和中止后 Pending 仍待固化。"
}
```

V1 延迟一次启动，然后在同一同步执行过程消费任务直至结束；不实现时间切片。微任务可作为启动方式，但精确启动契约仍待固化。V0.5 确认首次 Reaction 入队、进入 scheduled 时建立临时 Context，保留首次有效变化及后续合并的来源，避免执行开始时才记录而丢失起因。

| 发生时机 | 数据 | Reaction 归属与状态 |
| --- | --- | --- |
| scheduled 期间多个 Operation | 每次同步生效 | 加入已安排轮次，合并同一 pending 实例 |
| Flush 内部 Reaction 发出 Command | 同步生效 | 新失效加入当前轮，不为 A → B → C 各开一轮 |
| 前轮结束后 Host 异步返回 | 同步生效 | 新失效安排下一轮，计数独立 |
| 同步 Flush 中外部回调重入 dispatch | 同步生效 | 推荐加入当前轮并记 hadExternalReentry；策略仍待确认 |
| 外部修改未命中 Reaction | 同步生效 | 无需安排 Reaction Flush；Validation / View 仍按自身契约响应 |

同一 JS 主线程的普通输入事件或 Promise 回调不能插入已经开始的同步 Flush 调用栈。同步订阅回调、外部注册代码的重入是另一种情况：通知链需要独立保护，不能只靠 Reaction 执行次数兜底。外部重入不重置本轮计数；此时队列能否清空仍可判断，但报告不能轻率归因为纯内部循环。

## Reaction 合并、重入队与执行顺序 {#l3-reactions}

Reaction 是最新状态驱动的收敛行为。年龄和产品在执行前各变化一次，同一个保费实例只保留一份 pending，执行时读取最终年龄与产品；追踪保留两条失效来源。需要每次点击都新增一条记录的业务，使用明确 Command / Host 事件表达，不依赖 Reaction 的触发计数。

```text
invalidate(instance, change):
  尚未 pending → 登记实例与触发来源
  已经 pending → 合并触发来源，不重复入队
takeNext():
  从 pending 取出并移除实例
  执行时读取最新状态
  执行后再被有效变化命中 → 允许重新入队
```

推荐按 PreparedForm 稳定规则顺序完成初始入队，执行中新增任务按首次登记顺序追加；重复失效不移动已排队实例。推荐当前 Reaction 不被新失效打断，完成当前 `then[]` 后再取下一项，避免规则嵌套调用。准确顺序和运行中再次失效细节仍是 R13 / R18 的待确认契约。

稳定顺序帮助复现，不能保证冲突写入的最终值与顺序无关。同目标覆盖、互相依赖、结构修改都需验收。`then` 允许 array.insert/remove/move，但配置必须符合状态收敛意图；无条件反复新增需诊断风险，不能据此假定每次触发均应完整保留为业务事件。

## 初始化、缺失与清空由业务规则表达 {#l3-missing-values}

V0.5 确认不新增通用 Reaction Ready 状态机。必须区分读取缺失 / 未初始化、null、空字符串、0 与 false，不能用统一 falsy 判断表示“未就绪”。Missing 的具体读取表示与准确 SDK 类型仍待固化；示意中的 undefined 不作为 JSON 数据值写入协议。

| 场景 | 业务规则需要表达什么 | 结果 |
| --- | --- | --- |
| 初始缺少 age | 用 when 或纯函数的显式空值契约跳过 / 返回 null | 不误调要求有效年龄的保费算法 |
| 用户后来清空 age | 若业务要求同步清空 premium，明确计算并写 null | 该有效 Change 正常影响其他依赖，不默认留旧保费 |
| when 不成立 | 不执行当前 then[] | 跳过本身不会撤销以前写过的值；需要清空应另行表达 |

```text
示意业务纯函数：
  age 为 Missing / null / 空字符串 → 返回 null
  否则 → 按明确的输入类型契约计算保费
Reaction 的 set 把返回值写入 premium，仍经过正常变化匹配。
```

是否在 Runtime 初始化、新 Scope 激活、Reset 时主动安排首次 Reaction，仍是未决生命周期策略。它与上述实际执行时的空值处理分别设计；不能为了解决初始化而由 L3 扫描表达式补 watch。相关验收需要结合嵌套数组、when、显式 watch 和初始化基线完成。

## 四种执行轨迹 {#l3-traces}

以下是逻辑演示，字母为规则实例，数值为解释用途，不是运行算法或真实性能数据。

| 场景 | 步骤 | 可观察结论 |
| --- | --- | --- |
| 正常级联 | Operation 写 age=25 → pending A；Flush #1 中 A 写 premium=150 → B；B 写 totalPremium=150 → C；C 无有效修改 | 全部在 #1；队列清空，正常释放 Context |
| 多次输入合并 | scheduled 时 Operation #1 写 age=21 使 A 入队；#2 写 product=PLUS 再命中 A；A 执行一次读取最终二者 | 同一 pending，多对一 triggeredBy 来源 |
| 往复震荡 | A 将 age 17→18 使 B 入队；B 将 18→17 再使 A 入队，持续有效变化 | pending 去重不能阻止循环；整个 Flush 达到预算后停止，保留已写 Data 并报告 |
| 同步外部重入 | Flush #4 中 A 写 premium；通知回调由 Host 同步写 discount；新失效使 B 入队 | 推荐归当前轮并标记外部干预；通知有界策略待决策 |

同规则的 `A#1 → B#1 → A#2` 是三次独立执行，需要各自 executionId；不能把 A 的所有执行折叠成一条运行记录。

## 静态风险与运行时有限执行 {#l3-protection}

| 机制 | 发现 / 保护什么 | 取舍与状态 |
| --- | --- | --- |
| 同值短路 | 相同值反复写入 | 基本保护；复杂对象等值需明确，不默认深比较 |
| 同实例 pending 去重 | 执行前的重复失效 | 必须；不解决执行后的往复循环 |
| 本轮总执行数 + 单实例次数 | 无界传播与局部重复 | 必须；计数低成本，具体阈值待标定 |
| 执行边界耗时检查 | 过慢轮次 | 可以报告并阻止继续调度；不能强制抢占正在执行的同步函数 |
| L2 Watch / Write 图与 SCC | 潜在规则环链 | 推荐；Tarjan / Kosaraju 可用，风险默认 Warning，不能禁止所有环 |
| 每步全量 Data Hash | 重复数据状态 | 不做默认判环；单次 O(S)，K 次为 O(K×S)，也漏掉无限增长 |
| Runtime 执行图与 SCC | 实际反复触发的规则集合 | 不进入默认热路径；留给 Devtools / 高级诊断 |
| 局部指纹 / Merkle 式 Hash | 局部往复状态 | 延期；需要完备读取、Scope 和状态信息 |

重复 Data 不等于重复完整执行状态，图中有环也不等于一定不终止。V1 目标是提前提示风险、限制执行、解释异常，无法对任意函数与修改组合通用证明终止。正常多轮收敛不用报错；已删除 Scope 的过期待执行任务正常取消。

早期本地 Node 的毫秒数不能成为 Web / Flutter 的性能预算。全表 Hash 的复杂度随数据字节数 S 增长；轻量记录成本主要随执行事件数、实际变化与额外复制参数量增长。具体常数须用大型数组、高频输入及目标平台 benchmark 标定。

## Command 错误隔离与整体 Flush 熔断 {#l3-errors}

| 现象 | 当前约束 | 尚需固化 |
| --- | --- | --- |
| 合法多轮收敛 | 正常结束，不持久上报完整轨迹 | 不将次数多直接判错 |
| 疑似往复写入 / 持续覆盖 | 如实记录实际是否收敛，可报告异常模式 | 分类、阈值与上报限频 |
| Function / Command 可隔离错误 | 记录并报告，不回滚其他成功修改；后续独立 Command 继续尝试，其他 Reaction 按实际 Change 响应 | 错误类型、诊断、门控求值失败等具体继续条件与 API |
| 单实例 / 本轮执行数超限 | 中止整个当前 Flush，不做局部链路熔断 | 剩余 Pending 的清理 / 保留与后续再触发入口 |
| 耗时异常 | 执行边界判断并报告，无法抢占正在执行的同步函数 | 阈值和边界处理 |
| Scope 已删除 | 正常取消过期实例任务，回收关联 | 不作为业务错误上报 |

Reaction 没有执行控制意义的父子关系：A 修改数据使 B 失效，B 不检查 A 的成功状态，只检查自身 Scope、watch 与运行条件。某条命令失败，不自动禁用“下游”，不回滚其他成功修改；后续命令依次读取执行时的最新数据。可隔离错误与预算超限分别处理，安全预算到达时终止整轮，不能把“继续独立行为”理解成忽略保护。

整体停止的最小约束：保留已写 Data；不把停止伪装为正常收敛；清理 Context 前提取真实错误 / 超限类型与临时路径，交给 Host 报告；不自动无限重启同一批遗留任务。具体 Pending 处理及再触发仍待确认。

V0.4 曾保留“局部不可信范围、长期 Health、相关规则恢复后清除标记、利用依赖计划传播影响”的候选，V0.5 为降低状态机与影响链成本明确替代该方向：不做父子 Reaction 状态、失败下游禁用、局部熔断或链级恢复。解释异常的 Trace 不参与调度和权限决策；Validation 的 Issues / 新鲜度仍按自身契约管理。旧约束完整留在 [整合前正文](../history/README.md#protocol-runtime-v05-integration)。

## Trace：事实、来源与记录边界 {#l3-trace}

Runtime 记录有序执行事实与实际变化，Devtools / 离线平台重建因果关系。记录应能表达 Operation 来源、Reaction / Scope、执行顺序、状态和产生的有序修改，`triggeredBy[]` 支持多个变化合并触发一次执行。

```text
Operation #1 → Change #11：age 20→17
Operation #2 → Change #12：product BASIC→PLUS
Reaction A · Execution #13 · triggeredBy [#11,#12]
  → Change #14：premium 100→150
Reaction B · Execution #15 · triggeredBy [#14]
  → Change #16：discount 0→10%
Reaction A · Execution #17 · triggeredBy [#16]
```

| 信息 | 用途 | 限制 |
| --- | --- | --- |
| executionId | 区分同一实例在本轮的多次执行 | 不等于 L1 Reaction ID |
| changeId | 定位 Command 造成的真实变化 | 无变化调用可记录执行事实，不伪造有效 Change |
| triggeredBy | 标识使本次执行失效的变化 | 表示调度原因，不证明每项都是业务计算的必要条件 |
| dataVersion | 标识读取的工作状态版本及变化前后版本 | 版本号本身不保存历史值 |
| Scope / Path / op | 解释实际对象与修改位置 | Scope 稳定身份与当时路径需分别说明 |

概念级结构如下；字段、ID 空间、操作与变化粒度、失败 / 无变化的编码继续固化，不直接发布成正式 TS 包：

```typescript
interface ExecutionRecord {
  id: number;
  kind: 'operation' | 'reaction';
  name: string;
  scopeId?: string;
  triggeredBy?: ChangeId[];
  changes: DataChangeRecord[];
  status: 'success' | 'error';
}
interface DataChangeRecord {
  id: ChangeId;
  target: { scopeId?: string; path: string };
  op: string;
  beforeVersion: number;
  afterVersion: number;
}
```

来源草图同时给变化记录放入 `changed` 标志；本篇将有效变化与无变化 Command 事实分开说明，保留其信息需求，不冻结两套并行变化模型。首个失效之前的 Operation / Change 必须能在建立 Context 时被关联，具体采集方式待定。

V0.5 继续要求记录预算内的 Operation、Reaction 与 Command 结果。可隔离错误后仍可能有成功修改，因此记录应能区分失败命令、无变化尝试与后续实际 Change，不能只用整条 Reaction 的 success / error 推断每条命令的结果。具体事件粒度与字段仍待固化；这些状态只用于诊断，不用来禁用其他规则。推荐 Prepared Source Map 关联原始 L1 的身份、版本和位置，便于由报告回查配置，详见 [编译来源](l2-preparation.md#l2-authoring-diagnostics)。

## 记录预算、参数与异常上报 {#l3-trace-budget}

执行预算与记录预算独立：前者停止无限联动，后者限制事件条数及字节数。Trace 满了可停止详细采集或截断，但计数与循环保护必须继续。合并来源、参数副本等附属记录也需计入容量，不能通过大 `triggeredBy` 绕过记录预算。

推荐在正常容量内保留完整本轮，溢出时保留初始来源与最近一段，并标记 `truncated`；仅保留尾部是替代方案，最终策略仍待决策。截断造成的缺失引用必须如实表达，不能伪造完整因果链。

| 对象 | 生产临时 Trace 方向 | Devtools 可选扩展 |
| --- | --- | --- |
| Reaction / Scope、实际 Command 与目标 | 记录身份和事实 | 同一来源进一步展示 |
| when 结果 / Pure Function ID | 必要的少量元数据 | 更细的求值过程 |
| 标量业务参数 | 脱敏值、受限摘要或不留原值，策略待定 | 在明确授权范围扩展 |
| 大对象 / 数组参数 | 类型、大小、摘要，避免逐步深拷贝 | 受限稳定副本或检查点 |
| Working Data 全量 Snapshot | 不逐步复制 | 历史恢复属于延期能力 |

保存可变 Context / 外部对象引用不能证明历史参数；需要审计时必须明确受限副本或摘要形成的时点。正常结束释放生产完整记录，异常先提取报告；Devtools 可自行长期保留。异常报告至少应定位 Definition / 发布身份、Reaction / Scope / Path、轮次结果、保护原因及截断信息，具体字段、脱敏映射和限频待固化。注册能力、Runtime 和平台的版本信息也影响可解释范围。

报告交给 Host / 配置平台去重、限频，不能成为正常 Data 写入的等待或许可条件；Devtools 的历史保存与事件消费 API 在实现阶段确定。临时记录从首次入队建立到本轮结束释放，不以异常为由给生产 Runtime 增加所有正常轮次的长期历史。

## Devtools 因果分析与复现的三种层次 {#l3-devtools}

事后先扫描 changes 建立 `changeId → executionId` 索引，再扫描 triggeredBy 连边。记录完整时，成本随执行数、变化数和引用数线性增长；Runtime 无需实时维护父子树或运行 Tarjan。以执行实例为节点按时间向前连边，以 Reaction Instance 折叠展示时才可能出现 A ↔ B。

| 能力 | V1 边界 | 额外条件 |
| --- | --- | --- |
| 复原执行顺序和触发链 | 推荐支持；受截断范围限制 | 有序记录与 Change 关联 |
| 复原历史 Data 值 | 暂不承诺 | 初始 Data + 可重放的实际修改日志 + 数组 / Scope 恢复信息 |
| 确定性重新执行 | 暂不承诺 | Definition / Prepared / Function 版本、初始 Data / Context、外部输入、非确定性来源与环境约束 |

异常可定位不等于时间旅行。Devtools 关闭也必须得到同样的 Reaction 输出与调度结果。

## Validation、Renderer 与 Submit 的边界 {#l3-consumers}

共用匹配不等于共用完成条件。Reaction Flush 处理同步联动收敛，不等待所有外部校验或 UI 绘制。

| 消费者 | 失效时 | 执行 / 完成时 |
| --- | --- | --- |
| Reaction | 合并 pending 与来源 | 读取最新 Data；有效写入归当前轮 |
| Internal Validation | 旧结果及时失效 | 按策略重评估，维护自身 Issue / Status / Scope |
| External Validation | 旧结果失效，必要时取消旧请求 | 发起时固定输入；返回时检查请求、Scope 与输入新鲜度 |
| Renderer | 获知最新状态变化 | 框架读取最新状态，不要求消费每个中间版本 |
| Submit | 核对所需联动、校验与输出的完成条件 | 不把异常 / 中止视作无异常完成；准确交接契约仍待定 |

Validation / Submit 的完成边界仍待决策，不能只看队列为空或没有 Issue；需要核对所需联动完成、当前校验与输出。V0.4 的按局部受损范围 / Health 传播决定提交方案已随 V0.5 简化方向退出，不据此引入失败下游禁用。错误或整体熔断结果如何影响提交，由后续完成契约明确；实际提交、权限和风控由 Host 负责。

微任务启动 Flush 可能仍发生在浏览器绘制前，耗时同步纯函数会阻塞主线程，这是 V1 接受的简化取舍。未来可以替换 Scheduler，但需保持数据写入、收敛、身份及异常契约。

## 跨层修订、替代方案与取舍 {#l3-impact}

| 层 / 早期候选 | 现行处理 | 保留理由与影响 |
| --- | --- | --- |
| L3 可变 JSON + 按需 Snapshot | 不可变 Working Data + 结构共享 | 稳定旧快照；更新算法保留优化空间 |
| batch 候选树统一提交 / 回滚 | 逐 Command 有序即时生效，不默认整体回滚 | 输入反馈与状态语义；通知合并独立处理 |
| Reaction 每次失效均独立执行 | 最新状态收敛、pending 去重 | 状态联动与事件记账分离；L1 同步说明 |
| Operation 包含完整联动事务 | 仅记录外部来源，多个 Operation 可共用 Flush | 调度轮次独立于修改来源 |
| 同步 / 全延迟 / 混合 / 分段调度候选 | V1 延迟启动、同步消费到结束 | 保持简单，可替换入口，暂不做 Fiber 式优先级 |
| 每步 Hash / 热路径完整因果图 | 同值短路、次数预算、轻量有序 Trace | 降低热路径成本；静态风险和离线解释分工 |
| 最近 N 条或长期生产历史 | 临时轮次记录；预算与截断待定；异常提取报告 | 保留起点有助定位，同时控制内存与复制成本 |
| L2 Read / Watch 分离 | 保持；推荐 Watch / Write SCC 风险诊断 | Write 不改变 Reaction 触发逻辑 |
| L1 then 中数组操作 | 保留，但需符合收敛意图并提示非幂等风险 | 显式 Command 次数不合并，Reaction 不承诺每次触发次数 |
| 原始 L1 与 Prepared 可双轨执行 | Runtime 只消费兼容 PreparedForm | 统一诊断、依赖计划与能力绑定，避免静默解释回退 |
| 普通错误一律停后续 / 局部 Health 传播 | 单 Command 可隔离错误继续独立行为；超限整体熔断 | 不检查上游成功，不做局部影响链与恢复状态 |
| 缺失输入靠通用 Reaction Ready | 业务 when / Pure Function 明确空值语义 | 区分初始缺失与用户清空，不静默保留旧派生值；首次执行策略仍未决 |
| Scope / Validation / L4 | 保持稳定身份、校验所有权与新鲜度、按挂载订阅 | Trace 也按稳定 Scope 定位；Runtime 不控制 UI 帧与 Loading |

不默认整体回滚、逐步全表快照、运行时因果图或复杂调度，是具体成本与表单状态语义之间的选择。V0.5 进一步用单 Command 可隔离错误与整轮预算边界替代父子执行控制、局部熔断和不可信影响范围传播；Trace 仅诊断，不作为调度或权限门控。旧候选与整合前全文见 [V0.4 来源](../history/README.md#l3-integration) 及 [V0.5 整合归档](../history/README.md#protocol-runtime-v05-integration)。

## 决策总账 {#l3-decisions}

以下沿用 V0.4 的 R01–R26 稳定编号，受 V0.5 影响的行标明当前修订及原状态；未受影响项保留。“推荐”不是已经冻结，“待实现标定”也不是实现完成。完整 V0.4 原始状态在来源包中保留，V0.5 的独立 D01–D22 见 [跨层总账](dependency-reactivity.md#dependency-v05-decisions)。

| 编号 | 决策 | 状态 | 说明 / 所属层 |
| --- | --- | --- | --- |
| R01 | Working Data 不可变 + 结构共享 | 已确认 | 旧 Snapshot 稳定；每条有效 Command 可发布新 Root；L3 Data |
| R02 | 单个有效 Command 同步生效 | 已确认 | 业务合法性由 Validation 判断；结构操作保持内部一致性；L3 Data |
| R03 | 默认 Batch 非原子事务 | 已确认 | 子 Command 有序实时写入，不默认回滚前序成功修改；L1 / L3 |
| R04 | Reaction 是最新状态收敛行为 | 已确认 | 不依赖触发次数；同一待执行实例可以合并；L1 / L3 |
| R05 | 内部 Reaction 写入属于当前 Flush | 已确认 | 不为每条联动创建新 Flush；执行后可重新入队；L3 Reactive Engine |
| R06 | V1 延迟启动、同步执行到结束 | 已确认 | 不做分段调度/时间切片；L3 Scheduler |
| R07 | Operation 是来源，不是隔离事务 | 已确认 | 多个 Operation 可影响同一个 Flush；L3 |
| R08 | Trace 为顺序行为记录 + Change 来源 | 已确认 | 不构建运行时因果图；Devtools 事后分析；Diagnostics |
| R09 | 正常 Flush 不持久上报 | 已确认 | 执行结束后释放临时 Context；异常才提取报告；Diagnostics |
| R10 | Devtools 可观察完整执行 | 已确认方向 | 启用时由 Devtools 自行保存历史，不能改变执行语义；Devtools |
| R11 | L2 做 Watch/Write 图与潜在环诊断 | 推荐 | 静态 SCC 可辅助定位，但不禁止所有成环规则；L2 |
| R12 | Flush Context 自首次入队建立 | 已确认 · V0.5 | 原为推荐；当前确认保留 scheduled 初始来源与合并原因；L3 |
| R13 | 执行时使用稳定顺序与去重队列 | 推荐 | 稳定规则排序 + 首次入队顺序，具体语义需再确认；L3 |
| R14 | 超限熔断整个本轮 Flush | 已确认 · V0.5 | 原为推荐；统一整轮预算，不做局部熔断影响链；L3 |
| R15 | 可隔离 Command / Function 错误继续独立行为 | 已确认 · V0.5 | 原为待决策；记录错误，后续独立命令与规则继续；精确类型和接口待固化；L3 |
| R16 | 整体熔断后的 Pending 与再触发 | 待确认 · V0.5 | 不回滚、不无限自动重启；原局部影响范围 / 链级恢复被替代，具体队列处理待定；L3 |
| R17 | 同步订阅重入时的递归通知保护 | 待决策 | Data 同步写入不变；通知交付需要有界处理；L3 / L4 |
| R18 | 单次 Flush 的启动与执行排序细节 | 待决策 | 运行中被再次失效、同层/跨层写入冲突如何排序？；L3 |
| R19 | Trace 预算溢出策略 | 待决策 | 完整到上限后保留头尾并标注截断，还是仅尾部？；Diagnostics |
| R20 | 详细参数记录的边界 | 待决策 | 实际值/摘要/大小/类型、敏感数据与稳定拷贝；Diagnostics |
| R21 | 异常检测阈值与重复上报限频 | 待实现标定 | 单实例和总次数硬限制、耗时统计、告警聚合；L3 / Host |
| R22 | Validation / Submit 完成边界 | 待确认 · V0.5 | 原按局部受损范围阻止的候选被替代；所需联动、异常轮次与校验如何衔接待定；L3 / Host |
| R23 | 确定性 Replay、历史 Snapshot | 延期 | 先保证执行链说明；需要时再引入检查点与重放数据；Devtools |
| R24 | 全量 Hash、局部 Hash、完整因果图 | 延期 | 仅高级诊断/开发分析有明确需求时再实现；L2 / Devtools |
| R25 | 复杂分段调度 / 优先级 | 延期 | 先做可替换调度入口，V1 不实现 Fiber；L3 |
| R26 | 初始化/Reset 对 Reaction 首轮触发语义 | 待决策 | 初始化读依赖不等于执行初始校验；初始 Reaction 何时求值？；L3 Lifecycle |

## 设计验收与下一步 {#l3-acceptance}

| 用例 | 场景 | 输入 / 过程 | 必须观察到 |
| --- | --- | --- | --- |
| C01 | 单步输入 | set age=25 后立即读取 | 返回 25，不等待 Flush |
| C02 | 多次合并 | 启动前两次修改 A 的 watch | A 仅一份 pending，执行读最终值 |
| C03 | 链式写入 | A 写 premium，B 观察 premium | B 进入当前 Flush |
| C04 | 重复失效 | A 执行后 C 再改其 watch | A 可重新入队，保留新来源 |
| C05 | 同值短路 | A set 与当前原始值相同 | 无有效 Change，不继续触发 |
| C06 | 动态数组移动 | B 从 index1 移到 index0 | Scope B 稳定；订阅与 Trace 不串项 |
| C07 | 业务校验失败 | 输入超范围年龄 | Data 接受，Validation 产生 Issue |
| C08 | 简单自环收敛 | age16→A 设置18，再执行无修改 | 正常结束，无错误上报 |
| C09 | 往复震荡 | A→B→A 持续有效变化 | 达到预算停止并生成定位报告 |
| C10 | 合并来源 | 两个 Change 命中待执行 A | A 的一次执行关联两个 Change ID |
| C11 | 多次规则执行 | A#1→B#1→A#2 | 独立 executionId，可还原链条 |
| C12 | 正常清理 | 正常 Flush 完成 | 生产 Runtime 不保留完整 Trace 历史 |
| C13 | 异常上报 | 熔断后提取报告 | 定位 Definition 版本、Reaction / Scope / Path 和截断 |
| C14 | 记录预算满 | Trace 先于执行保护达到上限 | 停止详细采集 / 截断，保护仍工作 |
| C15 | 异步 Host 操作 | 前轮结束后 Host 写入 | 新轮次，不复用旧执行计数 |
| C16 | 同步重入 | 通知回调再次同步 dispatch | Data 即时更新，通知不会无限递归；策略待定 |
| C17 | 整体熔断后再触发 · V0.5 修订 | 本轮中止后又出现外部修改 | 不自动无限重启遗留任务，不回滚已写 Data；Pending / 再触发契约待补，不再断言局部 Health 标记 |
| C18 | Devtools 关闭 | 开关 Devtools 运行同表单 | Reaction 输出和调度语义一致 |

这些是未来 Runtime 的设计验收，当前候选协议检查与有界探针不实现真实 Flush / Trace / 整体熔断，不能将其通过计数当成本表已经通过。C17 按 V0.5 替代原局部 Health 要求，旧行在归档保留；C16、C17 需补准确契约。新增的 Command 隔离、初始化空值和 Prepared 拒绝回退见 [V0.5 的 12 个跨层场景](dependency-reactivity.md#dependency-v05-acceptance)。

下一步推荐从 PreparedForm → 初始化 → 动态 Scope 实例化 → Reaction 首次运行串成最小闭环，再验证 Reset / Reinitialize / Dispose、通知重入与精确排序。整体熔断后 Pending / 再触发以及 Validation / Submit 完成契约继续补齐；随后固化 Trace / 参数 / 错误接口，以动态数组与高频输入标定预算。可隔离错误继续与整轮熔断不再重开为局部传播设计。正式类型、Schema、Prepared ABI、Runtime 与适配器按落地任务建立，不将本篇概念结构当成生产发布包。
