# 文档维护

项目处于方案设计与规范固化阶段。现行基线是 Prepared 唯一运行入口、显式 Watch、逐 Command Data / Scope 比较、相对 Scope、变化驱动 Reaction 与整体 Flush。2026.10.19 后续用户进一步确认：常规 Reaction 只响应有效 Watch 变化，runOnActivate 仅新实例首次激活；L3 提供稳定 snapshot，Dirty / 业务 Baseline / Reset 策略归 Host，撤回 V0.6 的 Runtime 自动基准与主动重算。Context 保留现行只读 / Data-only Command 与 Watch。V0.7 将校验设计推进为完整 Schema + 增量 Constraint + 本轮前置整理 + 字段 Issue 聚合；缺失前置的增量语义、requires / 消息覆盖、Issue / 完整返回与通知仍待固化。索引候选仍为推荐，激活默认值、快照 SDK、Pending、异常 Flush / Submit 衔接、ABI 和生产实现继续固化；业务编辑策略不再作为核心未决项。

## 阅读与源文件

本地资料的架构知识重构沿用下表的权威主题，不另建平行 `architecture/`。直接阅读从整体架构的[现行设计路径](design/architecture.md#current-design-map)进入，不需要先检索历史。了解决策原因时查[独立 ADR 入口](design/architecture.md#decisions)，继续设计时查[一致性审查 / 模块矩阵 / 待决策 / 路线图](design/governance.md)，核对原件时查[来源与覆盖](design/source-map.md)。事实、已确认决策、审查建议和未知项分别标明；本次新增支持文档不改变既有架构语义。

整体方案分为两份指南：[使用与开发指南](reading/usage-guide.html) 从最小字段、计算校验、数据联动、重复项、宿主接入逐步进入排障与参与开发；[设计者指南 · 整体架构](reading/architecture.html) 保留完整思想、概念、分层、机制、图示、取舍、交付物和验收路线。前者帮助读者用场景理解框架，后者用于方案评审与核心设计。

两份指南共用 [L1 定义协议](reading/l1-definition-protocol-v1.html)、[L2 编译与发布](reading/l2-preparation.html)、[依赖与订阅](reading/dependency-reactivity.html)、[L3 执行与诊断](reading/l3-reactive-engine.html)、[L3 校验与结果](reading/l3-validation.html) 和 [协议样例](validation/index.html) 作为详细契约与例证，全部在共享侧栏直接切换。L1 原有渐进分组继续作为协议查阅路径，不扩写成第三份全框架指南；章节目录直接进侧栏，术语嵌入设计者指南，复现说明并入样例。历史只从 [归档入口](history/index.html) 按需追溯，不再维护平行摘要或轮次规范。

| 来源 | 职责 |
| --- | --- |
| `design/usage-guide.md` | 使用与开发指南；以场景递进解释框架、接入、可观察结果、排障与贡献入口，链接权威契约 |
| `design/architecture.md` | 设计者指南；思想、产品边界、完整分层、图示、机制、取舍、交付物与验收路线，保留现有 URL / 锚点 |
| `design/l2-preparation.md` | L2 与平台职责、Pure Function、能力契约、Host 注册、编辑诊断闭环、Prepared 唯一入口与不可变发布；增量与 Source Map 保留推荐状态 |
| `design/dependency-reactivity.md` | 原始 / 编译后协议、Watch 作者确认、读取 / 触发 / 订阅、Scope / 挂载 / 时序；承接 V0.5 D01–D22 来源状态与 12 个跨层设计验收，并注明后续进展 |
| `design/l3-reactive-engine.md` | 逐 Command Data / Scope 比较、新实例激活、稳定 snapshot、Runtime / Host 四条原则、Flush / Trace；R01–R26、V0.6 来源 / 现行处理、修订后场景及 B01–B08 边界验收 |
| `design/l3-validation.md` | 校验执行、完整 Schema / Adapter、增量 Pending、本轮前置、异步有效性、Source / 字段聚合；V0.7 的 19 项来源决策与 V01–V16 设计验收 |
| `design/l1/01-*.md` 至 `08-*.md` | 同一份 L1 正文的八个主题；按需读取和修改 |
| `design/l1/README.md` | L1 阅读分组、场景引导与章节顺序；生成时嵌入同一协议页，不另建索引页或复制协议正文 |
| `CONTEXT.md` | 领域词汇，生成时嵌入架构文档 |
| `design/decisions/ADR-FE-*.md` | 重要既有决策的独立记录；背景、真实备选、取舍与替代链，链接完整规则；不冒充历史 ADR 原编号 |
| `design/governance.md` | 约束索引、审查问题、17 个模块状态、OD 待决策清单及有依赖 / 交付 / 验收的路线；建议不自动成为决策 |
| `design/source-map.md` / `architecture-source-inventory.json` | 来源角色、关键结论与 ADR 映射、证据局限，以及可重复生成的文件 / ZIP 成员 / 章节 / 摘要清单 |
| `validation/` | 样本生成源、候选验证器、数据、报告与复现说明 |
| `history/` | 原始来源与被替代版本，不与现行正文并列生效 |

讨论某项能力时先查对应 Markdown 的标题和章节锚点，再读必要的相邻契约。指南解释不取代主题正文；一个决策只在其所属主题维护完整规则，跨层影响同步相邻契约，避免形成相互冲突的解释。完整示例、类型附录和验证数据按需加载；不为获取设计约束读取 HTML、CSS、JS 或历史稿。两份指南和各专题复用统一阅读外壳和侧栏，不新增重复索引页；后续设计继续归入 `design/`，实现目录在落地任务中建立。

## 维护方式 {#maintenance}

1. 修改相应 Markdown 或样本生成源，保留稳定章节锚点和已收敛 / 待固化状态；不按讨论轮次新增平行规范。
2. 示例变化时同步验证源。保险基线读取 [示例正文](design/l1/07-examples.md#sample)；其余样本来自 `validation/build_cases.py` / `extend_cases.py`。不直接修改生成的 cases、报告和阅读页。
3. 生成阅读页并检查同步；协议样例变更时另复跑验证。出现冲突，以相应主题正文为准，修正受影响的样本和说明。

4. 新增来源或修改设计时，同步相关 ADR、治理事项和来源映射；先审查变更，再运行统一构建更新派生清单与页面。盘点检查保留原技术章节 / 代码 / 图示，不自动判定新结论已确认；需要有意迁移原内容时须先扩展可审计的迁移映射。

首次安装依赖与日常生成，在项目根目录执行：

```bash
python3 -m venv --system-site-packages .venv-docs
.venv-docs/bin/python -m pip install -r tools/docs/requirements.txt -r docs/validation/requirements.txt
.venv-docs/bin/python tools/docs/build_docs.py
.venv-docs/bin/python tools/docs/build_docs.py --check
```

协议样例变更后的验证：

```bash
.venv-docs/bin/python docs/validation/run_validation.py
```

阅读页共用 `tools/docs/reader.py`、`tools/docs/templates/document.html` 及 `docs/reading/assets/documentation.css` / `documentation.js`。`examples.css` 只补充样例布局；历史快照保留原有呈现，纯函数术语已统一，原始字节见历史来源包。仅改呈现时重新生成页面即可，无需重建协议数据。旧首页 `reading/index.html` 直接转到整体架构，不另维护一份首页正文。

L1 阅读顺序在 `design/l1/README.md` 中维护：每个带稳定锚点的二级标题是一组，段落说明使用场景，末尾列表逐项链接编号正文的章节。生成器要求每节正文恰好出现一次，保留原章节及主题锚点，避免重排时漏节、重复或破坏既有链接。新增章节时同步安排阅读位置；协议字段、类型、约束和样例仍只在编号正文维护。

架构图在 Markdown 的 `diagram` 代码块中维护节点、连接和说明数据，由 `tools/docs/diagrams.py` 生成共享风格的图形。这些数据仅用于文档呈现，不是 L1 协议字段；正文和图示中的职责、状态与演进关系需要同步维护。

## HTML 阅读系统与本地运行 {#reader-system}

统一构建命令为 `.venv-docs/bin/python tools/docs/build_docs.py`。它读取现行 Markdown、领域词汇和历史主题索引，校验元数据 / ID / 关联 / 决策替代 / 任务前置，然后生成全文索引、模块及治理记录、来源清单、共享 HTML 与协议样例页。原始 Markdown 不被构建修改。`--check` 不写文件，检查派生物同步、本地文件 / 章节链接、重复锚点和原有内容保留。索引 JSON / JS 都是生成产物，不能手改设计状态。

完成构建后，用一条命令启动本地服务：

```bash
.venv-docs/bin/python tools/docs/serve.py
```

打开 [架构首页](http://127.0.0.1:8765/docs/reading/architecture.html)。默认只监听本机 127.0.0.1；端口被占用可用 `--port 8766`，需要启动前重建可加 `--build`，Ctrl+C 停止。验收使用本地 HTTP；直接 file:// 是否允许本地脚本取决于浏览器策略，不作为已验证的跨浏览器承诺。搜索使用本地经典脚本索引，不依赖 fetch、后端或外部 CDN。

输出继续集中在 `docs/reading/`，验证图鉴在 `docs/validation/index.html`、历史入口在 `docs/history/index.html`。这些明确的既有输出位置复用共享模板；没有第二套 viewer/dist 或重复正文。静态图、Mermaid、代码高亮、宽表格、打印、浅 / 深色与窄屏导航均由共享外壳处理。

顶部搜索支持全文 / 标题 / ID / 关键词，并按文档类型、模块和声明状态过滤；结果包含所属文档、层级、片段和章节链接。搜索覆盖已编目的 Markdown 及其当前章节，包含 ADR、治理、术语和历史推导索引；不声称全文搜索 ZIP 或旧 HTML 的全部原文。Ctrl / ⌘ K 打开搜索。治理页按种类、模块、严重程度、前置决策阻塞和状态筛选，并提供两个模块的状态对照；筛选写入 URL，可保存具体问题视图。正文始终完整保留在交互视图下方。

独立阅读不要求先看 ADR。普通主题上方给出相关模块概览，下方是完整规范，右侧为本页目录、关联模块、ADR、文档 / 历史及来源；窄屏从“本页目录与关联”展开。原有 `diagram` 架构图不迁移为新的事实副本，放大只克隆同一渲染结果。Mermaid 支持 flowchart、sequenceDiagram、stateDiagram 等库支持语法；当前只有文档构建链使用 Mermaid，不推导新的业务调用关系。原资料无数学公式，本次没有引入公式引擎。

第三方静态依赖为固定的 Mermaid 11.12.1，来自 npm 官方包，只保留 `mermaid.min.js` 和 MIT 许可证，不执行包内安装脚本。文件位于 `reading/assets/vendor/`，SHA-256 为 `198b19442f86f0b46a17e56d3abf744c3a28a3427e66fa8dada3b589a77babcc`。YAML 使用 SafeLoader，Markdown 输出经 nh3 标签 / 属性 / URL 白名单清理，Mermaid 使用 strict 且禁用文档内配置指令，搜索与筛选用文本节点渲染结果；语法高亮由 Pygments 在构建时完成。实现依据见 [nh3](https://nh3.readthedocs.io/en/stable/)、[Mermaid 配置](https://mermaid.js.org/config/usage)、[Pygments](https://pygments.org/docs/formatters/)。

## 机器元数据与状态语义 {#metadata-contract}

知识文档 Frontmatter 的 `id / title / type / status / layer` 必填；title 与 H1 一致。ID 是稳定身份，文件重命名不改变 ID。`modules` 引用治理矩阵 M01–M17，`related` 分组引用既有 ID，`sources` 引用来源登记 SRC-*；一般阅读互链与自动反向链接允许成环，不当作架构循环。`supersedes / superseded_by` 如果使用，双方须一致；只对明确决策替代和路线图前置进行有向无环校验，不从普通文档链接猜测模块调用关系。

| 声明状态 | 唯一语义 |
| --- | --- |
| active | 当前有效文档；不代表文档所述全部接口或生产实现已完成 |
| accepted | ADR 所限定范围的决策已确认；局部推荐 / 待定内容须在 status_note 和正文保留 |
| proposed | 尚待确认的提议 |
| superseded | 已被明确后续决策替代，须有相应替代关系 |
| deprecated | 明确不再采用，未必有单一后继 |
| archived | 历史记录，不与现行规范并列生效 |

文档类型为 design / guide / protocol / decision / governance / source-map / glossary / history。这些值分类文档，不定义新业务领域。模块的已完成 / 部分完成 / 待设计 / 存在阻塞 / 状态未知来自[治理矩阵](design/governance.md#design-status)的显式“阅读状态”列；完成标准与限定范围仍在该行及说明中。冲突的 high / medium / info、open / explained、blocking 与模块关联在同一治理 Markdown 的 Frontmatter 记录，属于审查判断，不等于用户批准新方案。OD 的 A / B 分类与任务优先级、前置由原有表格派生；交叉验证不自动成为强制前置。

修改 Markdown 后重新构建即可更新目录、全文、筛选、对照与关联。新章节必须使用可索引的 ATX 标题；显式锚点不能重复。新模块 / 新状态先在本段及校验规则定义，再更新相应正文，不手改 knowledge-index.json。内容摘要版本用于刷新缓存，不加入构建时间等无意义差异。

## 阅读系统验证 {#reader-verification}

构建会生成[结构校验结果](reading/assets/build-report.json)，列出实际文档 / 记录 / 来源 / 链接数量和检查范围，不写入时间戳。构建工具变更后运行：

```bash
.venv-docs/bin/python -m unittest discover -s tools/docs -p 'test_*.py' -v
node tools/docs/test_search.cjs
.venv-docs/bin/python tools/docs/build_docs.py --check
```

Python 测试覆盖元数据、引用 / 前置、正常互链、重复锚点、源码保留和不安全 HTML / URL / Mermaid 配置；Node 测试使用生成的真实全库索引检查跨文档搜索、组合过滤和阻塞条目。Node 只用于开发校验，日常构建和阅读无需 Node。

浏览器验收使用本地 HTTP：搜索 `Baseline` 并筛选 ADR，结果能进入 ADR-FE-008；治理选择 M11 / 高 / 存在阻塞得到 REV-01 / REV-02；模块对照保留“可进入的工作”；代码复制显示反馈；Mermaid 图及其放大视图正常。页面主题、目录与来源链接复用同一外壳。上述验证只涉及文档阅读系统，不能证明表单 Runtime、Prepared ABI 或跨端实现已完成。
