---
id: ADR-FE-002
title: ADR-FE-002：纯表达式、结构化引用与局部词法 Scope
type: decision
status: accepted
layer: 跨层
modules:
- M02
- M03
tags: []
related:
  decisions: []
sources:
- SRC-L1
- SRC-L2
navigation:
  order: 202
last_reviewed: '2026-10-19'
status_note: 已确认，类型与签名待固化
---

# ADR-FE-002：纯表达式、结构化引用与局部词法 Scope



## 背景与约束 {#adr-002-context}

需要让跨字段计算、深层动态 Props 和重复数据可以静态检查、跨端复用，又不能把 L1 变成通用程序语言。数据位置、词法名称和运行时项身份必须区分；G03 的受限语言边界约束后续接口。

## 已确认选择与备选 {#adr-002-decision}

表达式采用纯 AST，ValueSpec 用显式 `$expr` 递归嵌入，Literal 明确转义。能力调用是同步确定性的 Pure Function，不读外部可变状态、不 I/O、不写 Data；复杂同步校验复用相同能力，Internal assert 保持 boolean。

Reference 采用结构化来源 / 路径；根路径简写固定从 Data 根开始。局部 ScopeBinder 以 one / each 建立词法绑定，禁止任意位置新建 Scope、动态拼写入路径或隐式捕获调用方 Scope。ScopeHandle 与 DataReference 分责。

原资料保留过全局 Scope 注册表、多类可执行配置和泛化表达能力；当前以局部 Binder、纯 AST 和受控命令替代。避免解析间接性及不可分析行为，代价是作者需显式区分计算、触发、写入，复杂算法需版本化能力实现。未实际讨论的语言方案不补写为历史候选。

## 影响与未决边界 {#adr-002-consequences}

L2 按类型递归分析所有合法表达式位置及可能分支，Literal 不扫描，不能执行纯函数发现依赖。L3 求值当前输入，L4 通过统一能力读取动态 Props。AST Union / Literal 消歧、内置签名、短名到 core.* 映射、Schema 类型兼容和错误返回尚需固化；`op + args` 当前保留，改为 call 不是本次决策。

## 来源与关联 {#adr-002-sources}

- 现行：[Reference / Binder](../l1/02-data-reference-scope.md#reference)、[Expression 与使用位置](../l1/03-expression-validation.md#expression)、[Pure Function](../l2-preparation.md#l2-pure-functions)。
- 来源：[第一 / 二组与定稿](../source-map.md#src-l1)、[L2 原件](../source-map.md#src-l2)。[早期记录](../../history/2026-10-16-before-v1-final/changes-2026-10-15.md)保留 AST 方向认可、剩余边界未冻结的状态。
- 关联：[ADR-FE-005](ADR-FE-005-watch-subscription.md)区分读取与触发；[ADR-FE-007](ADR-FE-007-scope-comparison.md)管理真实身份；[OD-11 / 13](../governance.md#open-decisions)处理正式类型与输入交接。
