---
id: L1-RELEASE
title: 修订、待固化事项与发布
type: protocol
status: active
layer: L1
modules:
- M02
- M06
tags: []
related:
  decisions: []
sources:
- SRC-L1
- SRC-L2
- SRC-V07
navigation:
  order: 38
last_reviewed: '2026-10-19'
---

# 修订、待固化事项与发布

> L1 V1.0 架构与语义决策正文；正式类型、Schema 与发布验收状态见各节。

## 从早期方案到当前决策：修订记录 {#history}

> 状态：已收敛

本节为追溯附录，保留每次修订当时的结论及后续替代，不能把第 16 条的自动 Baseline / Reset 重算与第 17 条现行规则并列执行。当前完整规则在所属主题；独立的背景 / 备选 / 取舍见[架构 ADR 入口](../architecture.md#decisions)，来源与章节映射见[来源覆盖](../source-map.md#conclusion-map)。

01

**数据与业务边界**

确定 JSON Schema + 唯一 Working Data；Data、View、Validation 与外部业务执行分离。

02

**表达式与内部规则**

由多种可执行配置收敛为纯 Expression、Constraint 与受控 Command/Reaction。

03

**Scope 的权柄争论**

从可能的跨层 Scope 注册表，收敛为 Data 提供位置、局部 Binder 提供词法别名、L3 提供实例身份。

04

**View Root / Target / Fragment 重复**

统一为 具名 Profile → ViewNode + Named View Template + 静态 $use；不再各自维护定义体系。

05

**view.present 的撤回**

发现与容器/复合 Material 重叠，取消核心 Presentation DSL 和 view.present/view.dismiss。

06

**Binding/Validation 的纠偏**

取消 ValidationMetadata 作为独立 L1 DSL 的倾向；Binding 仅映射端口，字段与校验状态由 Runtime 管理。

07

**Canonical 结构统一**

bindings、slots 使用唯一规范形态；bind、children 可以作为 Authoring 简写。

08

**Typed Template Params 收敛**

采用 schemaRef + DataReference 传参；不创建泛型系统，也不暴露额外的 Template ScopeHandle。

09

**物料约束职责冻结**

Protocol 管机制、Material Manifest 管能力限制、Form Definition 管业务合法性。

10

**L1 架构定稿**

顶层结构及主要领域边界冻结，转入 TS 类型、机器 Schema 和一致性验收。

11

**Profile 去掉单字段包装 · 2026.10.16**

views 的每个具名 Profile 直接对应 ViewNode；原 entry 没有独立语义，予以移除。Profile 名可自由选择，default 不是固定关键字；slots.default 保持插槽语义。基础标识、版本与 metadata 在文档中合并展示为定义信息，协议顶层字段不变。

12

**Pure Function 命名与平台能力边界 · 2026.10.17**

统一采用 Pure Function（纯函数）作为内置和注册纯计算的能力分类，复杂同步校验复用纯函数；Material、Pure Function 与 Host 保留不同职责。Expression 继续使用 `op + args`，调用字段迁移另行决策。L2 消费确定的能力契约，Form Release 锁定版本与不可变制品身份；Host 运行时注册，静态契约可选。具体 [L2 决策与待固化接口](../l2-preparation.md#l2-decisions) 不等于生产协议实现已经完成。

13

**跨层依赖与订阅模型 · 2026.10.17**

区分 Read Dependency、Watch Dependency 与活跃 Subscription。Internal Constraint 自动观察 when + assert，External Constraint 的 dependsOn 统一为 watch 并合并 when 的可见读取；Reaction 保持显式 watch，不追加 when / then 读取。L2 编译 Dependency Plan，L3 统一匹配并激活业务规则，L4 按实际挂载订阅与释放。运行时状态来源不扩展 L1 Reference；通知时机、合并及正式 API / ABI 保留待固化。整合前正文和用户原件见 [来源归档](../../history/README.md#dependency-integration)，现行契约见 [跨层专题](../dependency-reactivity.md)。

14

**L3 执行与诊断修订 · 2026.10.18**

选择不可变 Working Data + 结构共享；有效 Command 同步生效，batch 与 then[] 默认有序、不整体回滚。Reaction 明确为最新状态收敛，待执行实例可以合并，执行后可重新入队；V1 延迟启动、同步 Flush，内部级联归当前轮。Operation 仅表示外部来源。临时有序 Trace 保存实际变化与触发来源，正常释放、异常提取报告；Devtools 自行保存历史。替代早期事务 / 每次触发独立执行候选，保留错误隔离、恢复、通知重入、排序及 Submit 受损范围的未决状态。完整决策见 [L3 专题](../l3-reactive-engine.md#l3-decisions)，原件与整合前正文见 [来源归档](../../history/README.md#l3-integration)。

15

**原始 / 编译后协议与 Watch / Runtime · V0.5（来源 2026.10.18，整合 2026.10.19）**

FormDefinition 与 PreparedForm 严格分工，L3 唯一消费兼容 PreparedForm，不能在 ABI 失败时静默回退解释原始 L1。显式 Reaction.watch 保留，L2 用 Reads / Writes / Watch 分析给建议，作者确认后回写 L1 再编译；不能自动增删触发依赖。可隔离的单 Command 错误记录后继续独立命令与规则，预算超限整体熔断，不做父子执行控制、失败下游禁用或局部 Health / 影响链恢复；这替代第 14 条在 V0.4 中保留的相应候选。缺失与清空由业务 when / Pure Function 明确，不建通用 Reaction Ready 状态机。

初始化 / 新 Scope / Reset 首次执行、通知重入、熔断后 Pending、Validation / Submit 完成契约继续未决；Source Map 与编辑期增量方案为推荐。原始 22 项状态与 12 个跨层场景见 [V0.5 总账及验收](../dependency-reactivity.md#dependency-v05-decisions)，原始字节与整合前正文见 [来源归档](../../history/README.md#protocol-runtime-v05-integration)。阶段归档版本不等于发布新的 L1 Protocol Version，现行 Canonical Reference 与顶层字段保持。

16

**数据变更、依赖索引与 Scope · V0.6 · 2026.10.19**

每条 Command 取得前后不可变 Root 与可稳定读取旧位置的 Scope 视图，一致提交 Data / Scope，定位候选观察者后比较逻辑观察值，临时材料不进入 pending，不传播 ScopeChange。Scope Index 存父级相对位置，完整绝对路径按需解析；Scope 相对观察跟随同一实例，固定路径观察同一位置。用户、Host、Reaction 修改同一字段都走同一检测，不建立派生字段所有权。数据订阅共用匹配，执行事件另走事件观察 / Trace。

首次激活执行策略显式可配置、初始 Reaction 正常收敛后建立 Baseline、Reset 按当前环境重算目标已确认，推进第 15 条当时的初始化未决状态。`runOnActivate` 名称、字段默认值与 API 未冻结；Object.is、Trie / 模板索引、临时 ScopeReadView、整数组替换默认重建及位置型匹配仍为推荐。Reset 主动重算范围 / 入口、Context 改变后的 Dirty 继续待讨论；候选 Schema 尚未因此覆盖新策略字段。原始 [25 项状态与 16 个场景](../l3-reactive-engine.md#l3-v06-decisions) 保留，原件和本次整合前正文见 [来源归档](../../history/README.md#data-scope-v06-integration)。

17

**Runtime / Host 职责再次收敛 · 2026.10.19 用户明确修订**

确认四条原则：数据是事实，不区分字段所有权或编辑来源；常规 Reaction 只由显式 Watch 有效观察值变化驱动；runOnActivate 仅新规则实例首次激活；Dirty、业务 Baseline、Reset 策略归 Host。Runtime 提供稳定 snapshot 与协议执行 / 校验能力，不判断业务结果应否被修复，不提供 isDirty、markClean、resetToBaseline 或绕过依赖的 Reset 重算模式。

第 16 条记录的“Runtime 初始收敛后自动建立基准”和“Reset 按当前环境主动重新计算”已被替代，不继续作为核心确认或待决项。Host 可以在所选完成时点读取 snapshot，自行保存业务基准，再按业务恢复意图生成普通 Command；没有有效 Watch 变化就不重跑已有规则。数据 / Scope 临时前后视图和 Trace 继续服务检测与诊断。真正新建实例可按激活策略处理，不得伪造重建来强制重算现存实例。

用户另已确认 Context 维持现行只读 / Data-only Command 与 Watch 契约，不在本次扩展。例子与 B01–B08 边界验收见 [四条现行原则](../l3-reactive-engine.md#l3-runtime-host-boundary)；来源决策摘录与整合前正文见 [归档](../../history/README.md#runtime-host-boundary)。这是当前对话的明确修订，不新造 V0.7 或正式 Protocol Version。

18

**Validation 校验引擎 · V0.7 · 2026.10.19**

保留完整 JSON Schema 作为根校验域，业务 Constraint 独立执行；Data Change 复用现有索引登记 Pending，正常 Reaction 收敛后执行本轮校验。前置在本轮检查并必要重排，不建立结果反向订阅、通用异步 DAG 或 Validation 触发 Reaction 链。按字段聚合错误方向已收敛，按 Source 保存 / 字段索引派生、消息模板和原子通知是推荐实现；内部仍需异步有效性与完整校验事实，不强制向 UI 暴露每源复杂状态。

来源的“缺失前置则诊断并跳过”保留为当前倾向，A 旧结果有效但仅 B 入 Pending 的增量场景继续待验证；不自动补齐，不静默扩展 Watch。requires、validationMessages、PreparedValidation、Issue 与完整返回 API 未冻结，现行候选 Schema / 正式版本不因此扩展。Context 与第 17 条的 Runtime / Host 职责保持。完整 [19 项来源状态与 16 个验收案例](../l3-validation.md#validation-decisions) 已整合；原始字节和整合前正文见 [来源归档](../../history/README.md#validation-v07-integration)。

## 被排除或延期的能力 {#tradeoffs}

> 状态：已收敛

| 方案 | 不进入核心的原因 | 替代方案 |
| --- | --- | --- |
| 全局 scopes 注册表 | 与 Data Schema 引用重复，提升解析间接性 | 局部 ScopeBinder + 统一实例身份 |
| 通用 Action / Workflow DSL | 把 Form 协议变为应用编排语言 | Command + Host |
| view.present / view.dismiss | 重复容器 Material 的展示职责 | Modal/Drawer/BottomSheet Material |
| 独立 Validation Binding | 同一数据位置重复绑定，增加 L1 语义 | Runtime Field State → 现有 Binding |
| 动态 Template ID | 引入动态 View 选择与状态替换问题 | 静态 $use + 物料内部组合 |
| 通用 Typed Params 泛型 | 类型证明器成本远超当前需要 | schemaRef 的 Typed Data Params |
| Expression 生成写入路径 | 降低引用静态可分析性 | 结构化 DataReference 作为 Command Target |
| 自动双向派生字段镜像 | 制造重复业务状态 | 需要展示用 Expression，需要保存时显式 Command |
| 生命周期脚本与请求 URL | 引入通用外部流程执行机制 | Host API 与 External Constraint |
| 原始 L1 与 Prepared 双轨运行 | 容易绕过同一编译诊断、依赖和锁定语义 | Runtime 只消费兼容 PreparedForm |
| 父子 Reaction / 局部 Health / 局部熔断 | 为独立状态规则引入影响链与恢复状态机 | 可隔离 Command 错误继续；超限整体 Flush 熔断 |
| 通用 Reaction Ready 状态 | 混淆初始化、业务空值与清空后的结果 | 业务 when / Pure Function 明确；首轮激活策略单独验收 |
| 派生字段所有权与规则链传播 ScopeChange | 改变显式触发意图，并把局部位置比较复杂度传到消费者 | 同一 Command 检测、相对 Scope Index、只投递失效标识 |
| 校验结果 PubSub / 通用异步 DAG / Schema Keyword 自动拆分 | 重建响应式与调度系统，增加跨端等价性成本 | 完整 Schema、本轮前置检查与字段聚合；多步外部业务封装同一 Host 能力 |
| 核心 Dirty / 业务 Baseline / Reset 主动重算 | 不同应用对编辑、保存和恢复的定义不同，且可能绕过 Watch | Host 自选稳定 snapshot、定义编辑状态并生成普通 Command |

## 仍需规范固化的事项：不等于重开架构 {#boundaries}

> 状态：待固化

| 事项 | 当前方向 | 固化工作 |
| --- | --- | --- |
| Reference / Expression Union | 类型与用途已经明确 | 确定严格判别结构和 Literal 转义边界 |
| ScopeBinder 单/链 | View 单 Binder、规则可链式绑定 | 用 Schema/TS 校验数组链顺序和遮蔽规则 |
| Pure Function Contract | 同步确定性、受限、类型明确；内置与注册共用调用 | 列出内置签名、`core.*` / 短名别名映射、错误诊断与版本契约 |
| Command 全量结构 | 封闭 7 类动作；batch 有序即时生效、非原子；可隔离错误继续独立行为 | 补完插入 / 移动位置、错误分类和诊断接口 |
| Reaction 收敛与错误 | 最新状态合并、显式首次激活可配置；显式 Command 保留次数、超限整体熔断 | 激活字段 / 默认值、通知、排序、Pending 再触发；不增加队列 / 索引字段 |
| 实例生命周期与快照 | 新实例按 runOnActivate；稳定快照由 Host 按需用于业务基准 | 激活默认值、实例建立 / 替换、snapshot / 完成观察 SDK；业务 Dirty / Reset 不是核心未决项 |
| Scope 与观察粒度 | 父级相对位置；候选定位后比较逻辑观察值 | Object.is / 存在性、位置观察编码、数组整体重建的推荐方案与跨端验收 |
| JSON Schema 兼容性 | Typed Params 引用 schemaRef | 明确兼容性规则与静态不可证明时的诊断 |
| Material / Pure Function Version Resolution | 确定 Catalog Snapshot，Release 锁定版本及制品身份 | 固化锁字段、摘要对象、升级与 Runtime 兼容检查 |
| Interaction Event Context | Event Reference 仅在有效上下文 | 明确事件 Payload Schema 与解析限制 |
| External watch 迁移 | 当前草案使用 watch；合并 when 读取，失效与请求分离 | 正式版本识别、dependsOn → watch 的迁移规则与双字段拒绝 |
| 使用位置与 Prepared 依赖契约 | Read / Watch / Subscription 分离，L2 计划 / L3 匹配 / L4 挂载 | 用矩阵和跨层验收固化；不把候选 ABI 或调度策略写入 L1 |
| Validation 前置与结果 | 完整 Schema + 增量本轮 Constraint + 字段 Issue 聚合 | 验证缺失前置；冻结 requires / 消息覆盖、PreparedValidation、Issue / 完整结果 API、跨端与性能 |
| Formal JSON Schema | Canonical 形状已收敛 | 生成并验证 2020-12 Schema 与 TS 类型一致性 |

> **冻结原则**
> 
> 这些是将“架构共识”工程化为“正式规范”的工作清单。除非样例或校验出现事实上的冲突，否则不再因局部实现问题增设新的顶层领域模型。

## 附录：完整的核心类型关系（概念稿） {#types}

> 状态：待固化

**架构核心类型汇编（用于后续正式 TypeScript 固化）**

```typescript
type JsonPrimitive = string | number | boolean | null;
type JsonValue = JsonPrimitive | JsonValue[] | { [key: string]: JsonValue };
type JsonSchema = Record<string, unknown>; // 采用正式 JSON Schema 类型

type DataReference = { source: 'data'; path: string; scope?: string };
type ContextReference = { source: 'context'; path: string };
type EventReference = { source: 'event'; path: string };
type Reference = DataReference | ContextReference | EventReference;

type ScopeBinder = {
  from: DataReference;
  as: string;
  mode?: 'one' | 'each';
};
type ScopeDeclaration = ScopeBinder | ScopeBinder[];
type ScopeHandleReference = { $scope: string };

type Expression =
  | JsonPrimitive
  | { ref: Reference }
  | { use: string }
  | { op: string; args: Expression[] }
  | { literal: JsonValue };

type ValueSpec =
  | JsonPrimitive
  | { $expr: Expression }
  | { $literal: JsonValue }
  | ValueSpec[]
  | { [key: string]: ValueSpec };

type IssueDefinition = { target: DataReference; code: string };

type InternalConstraint = {
  id: string; kind: 'internal';
  scope?: ScopeDeclaration;
  when?: Expression;
  assert: Expression;
  issue: IssueDefinition;
};
type ExternalConstraint = {
  id: string; kind: 'external';
  scope?: ScopeDeclaration;
  when?: Expression;
  watch: DataReference[];
  target: DataReference;
  requiredForSubmit?: boolean;
};
type Constraint = InternalConstraint | ExternalConstraint;

// Command 具体每种操作的字段请以正式 JSON Schema 为准
// 下方展示稳定的分发类别，非已完整定义的公开类型。
type Command =
  | { op: 'set'; target: DataReference; value: ValueSpec }
  | { op: 'patch'; target: DataReference; value: Record<string, ValueSpec> }
  | { op: 'remove'; target: DataReference }
  | { op: 'array.insert'; target: DataReference; value: ValueSpec; [k: string]: unknown }
  | { op: 'array.remove'; target: DataReference; item: ScopeHandleReference }
  | { op: 'array.move'; target: DataReference; item: ScopeHandleReference; [k: string]: unknown }
  | { op: 'batch'; commands: Command[] };

type Reaction = {
  id: string;
  scope?: ScopeDeclaration;
  watch: DataReference[];
  when?: Expression;
  then: Command[];
};

type InteractionIntent =
  | { type: 'form.command'; command: Command }
  | { type: 'host.emit'; event: string; payload?: ValueSpec };

type MaterialNode = {
  material: string;
  props?: Record<string, ValueSpec>;
  bindings?: Record<string, DataReference>;
  slots?: Record<string, ViewNode[]>;
  on?: Record<string, InteractionIntent>;
};
type ScopeNode = { scope: ScopeBinder; node: ViewNode };
type TemplateUse = { $use: string; with?: Record<string, DataReference> };
type ViewNode = MaterialNode | ScopeNode | TemplateUse;
type ViewTemplate = {
  params?: Record<string, { schemaRef: string }>;
  node: ViewNode;
};

type FormDefinition = {
  protocolVersion: string;
  id: string;
  version: string;
  data: { schema: JsonSchema };
  expressions?: Record<string, Expression>;
  constraints?: Constraint[];
  reactions?: Reaction[];
  views: Record<string, ViewNode>;
  viewTemplates?: Record<string, ViewTemplate>;
  metadata?: Record<string, JsonValue>;
};
```

> **不要误当成可直接发布的 npm 类型**
> 
> 本附录刻意把 `array.insert` / `array.move` 的具体位置描述留作固化项，且 JsonSchema 使用抽象占位。它是已收敛语义的汇编，不是已经编译与验证的完整类型包。

## 正式 V1.0 发布前的验收与交付 {#release}

> 状态：已收敛

- [ ] 生成完整 `form-definition.types.ts`，消除占位和不严谨 Union
- [ ] 生成完整 `form-definition.schema.json`，与 TypeScript 一致
- [ ] 校验简单表单 / 动态数组 / 多端保险表单三类样例
- [ ] 反例验收：非法引用、Scope 越界、模板参数类型不匹配、端口不兼容
- [ ] 冻结 Material Manifest 版本解析约定及 Pure Function 合约
- [ ] 发布规范语义说明、版本兼容说明与变更记录

上述勾选仅供阅读时自查，不自动代表项目真实完成状态。后续阶段 L2、L3、L4 只能在遵守这份 L1 语义的前提下选择自己的实现策略。

> 最终决策：**停止 L1 的开放式抽象扩张，进入 Canonical Type / JSON Schema / 反例验收**。需要修订时提出能复现的协议冲突，而不是重新设计已确定的领域层次。
