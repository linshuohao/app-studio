---
id: PROTOCOL-L1
title: L1 Definition Protocol V1.0
type: protocol
status: active
layer: L1
modules:
- M02
- M03
- M04
tags: []
related:
  decisions:
  - ADR-FE-002
  - ADR-FE-003
  - ADR-FE-005
  - ADR-FE-006
sources:
- SRC-L1
navigation:
  order: 30
last_reviewed: '2026-10-19'
---

# L1 Definition Protocol V1.0

从一个姓名输入框开始，遇到计算、重复项、视图复用和外部业务时，再逐步学习对应能力。普通表单先读第一部分即可；已有明确问题时，直接搜索侧栏中的章节名称。

L1 的架构与语义已收敛，正式类型、Schema 与发布验收仍待完成。以下分组只安排阅读次序，协议正文、约束和阶段状态以各节为准。

本页负责 L1 声明与完整协议查阅。初次了解整个框架、宿主接入和排障，先读 [使用与开发指南](../usage-guide.md)；思想、层级和设计取舍见 [设计者指南](../architecture.md)。

## 从一个姓名输入框开始 {#learn-basic}

先看极简表单，再沿着“数据结构 → 数据位置 → 输入端口”理解它：`data.schema` 定义姓名，`views` 选择一个物料，`bindings.value` 把输入端口连到 `/name`。物料是预先注册的 UI 能力；此时只需理解这条连接，具体契约留到宿主接入时再查。

Reference 一节先读根数据路径即可，其他来源和局部名称遇到时再回查。能解释姓名存在哪里、输入框连接哪里，就可以开始描述普通表单。

- [极简表单：先看完整形状](07-examples.md#simple)
- [数据：结构、当前值、默认值与输出](02-data-reference-scope.md#data)
- [引用：如何指向一个数据位置](02-data-reference-scope.md#reference)
- [绑定：输入端口如何连接数据](05-view-material-host.md#binding)

## 增加计算、校验与联动 {#learn-rules}

有了字段，再分别解决三个问题：怎样计算一个值，怎样判断业务是否合法，怎样在数据变化后修改另一个值。Expression 负责计算，Constraint 负责断言或声明外部校验义务；Command 负责受控修改，Reaction 把触发条件与修改连接起来。

先区分这些职责，再查各节完整结构。示例中的 `scope` 用于把规则应用到每位被保人，下一部分解释它；首次阅读先关注 `assert`、`target` 和 `watch → then`。只需要基础 Schema 约束的普通表单，可以暂时跳过本部分。

- [表达式：计算值](03-expression-validation.md#expression)
- [约束：判断业务是否合法](03-expression-validation.md#constraint)
- [命令：受控修改数据](04-command-reaction.md#commands)
- [联动：数据变化后执行命令](04-command-reaction.md#reactions)
- [校验状态：何时具备提交条件](03-expression-validation.md#validation)

## 把同一套能力用到重复数据 {#learn-repeated-data}

出现“多位被保人”时，原有字段和规则需要分别指向当前项。ScopeBinder 在已有数据位置上建立局部名称；`each` 为每项建立上下文，在 View 中也负责重复实例化子视图。需要排序或删除当前项时，再学习稳定身份 ScopeHandle。

读完后回看上一部分带 `scope` 的规则，应能解释它们如何分别作用于每一项，以及数组排序后如何仍然定位同一项。

- [作用域：为当前数据位置命名](02-data-reference-scope.md#scope)
- [实例身份：排序和删除时定位当前项](02-data-reference-scope.md#scope-handle)

## 组合视图并复用到不同场景 {#learn-view-composition}

需要容器布局、复用字段组或同时提供 PC 与移动端视图时，再展开 View 的完整结构。Slots 组合子节点，Template 静态复用结构并传入数据位置，Profile 选择场景入口；它们都继续连接同一份业务数据。

先理解组合关系，再查模板参数的类型约束。一个输入框的表单只用到 MaterialNode，无需先掌握其余节点形态。

- [视图节点：物料、作用域与模板引用](05-view-material-host.md#view)
- [插槽：组合容器中的子视图](05-view-material-host.md#slots)
- [模板：复用结构并传入数据位置](05-view-material-host.md#templates)
- [多视图：选择入口与按需交付](06-lifecycle-profiles.md#profiles)

## 连接物料、宿主与表单生命周期 {#learn-integration}

物料的端口、属性、插槽和语义事件由 Manifest 声明。普通输入通过 Binding 更新数据；按钮等语义事件可以发出数据命令或宿主事件。Host 负责网络、业务基准 / Dirty / Reset 意图和真实提交；L3 管实例与规则，runOnActivate 仅新实例首次激活，业务恢复生成普通 Command 并遵守有效 Watch 变化检测。

这一部分把协议声明与外部执行连接起来。读完应能判断一项业务需求由 Definition、Material 还是 Host 承担。

- [物料契约：能力与限制由谁声明](05-view-material-host.md#materials)
- [交互：语义事件连接命令或宿主](05-view-material-host.md#interaction)
- [宿主集成：三条外部能力路径](05-view-material-host.md#host)
- [生命周期：初始化、更新与提交](06-lifecycle-profiles.md#lifecycle)

## 对照完整协议与业务组合 {#reference-protocol}

掌握前面的使用场景后，再对照完整顶层结构、表示形式、层级边界与核心决策。完整保险案例把这些能力放进同一份定义，适合核对组合是否保持职责与不变量。进行协议评审或实现对接时，也可以直接从这里查阅。

- [定稿状态与规范声明级别](01-foundation.md#summary)
- [设计目标与硬约束](01-foundation.md#principles)
- [四层架构与外部契约](01-foundation.md#architecture)
- [FormDefinition 完整顶层结构](01-foundation.md#top-level)
- [Canonical、Authoring 与 Prepared](01-foundation.md#representations)
- [核心决策总表](01-foundation.md#decisions)
- [完整保险投保示例](07-examples.md#sample)
- [业务组合与不变量核对](07-examples.md#walkthrough)

## 查阅决策依据与发布事项 {#reference-release}

需要追溯取舍、核对完整类型关系或推进规范固化时，再查本部分。这里保留修订理由、被排除能力与待完成事项；概念类型和候选样例的阶段状态不随阅读重排而改变。

- [修订记录](08-decisions-release.md#history)
- [被排除或延期的能力](08-decisions-release.md#tradeoffs)
- [仍需固化的事项](08-decisions-release.md#boundaries)
- [完整核心类型关系（概念稿）](08-decisions-release.md#types)
- [正式发布前的验收与交付](08-decisions-release.md#release)
