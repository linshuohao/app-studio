---
id: DESIGN-L3-VALIDATION
title: L3 Validation：校验执行、结果与字段订阅
type: design
status: active
layer: L3
modules:
- M10
- M11
- M12
- M13
tags: []
related:
  decisions:
  - ADR-FE-010
sources:
- SRC-V07
navigation:
  order: 70
last_reviewed: '2026-10-19'
---

# L3 Validation：校验执行、结果与字段订阅

本专题维护校验引擎的设计，承接 V0.7 来源的 18 个章节、19 项决策和 16 个验收案例。数据更新、Scope 与 Reaction Flush 继续遵循 [L3 执行契约](l3-reactive-engine.md)，不在这里重建一套响应式系统。设计方向、推荐实现和待验证边界分别标注；概念类型、`requires`、消息覆盖与 SDK 均未冻结，也没有生产校验引擎实现。原始 HTML 和整合前正文见 [来源归档](../history/README.md#validation-v07-integration)。

## 目标、职责与当前状态 {#validation-baseline}

Validation 读取业务数据，产生结构化 Issue，供 View / Host 消费。它不修改 Working Data，不拦截业务不合法的输入，不回滚 Command，也不自动修复结果。Dirty / 业务 Baseline / Reset 仍归 Host，Touched 和错误显示时机归交互层。

| 状态 | 当前设计 |
| --- | --- |
| 已收敛 | 保留完整 JSON Schema；业务 Constraint 独立于 Schema 库扩展；Reaction 正常收敛后校验；复用 Data Dependency Index；只整理本轮任务，不建立前置结果 PubSub；按字段聚合错误 |
| 当前倾向，仍需验证 | 本轮缺少前置任务时报告配置 / 调度诊断并跳过后置，不自动补齐；旧有效前置未入本轮的增量场景尚未解决 |
| 推荐实现 | 按 Source 保存结果、字段索引派生；同步结果原子替换；默认消息模板加局部覆盖；实例代次隔离；独立任务继续 |
| 必须满足的正确性 | 过期或已销毁实例的异步返回不能提交；执行异常 / 跳过 / 未校验不能冒充通过；无 Issue 不等于校验完备 |
| 待固化 / 验证 | 前置的字段 / 规则范围与语法、PreparedValidation、Issue / 完整结果 API、通知时序、性能与 Web / Dart 一致性 |

Reaction 和 Validation 共用 Data / Scope / 依赖匹配，分别管理待执行任务与完成语义。需要“条件不成立则清空保障”时，两者可以复用同一纯业务条件；不让 Reaction 监听 Validation Result 来产生 Data → Reaction → Validation → Reaction 的跨轮循环。异步后续业务动作由 Host 明确发出 Command。

背景、原有备选及代价见 [ADR-FE-010](decisions/ADR-FE-010-validation.md)。本篇保留完整执行、结果、异步与完备性说明，末尾来源表为追溯附录；缺失前置与跨轮资格的张力在 [REV-01 / 02](governance.md#rev-01)有具体反例，异常 Flush 交接见 [REV-03](governance.md#rev-03)。这些问题尚未被本次整理解决，正式语法不能据 ADR 或审查建议擅自扩展。

## 一次联系人导入如何完成校验 {#validation-story}

Host 选择历史联系人，以普通 Command 导入被保人。每条有效修改经过已有 Data / Scope 前后值比较，登记 Reaction 和受影响 Constraint。Reaction 按自己的显式 Watch 收敛，Validation 随后读取当前数据。

```diagram
{
  "id":"figure-validation-round",
  "title":"同一变化入口，两种执行职责",
  "rows":[
    [{"title":"Command → Data + Scope","body":"比较有效观察值；共享 Dependency Index 定位消费者"}],
    [{"title":"Reaction Pending → Flush","body":"同步联动收敛；后续 Command 继续补充校验失效"},{"title":"Validation Pending","body":"根 Schema 待校验标记 + ConstraintInstanceId 去重集合"}],
    [{"title":"根 Schema + 本轮 Constraint 链","body":"完整结构校验；检查本轮前置、必要重排，再判断准入","major":true}],
    [{"title":"Source Issues → Field Issue Index","body":"保留来源、按稳定 Scope 定位，原子替换来源贡献"}],
    [{"title":"View / Host","body":"读取或订阅字段聚合；完整校验另核对执行与新鲜度"}]
  ],
  "arrows":["↓","↓","↓","↓"],
  "note":"正常 Reaction 收敛后启动校验；没有 Reaction 时也有校验入口。异步不阻塞同步 Flush；前置缺失、异常与熔断衔接不得解释为业务通过。"
}
```

根 Schema 检查必填、类型、证件号码静态约束。C1 检查证件类型与号码一致性，C2 执行身份核验，C3 检查独立年龄规则。若 C2 明确以前置 C1 为条件，则先整理 C1 / C2 的顺序，再核对 C1 是否通过；C1 失败只使 C2 跳过，C3 继续。各来源的 Issue 最终聚合到对应成员的字段。一轮校验不要求全部外部请求同步完成，独立异步操作可以并发。

## 完整 JSON Schema 与平台 Adapter {#validation-schema}

首版保留完整标准 Schema，作为根级校验域。自动拆成字段或 Keyword 单元可能破坏 oneOf、条件组合与 unevaluated* 等语义，还要求额外依赖分析；先测完整校验成本，再评估能够证明等价的局部优化。根数据传入校验器，由 Schema 决定适用规则，并非无条件对全部字段执行全部关键字。

| 层 / 平台 | 负责什么 | 不携带什么 |
| --- | --- | --- |
| L1 | 完整 Schema、业务 Constraint；现有断言 / 外部义务语义继续有效 | 不加入校验状态、请求或库私有规则 DSL |
| L2 | 保留 Schema 资源、引用与 Adapter 约定；准备规则读取依赖和消息映射 | 不把 Ajv 生成的 JavaScript 函数跨端传输，不装入实例结果 |
| Web / Node Adapter | 以 Ajv 的 Draft 2020-12 入口为候选，缓存编译后的校验函数，再验证当前 Root | 不在每次输入时重新 compile，不修改 Working Data |
| Flutter / Dart Adapter | 选择满足约定 Draft / 关键字范围的实现，归一化为同一 Issue 契约 | 不宣称现有 Dart 库已通过兼容验收 |

复用编译函数不同于缓存数据校验结果：每次调用仍校验本次数据，不能认为未重新编译就自动得到了字段级增量结论。[Ajv 的编译复用说明](https://ajv.js.org/guide/managing-schemas.html#re-using-validation-functions)支持这种使用方式。

```typescript
// Adapter 概念示意；preparedSchema 指已有 Schema 资源，不冻结 Prepared 字段。
import Ajv2020 from 'ajv/dist/2020';
const ajv = new Ajv2020({
  allErrors: true,
  strict: true,
  useDefaults: false,
  coerceTypes: false,
  removeAdditional: false
});
const validateRoot = ajv.compile(preparedSchema); // 按资源、版本和选项复用
function validateCurrentRoot(dataRoot: unknown) {
  return validateRoot(dataRoot)
    ? []
    : normalizeAjvErrors(validateRoot.errors ?? []);
}
```

Adapter 禁用赋默认值、类型转换、移除额外属性等会修改输入的选项，保持“校验只读”边界；这些选项的作用见 [Ajv 数据修改说明](https://ajv.js.org/guide/modifying-data.html)。装载时的默认值按已有生命周期契约处理，不借校验回写数据。

业务 Constraint 由 Expression / Pure Function / Host 外部能力执行，沿用 Internal `assert: boolean` 与 External 义务，不改造成 Ajv 自定义 Keyword 的跨端 ABI，也不据来源的 `execute(): Issue[]` 伪代码放宽 L1 断言返回类型。跨端需对齐 Draft、关键字、format 是否作为断言、引用解析、数字 / 正则行为、Issue 目标和消息；正式支持范围与 Dart 选型由一致性测试确定。

## 增量登记与校验入口 {#validation-pending}

匹配发生在 Command 的有效 Data Change 阶段。已有 Dependency Index 定位候选，再比较观察值，命中的 ConstraintInstanceId 加入本轮集合；Runner 获取该集合，不扫描所有注册 Constraint 再判断谁读了修改字段。根 Schema 保守观察整个 Working Data，有效修改后登记一次待校验标记。

```typescript
// 概念结构，不是冻结接口。
interface PendingValidation {
  schemaNeedsValidation: boolean;
  constraints: Set<ConstraintInstanceId>;
}
// Data Change：共享索引与观察值比较已完成后分别投递。
// Reaction → pendingReactions.add(instanceId)
// Constraint → pendingValidation.constraints.add(instanceId)
// Root Schema → schemaNeedsValidation = true
```

来源中的 `schemaDirty` 只是“根 Schema 需要重新校验”的内部工作标记，现行示意称 schemaNeedsValidation，避免与 Host 的业务 Dirty 混淆。它不记录用户编辑来源，也不重新引入核心编辑状态。

| 变化 / 入口 | 本轮范围 |
| --- | --- |
| 修改一位被保人的 age | 根 Schema 一次；只登记有效观察值变化的 Constraint 实例 |
| 多 Command 命中同一规则 | Pending 去重；Reaction 造成的后续变化继续登记，正常收敛后按最新输入执行 |
| 同值写入 / 整对象导入 | 无有效变化不新增任务；对象导入按相关子路径观察值比较，不因索引命中就执行 |
| 没有 Reaction 被触发 | 校验仍有独立启动入口，不以必须出现一轮 Reaction 为前提 |
| 初始化 / 新 Scope / 主动校验 | 显式覆盖应检查的规则；不等待第一次 Data Change，不以 subscribe 代替初次执行 |
| Host 完整校验 / Submit | 根 Schema + 全部适用 Constraint 构造完整校验链，不能用普通增量集合冒充完整性 |

Internal 依赖仍来自 when + assert；External 仍以显式 Data watch + when 可见读取标记失效。V0.7 给出数据变化后的自动增量校验路径，但“旧结果失效”和“立即请求 Host”继续分开：外部请求的自动策略、blur / 主动校验入口及通知节流尚未冻结，不能把登记 Pending 等同于每次输入必发请求。网络、重试、取消由 Host 实现，Runtime 管结果适用性。

## 本轮前置检查、重排序与四种推演 {#validation-round}

本轮任务以配置顺序为稳定起点；执行前检查前置是否在本轮，必要时重排，使前置先于后置。同步 / 异步是执行形式，不据此把全部 Constraint 强分为两个固定阶段。根 Schema 是基础校验域，但其结果如何成为“字段有效性前置”仍需明确，不能以根级任一错误阻断全部无关 Constraint。

`requires` 是来源使用的前置关系占位名称，**尚未作为现行 Canonical 字段发布**。引用哪些字段 / 规则、跨 Scope 如何绑定、字段有效性包含哪些同步校验、组合错误如何归属，均待固化。运行时前置使用解析后的具体实例身份，不能把不同数组项的同名规则混成一个任务。

| 场景 | 初始本轮任务 | 整理与执行结果 |
| --- | --- | --- |
| 正常 | Schema、A、B；B 以前置 A 为条件 | A 通过后 B 执行 |
| 乱序 | B、A | 重排 A → B；排好序仍须判断 A 已通过 |
| 缺前置 | 仅 B，B 引用 A | 当前倾向：诊断缺失并跳过 B，不补入 A；增量兼容性待验证 |
| 前置失败 | A、B、独立 C | A 产生自己的业务 Issue；B 跳过，不伪造 B 业务失败；C 继续 |

自依赖、环路、非法引用均需诊断，排除无法合法执行的任务与受其影响的后置，独立任务继续。排序只能表示先后，不能把“已排在前面”视为“已执行且通过”。跳过、执行异常或尚未完成均不等于通过；前置资格丧失时后置旧来源 Issue 不再有效。

### 最小整理算法及其限度

```text
pending = 本轮去重后的任务，保留配置顺序
selected = 本轮任务身份集合
重复：排除前置不在 selected 的任务，记录缺失诊断
      直到集合不再变化（后置依赖无效任务时也被排除）
ordered = []
重复：选配置顺序中第一条尚未排出、全部前置已排出的任务
      若存在，将其加入 ordered
      若不存在，对剩余无法排序任务报告环路 / 受环阻塞诊断并停止
执行 ordered：检查本轮前置的实际结论，满足才执行；独立任务继续
```

这是只处理本轮任务的概念算法，不遍历全部已注册规则。直观实现可以扫描本轮列表；任务多时可用本轮临时入度表优化，不必持久维护前置结果反向索引或发布订阅。剩余无法排序者可能包含环成员和受环阻塞的后置，不能都误报为环成员。

跨 Constraint 的异步前置等待尚未定义，不能从任务返回 Promise 的示意中推导出通用 DAG 支持。多步异步 A → B 优先由一个 External Constraint 的 Host 实现封装；独立异步任务可以并发，发起顺序不强迫逐个 await。

### 增量缺失前置是当前最优先的待验证问题

A 观察 idNumber；B 观察 name 并以前置 A 为条件。只修改 name，Pending 可能只有 B，即使 A 以前已有有效结论。来源同时记录了“本轮缺失就诊断并跳过”的最新倾向和“是否接受这种增量行为”的待验证状态；现行正文保留两者，不将其提升为最终执行契约。

后续需用业务实例判断坚持严格本轮规则，还是由编译契约保证后置可能触发时前置也进入本轮；旧有效结论能否使用也需明确。当前不自动补齐，不擅自使用历史通过结果，不静默扩展任何业务 Watch。这是 Validation 前置的未决范围，不改变 Reaction 显式 Watch 原则。

## 结果按来源保存，按字段聚合 {#validation-results}

推荐 `issuesBySource` 作为结果事实来源：根 Schema、每个绑定 Scope 的 Constraint 实例分别贡献 Issue。`fieldIssueIndex` 是从来源结果派生的查询索引，以稳定 ScopeId + 相对路径定位字段；不是第二份业务事实，也不由 L4 重新聚合一遍。

```typescript
// 概念算法；SourceId / IssueRef 等正式字段、顺序和去重待固化。
function publishIssues(sourceId: SourceId, next: ValidationIssue[]) {
  const old = issuesBySource.get(sourceId) ?? [];
  const affected = collectAffectedFieldKeys(old, next);
  issuesBySource.set(sourceId, next);
  updateFieldIssueIndex(sourceId, old, next);
  notifyAggregatesThatChanged(affected);
}
```

例如 root-schema 对成员 A 的 age / name 各有 Issue，age-constraint@A 也对 age 报错。字段 age 聚合两个来源；根 Schema 重跑只替换自己的贡献，不清除业务 Constraint 的错误。仅维护一份 formErrors 数组难以准确撤销各来源旧贡献，故保留来源所有权。

根 Schema 的物理 JSON Pointer 由 Adapter 结合**本次校验输入对应的 Scope 读取视图**转换成稳定成员身份 + 相对路径，不能用已变化的位置把旧结果附给另一成员。对象 / 数组错误可归容器或 root，不强迫伪造子字段。现行推荐在当前 Root 同步完成根校验；若以后延迟计算，须保持其数据 / Scope 配对与新鲜度。

Issue 的最小字段、稳定排序、去重、根级查询与多目标表示还未冻结。Internal Constraint 沿用已有声明目标与错误码，Source 保存 / Field 聚合不自动扩展其返回协议。

## 消息生成、字段订阅与展示 {#validation-messages-subscription}

消息推荐按“字段 / 约束专属覆盖 → 平台关键字模板 → 通用回退”选择。Schema 的 title 可提供显示名；maximum 可用“{title}不能超过 {limit}”，required 可用“请填写{title}”。无需作者为每个 JSON Pointer 维护重复提示。

来源 `validationMessages` 示例是概念性 L1 扩展，覆盖键如何关联字段、Schema / Constraint / Scope 以及多语言资源均未冻结，**本次不新增顶层字段或修改候选 Schema 接受它**。底层错误先归一化为结构化 Issue，消息覆盖不能改变校验是否通过。

Ajv 的 instancePath、keyword、schemaPath、params 可供 Adapter 转换；required 的缺失属性位于 params.missingProperty，须与父路径组合并正确编码 Pointer，不能直接把父对象当作缺失字段。其他错误仍按自身关键字语义归属，不一概套用此规则。底层字段定义见 [Ajv 错误接口](https://ajv.js.org/api.html#validation-errors)；Dart Adapter 需给出相同语义。

```typescript
// 概念 SDK；不增加 L1 validationBind / errorBind。
const field = { scopeId: 'insured-A', path: ['age'] };
const readIssues = () => runtime.getIssues(field);
const unsubscribe = runtime.subscribeIssues(field, () => {
  renderIssues(readIssues());
});
```

| 情形 | 推荐发布行为 |
| --- | --- |
| Schema 重跑，字段聚合内容相同 | 不发送没有内容变化的字段通知 |
| 同步校验旧结果失效至新结果就绪 | 聚合原子替换，避免旧 → 空 → 新闪烁；内部仍及时标记结论不再有效 |
| 异步输入有效变化 | 撤销该来源过期 Issue，不清除其他来源；是否显示 loading 由 UI 决定 |
| 数组成员移动 | 相对字段订阅仍跟随同一 ScopeId；固定物理位置观察按原有位置语义解释 |
| Scope 删除 / 实例销毁 | 清理来源贡献、派生索引及对应实例订阅；旧返回不能恢复它们 |

View 主要消费字段聚合，不必逐步感知每个校验单元的内部执行状态。L4 可封装 Vue Hook、Flutter Stream / Listenable 等接入。减少 UI 状态暴露不等于删掉内部有效性：请求代次、是否完成、是否过期仍供运行正确性与完整校验使用。Dirty、Touched、spinner 和何时展示错误不因此进入 L3。

## 异步结果与实例生命周期 {#validation-async}

外部校验由 Host 注册的能力执行。每个 Constraint 实例独立管理输入 / 请求代次及 Scope 存活，不能仅以全表 Data Version 变化丢弃所有无关请求。返回成功和异常都要做同样的适用性保护，避免销毁后旧错误报告重新污染结果。

```typescript
// 概念保护流程；invokeHostValidator / 输入和代次协议尚待固化。
async function runExternal(unit: ConstraintInstance) {
  const generation = unit.generation;
  const scopeId = unit.scopeId;
  const input = readCurrentInput(unit);
  const isCurrent = () => isScopeAlive(scopeId)
    && isCurrentInstance(unit)
    && unit.generation === generation;
  try {
    const issues = await invokeHostValidator(unit, input);
    if (!isCurrent()) return;
    publishIssues(unit.sourceId, issues);
  } catch (error) {
    if (!isCurrent()) return;
    reportExecutionError(unit, error);
  }
}
```

有效输入变化、实例替换 / 销毁、前置资格丧失须使旧请求不再适用。重复请求相同输入时仍需区分当前请求，具体 token 与代次 API 待固化；取消只是优化，不能代替返回时核对。前置失败使后置跳过，不产生“后置验证失败”业务 Issue；执行异常写诊断与不完备结论，不伪装业务通过。

这里不建立前置结果 PubSub。当前轮次遇到前置失败或输入 / Scope 失效时保证正确；跨轮前置变化但后置未入 Pending 的完整资格失效规则，应随增量缺失前置问题一起固化，不能暗中依靠新反向订阅系统兜底。

Context 沿用用户已确认的 Host 提供、表达式只读契约。本轮不增加 Context Command、External watch 的 Context 引用或 Reaction.watch 类别。完整校验若使用 Context，应与调用时的受控输入条件关联；Host 更新相关上下文后不能继续把旧完成证明用于新输入。如何识别上下文变化、重新请求完整校验的 SDK 仍待定，不能反推自动 Context 触发链。

## 完整校验、Readiness 与异常轮次 {#validation-completeness}

| 入口 | 范围 | 完成含义 |
| --- | --- | --- |
| 普通自动增量 | 根 Schema 待校验项 + 本轮命中的适用 Constraint | 更新当前来源结果和字段聚合，不证明全表已完整通过 |
| 显式完整校验（validateAll 为概念名称） | 当前根数据与全部适用 Constraint，构造完整链 | 需核对执行完成、业务失败、诊断、异步有效性与调用输入 |
| Submit 准备 | 所需联动、Schema / Internal、当前适用且 requiredForSubmit 的外部义务、输出有效性 | Host 再决定业务许可、保存与真实提交；非必需外部结果如何返回随 API 固化 |

`getIssues().length === 0` 只能说明当前没有展示出来的 Issue，不能证明必要规则均执行并通过。完整结果至少需区分当前通过（valid）、业务不通过（invalid）、未完成 / 执行异常 / 配置阻塞（incomplete）、输入已改变（stale）的语义；名称、组合优先级、返回类型与等待范围尚未冻结。来源 D17 将配置错误的完整返回列为待验证，当前只保证不能把它当作 valid。

数据变化时，单个外部结果依据自身输入与实例判断是否仍适用；完整校验证明则关联该次所验证的整体输入。无关字段变化不应误伤独立请求，却可能使上一份全表完整证明不再对应当前表单。这两个判断层次不能混用。

正常路径在所需 Reaction 收敛后校验；未触发 Reaction 也必须能检查；异步完成不纳入同步 Flush。发生可隔离 Command 错误或整体 Flush 熔断时，校验是否继续、返回哪个 Outcome、如何重试和判定 Submit 完成仍待固化，不把队列空或同步校验通过解释为整个异常轮次成功，也不恢复局部 Health / 下游禁用设计。

## 跨层交付、替代方案与取舍 {#validation-layers}

| 层 | 本专题新增说明 | 保持的边界 |
| --- | --- | --- |
| L1 | 完整 Schema + 业务 Constraint；有限前置与消息覆盖的语义方向 | requires / validationMessages 尚非正式字段；Internal boolean、External Data watch 保持 |
| L2 | PreparedValidation 方向：解析规则 / 字段引用、读取依赖、消息计划与执行器身份 | 可序列化；不保存实际 Pending / 结果，不自动改 Reaction Watch |
| L3 | Data 匹配 → Pending → 本轮整理 / 执行 → Source Issues → 字段聚合 | 不增加全局异步 DAG、前置结果 PubSub、Keyword 局部引擎或编辑状态 |
| L4 / Host | 按字段查询与订阅；Host 执行外部能力，决定交互 / 保存 / Submit 策略 | 数据回写须显式 Command；校验报告另走有效性入口 |

原候选“固定 Schema → 全部同步 → 全部异步”改为根 Schema 基础域 + 按前置整理的本轮 Constraint 链；原候选“复杂源状态全部向 UI 暴露”改为字段聚合消费，内部保留必要有效性。自动局部 Schema 拆分、前置结果反向索引、Reaction 监听校验结果、运行时自动补齐缺失前置均不作为当前采用方案。完整 Schema 的全量成本和严格缺失策略的业务影响是明确代价，需由基准 / 业务案例判断，不能为简化描述隐藏。

## V0.7 来源决策与现行处理 {#validation-decisions}

以下编号属于 V0.7 自身命名空间，不与 L3 R01–R26、V0.5 / V0.6 的 D 编号混合。保留来源标题、说明与状态；“已收敛”表示设计意图，不等于 API 冻结。D06 的倾向须与 D14 的增量待验证状态一起阅读。

| 来源编号 | 来源决策 | 来源状态 | 来源说明 | 现行处理 |
| --- | --- | --- | --- | --- |
| D01 | 完整 JSON Schema 首版不自动拆分 | 已收敛 | Ajv / Dart 接收完整标准 Schema，编译执行交给平台 Adapter。 | 沿用来源状态；完整约束见本专题对应章节 |
| D02 | 自定义 Constraint 独立于 Ajv 扩展 | 已收敛 | 表达式 / Function / External 在 L3 统一校验容器内执行，不做自定义 Ajv Keyword 的跨端 ABI。 | 沿用来源状态；完整约束见本专题对应章节 |
| D03 | Reaction 先收敛，Validation 后执行 | 已收敛 | 校验不改 Working Data，也不默认让 Reaction 监听校验结果。 | 沿用来源状态；完整约束见本专题对应章节 |
| D04 | Constraint 增量触发依赖现有 Index | 已收敛 | Data Change 时登记 Pending；到校验阶段不遍历全部 Constraint。 | 沿用来源状态；完整约束见本专题对应章节 |
| D05 | 前置关系采用本轮有序链 | 已收敛 | 按数组配置顺序，执行前检查 requires、必要时重排序；不建立前置结果 PubSub。 | 本轮排序方向沿用；requires 引用和异步等待语法未冻结 |
| D06 | 缺失前置按用户最新意见作为本轮错误处理 | 已收敛 | 缺失时报告诊断并跳过受影响任务；如何与增量 Pending 兼容待验证。 | 保留严格缺失倾向；须结合 D14，未提升为最终增量契约 |
| D07 | 跨异步前置优先封装同一 External Constraint | 已收敛 | 避免 Runtime 负担复杂跨异步链路。 | 沿用来源状态；完整约束见本专题对应章节 |
| D08 | 校验错误按字段聚合供 L4 订阅 | 已收敛 | 一个字段可同时来自 JSON Schema、业务 Constraint 与 External。 | 沿用来源状态；完整约束见本专题对应章节 |
| D09 | 按 Source 保存、字段索引派生 | 推荐实现 | 保证各校验来源原子替换和撤销旧 Issue。 | 来源存储和字段派生为推荐；不是两份独立真相 |
| D10 | 同步错误原子更新，避免闪烁 | 推荐实现 | 仅在聚合内容真正变化时通知字段订阅者。 | 沿用来源状态；完整约束见本专题对应章节 |
| D11 | 错误消息默认模板加局部覆盖 | 推荐实现 | 不要求作者维护大规模 JSON Pointer 错误文案表。 | 沿用来源状态；完整约束见本专题对应章节 |
| D12 | 前置不通过只跳过当前后置任务 | 推荐实现 | 其他独立任务继续，跳过不等于通过。 | 沿用来源状态；完整约束见本专题对应章节 |
| D13 | 异步结果代次隔离 | 推荐实现 | 输入变化、前置不再满足或 Scope 销毁时旧返回不能提交。 | 过期不能提交是必须满足的正确性；代次 / token 是推荐实现 |
| D14 | 仅增量触发 B 而前置 A 未入 Pending | 待验证 | 严格缺失跳过可能导致合法的增量请求不执行；保留最新偏好，需业务验证。 | 沿用来源状态；完整约束见本专题对应章节 |
| D15 | 字段有效性前置的精确范围 | 待验证 | 是仅 JSON Schema 同步错误、还是包括明确的同步 Constraint；根级组合错误如何归属。 | 根级错误不得据此默认阻断全部规则；精确范围待验证 |
| D16 | Constraint 配置 API 语法 | 待验证 | requires 的字段 / 规则引用格式、L1 和 PreparedValidation 的公共类型尚未冻结。 | requires / validationMessages 不新增为现行候选 Canonical 字段 |
| D17 | 完整校验对配置错误的处理 | 待验证 | 缺失前置、环路及外部异常需返回 incomplete，不能当作业务 valid。 | 不把配置异常当作 valid；完整返回类型与优先级仍待固化 |
| D18 | 同步 Schema 全量校验性能基准 | 待验证 | 先测目标设备真实表单，再决定是否增加局部优化。 | 沿用来源状态；完整约束见本专题对应章节 |
| D19 | 校验通知与高频输入的时序 | 待验证 | 默认合并同步轮次；是否加延迟/节流取决于实际性能与体验。 | 沿用来源状态；完整约束见本专题对应章节 |

## 设计验收与下一步 {#validation-acceptance}

以下 V01–V16 对应来源的 16 个案例，是后续实现验收，**不计入当前候选验证器通过统计**。

| 编号 | 场景 | 预期与证据边界 |
| --- | --- | --- |
| V01 | 基础类型 / 必填 / 枚举错误 | 根 Schema 产生标准化 Issue，Data 不因业务不合法而回滚 |
| V02 | 全量 Schema 反复校验 | 复用编译函数；Web / Dart 同数据结果对照，缓存编译不冒充增量结果 |
| V03 | Data 同值写入 | 没有有效观察值变化，不新增增量 Constraint 任务 |
| V04 | 多 Command 命中同一 Constraint | Pending 去重，正常收敛后本轮执行一次 |
| V05 | 对象整体替换 | 子字段观察值有效变化才使相关实例入队 |
| V06 | 数组移动与 Scope | Issue 跟随逻辑成员，不错误附着到原物理位置的其他人 |
| V07 | Schema / 业务错误重叠 | 同一字段聚合两类来源，不互相覆盖 |
| V08 | 根 Schema 部分错误消失 | 仅撤销该 Source 旧贡献，其他 Source 不受影响 |
| V09 | 前置项排在后面 | 本轮重排，无前置结果二次发布订阅 |
| V10 | 前置缺失 | 当前倾向为诊断、跳过受影响后置、不自动补齐；最终边界待验证 |
| V11 | 前置失败且有独立规则 | 后置跳过，独立规则继续；跳过不算通过 |
| V12 | 仅 B 入 Pending，A 旧结果有效 | 以 idNumber / name 案例验证严格缺失策略是否可接受；不预填通过结论 |
| V13 | 异步乱序返回 | 仅当前请求 / 输入与存活实例的结果可提交 |
| V14 | 异步输入失效 | 撤销该外部来源过期 Issue，其他同步来源保留 |
| V15 | Submit 校验完整性 | 首次未执行的必要规则仍被完整覆盖；未完成 / 配置异常 / stale 不算通过 |
| V16 | 校验结果内容不变 | 字段聚合不重复通知；具体通知时序仍需验证 |

下一步先推演 V12，明确缺失前置及跨轮资格失效，再冻结前置引用范围与语法、PreparedValidation 最小结构、Issue 查询 / 订阅 / 完整结果 API。随后用相同测试向量对照 Web / Dart，度量根 Schema 在目标设备的成本，决定是否需要延迟通知或局部优化。附带图示、伪代码与交互原件只是设计说明，不代替正式类型、Schema、Adapter 和 Runtime 实现。
