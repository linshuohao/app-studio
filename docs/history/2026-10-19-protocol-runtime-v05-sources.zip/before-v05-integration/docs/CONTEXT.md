# 动态表单定义协议

复杂动态表单与数据录入引擎的领域词汇。协议与决策正文见 [L1 定义协议](design/l1/README.md)。

## Language

**Read Dependency（读取依赖）**：某个表达式或取值过程可能使用的输入引用，不表示这些输入的变化必然触发业务行为。
_Avoid_：将所有读取自动视为 Reaction 的触发条件。

**Watch Dependency（触发依赖）**：某个行为需要响应的状态变化范围，由使用位置的语义决定，显式 `watch` 是其中一种声明方式。
_Avoid_：将 watch 解释为执行时机或回调调度策略。

**Dependency Plan（依赖计划）**：描述行为、触发依赖、作用域模式和激活归属的静态观察计划；Observation Plan 是同一概念的说明性别称。
_Avoid_：将计划当作已经激活的订阅，或另设一套平行的 Observation Plan 模型。

**Subscription（活跃订阅）**：某个消费者在 FormRuntime 中已建立的观察关系，具有自身的激活与释放生命周期。
_Avoid_：把全部 Prepared View 计划等同于已挂载的视图订阅。

**Scope Pattern（作用域模式）**：描述词法绑定与逐项关系的静态模式，与某个真实数组项的实例身份不同。
_Avoid_：用当前数组下标或实例 ID 表达静态模式。

**Reactive Engine（统一观察机制）**：Runtime 内按状态来源、引用与 Scope 实例匹配活跃订阅的协作机制，供联动、校验和视图观察共用。
_Avoid_：将它扩张为与 Data、Reaction、Validation 并列的新业务领域或通用工作流引擎。

**Operation（外部操作）**：一次由 View / Host 等外部来源发起的数据修改调用，表达修改从哪里来。
_Avoid_：将一次 Operation 等同于独占的 Flush 或可回滚业务事务。

**Data Change（有效数据变化）**：Command 对当前 Working Data 造成的真实变化，是后续依赖失效的依据。
_Avoid_：将每次 Command 调用都算作有效变化，或将 Validation 状态变化混入 Data Change。

**Reaction Instance（联动实例）**：一条 Reaction 定义绑定实际 Scope 后形成的状态收敛行为；待执行时多次失效可以合并，执行时读取最新数据。
_Avoid_：按触发次数记账的事件处理器，或以数组下标标识实例。

**Flush（联动执行轮次）**：消费待执行 Reaction 实例直至收敛或停止的一轮执行，可接收多个 Operation 引发的失效。
_Avoid_：数据提交事务、每条 Reaction 各自一轮，或所有校验与 UI 绘制都已完成。

**Flush Context（轮次上下文）**：仅属于一轮联动执行的计数、来源与临时追踪证据。
_Avoid_：全部 Runtime 状态的容器，或跨轮保留的完整生产历史。

**Runtime Health（运行结果可信度）**：描述联动异常后哪些派生结果仍未可靠收敛的运行状态，与调度是否空闲分别表达。
_Avoid_：队列为空即健康，或无关输入变化即恢复。

**Flush Trace（轮次追踪）**：一轮执行中的有序行为、实际数据变化及触发来源记录，供异常诊断与开发工具解释执行链。
_Avoid_：将追踪等同于完整历史数据、确定性重放或热路径实时因果图。

**Pure Function（纯函数）**：表单纯表达式可调用的同步、确定性计算能力，内置能力与注册的领域能力属于同一类别；输入相同则输出相同，不读外部可变状态，也不产生 I/O 或数据写入副作用。
_Avoid_：泛称 Function 而省略纯计算约束、把异步业务操作归入纯函数。

**Capability Catalog**：编译时可查询的 Material 与 Pure Function 契约集合；Host 静态契约可以作为可选补充。
_Avoid_：将契约目录等同于可执行代码或统一业务执行器。

**Capability Lock**：一次表单发布在指定平台与 Profile 下选定的能力版本及不可变制品身份。
_Avoid_：以最新版本指针代替发布锁定。

**Form Release**：绑定业务表单版本、编译产物、能力锁及 Host 依赖要求的不可变发布单元。
_Avoid_：回滚时使用当前能力目录重新组装旧发布。

**View Profile**：同一 FormDefinition 内按场景命名的视图，其值直接是一个 ViewNode。`default` 只是可选名称，不表示额外的协议层级。
_Avoid_：Profile Entry 包装、固定 default 根。

**Default Slot**：Material 的默认子节点组合位置，以 `slots.default` 表达，与 Profile 名称无关。
_Avoid_：把默认插槽与默认视图混用。

**定义信息**：文档中对协议标识、版本和非执行性 metadata 的阅读分组；它不是新的协议字段或嵌套对象。
_Avoid_：basicInfo 协议域。
