# 文档维护

项目处于方案设计与规范固化阶段。L1 主体架构与语义、L2 静态编译与能力发布治理、跨层读取 / 触发 / 订阅职责已收敛。2026.10.18 进一步确认不可变 Working Data、Command 即时生效、batch 默认非原子、Reaction 最新状态收敛与待执行合并、延迟启动同步 Flush、临时 Trace 与异常上报。普通错误隔离、熔断恢复、同步通知重入、精确排序和异常影响 Submit 的范围仍待决策；正式类型、Schema、版本规则、Prepared ABI、生产 Runtime 与 L4 适配尚待完成。

## 阅读与源文件

整体方案分为两份指南：[使用与开发指南](reading/usage-guide.html) 从最小字段、计算校验、数据联动、重复项、宿主接入逐步进入排障与参与开发；[设计者指南 · 整体架构](reading/architecture.html) 保留完整思想、概念、分层、机制、图示、取舍、交付物和验收路线。前者帮助读者用场景理解框架，后者用于方案评审与核心设计。

两份指南共用 [L1 定义协议](reading/l1-definition-protocol-v1.html)、[L2 编译与发布](reading/l2-preparation.html)、[依赖与订阅](reading/dependency-reactivity.html)、[L3 执行与诊断](reading/l3-reactive-engine.html) 和 [协议样例](validation/index.html) 作为详细契约与例证，全部在共享侧栏直接切换。L1 原有渐进分组继续作为协议查阅路径，不扩写成第三份全框架指南；章节目录直接进侧栏，术语嵌入设计者指南，复现说明并入样例。历史只从 [归档入口](history/index.html) 按需追溯，不再维护平行摘要或轮次规范。

| 来源 | 职责 |
| --- | --- |
| `design/usage-guide.md` | 使用与开发指南；以场景递进解释框架、接入、可观察结果、排障与贡献入口，链接权威契约 |
| `design/architecture.md` | 设计者指南；思想、产品边界、完整分层、图示、机制、取舍、交付物与验收路线，保留现有 URL / 锚点 |
| `design/l2-preparation.md` | L2 与平台职责、Pure Function、能力契约、Host 注册、编译与不可变发布；侧栏提供直达入口，整体架构的 L2 章节也保留链接 |
| `design/dependency-reactivity.md` | 跨层读取 / 触发 / 订阅契约，依赖计划、统一观察、Scope、挂载生命周期、时序与验收；语法和编译细节同步相应 L1 / L2 主题 |
| `design/l3-reactive-engine.md` | L3 数据 / Command / Flush、状态所有权、合并、保护、Health、临时 Trace、诊断取舍、R01–R26 决策与 C01–C18 设计验收 |
| `design/l1/01-*.md` 至 `08-*.md` | 同一份 L1 正文的八个主题；按需读取和修改 |
| `design/l1/README.md` | L1 阅读分组、场景引导与章节顺序；生成时嵌入同一协议页，不另建索引页或复制协议正文 |
| `CONTEXT.md` | 领域词汇，生成时嵌入架构文档 |
| `validation/` | 样本生成源、候选验证器、数据、报告与复现说明 |
| `history/` | 原始来源与被替代版本，不与现行正文并列生效 |

讨论某项能力时先查对应 Markdown 的标题和章节锚点，再读必要的相邻契约。指南解释不取代主题正文；一个决策只在其所属主题维护完整规则，跨层影响同步相邻契约，避免形成相互冲突的解释。完整示例、类型附录和验证数据按需加载；不为获取设计约束读取 HTML、CSS、JS 或历史稿。两份指南和各专题复用统一阅读外壳和侧栏，不新增重复索引页；后续设计继续归入 `design/`，实现目录在落地任务中建立。

## 维护方式 {#maintenance}

1. 修改相应 Markdown 或样本生成源，保留稳定章节锚点和已收敛 / 待固化状态；不按讨论轮次新增平行规范。
2. 示例变化时同步验证源。保险基线读取 [示例正文](design/l1/07-examples.md#sample)；其余样本来自 `validation/build_cases.py` / `extend_cases.py`。不直接修改生成的 cases、报告和阅读页。
3. 生成阅读页并检查同步；协议样例变更时另复跑验证。出现冲突，以相应主题正文为准，修正受影响的样本和说明。

首次安装依赖与日常生成，在项目根目录执行：

```bash
python3 -m pip install -r tools/docs/requirements.txt -r docs/validation/requirements.txt
python3 tools/docs/build_docs.py
python3 tools/docs/build_docs.py --check
```

协议样例变更后的验证：

```bash
python3 docs/validation/run_validation.py
```

阅读页共用 `tools/docs/reader.py`、`tools/docs/templates/document.html` 及 `docs/reading/assets/documentation.css` / `documentation.js`。`examples.css` 只补充样例布局；历史快照保留原有呈现，纯函数术语已统一，原始字节见历史来源包。仅改呈现时重新生成页面即可，无需重建协议数据。旧首页 `reading/index.html` 直接转到整体架构，不另维护一份首页正文。

L1 阅读顺序在 `design/l1/README.md` 中维护：每个带稳定锚点的二级标题是一组，段落说明使用场景，末尾列表逐项链接编号正文的章节。生成器要求每节正文恰好出现一次，保留原章节及主题锚点，避免重排时漏节、重复或破坏既有链接。新增章节时同步安排阅读位置；协议字段、类型、约束和样例仍只在编号正文维护。

架构图在 Markdown 的 `diagram` 代码块中维护节点、连接和说明数据，由 `tools/docs/diagrams.py` 生成共享风格的图形。这些数据仅用于文档呈现，不是 L1 协议字段；正文和图示中的职责、状态与演进关系需要同步维护。
