# L3 Reactive Engine：数据更新、Flush 与异常诊断

本篇整合《L3 Reactive Engine · Flush / Trace / Diagnostics 完整决策归档 V0.4》（2026.10.18）的 20 节讨论、26 项决策及 18 个验收场景，作为现行 L3 设计专题。它修订早期候选机制，保留已确认、推荐、待决策、待实现标定和延期的区别；没有冻结正式接口，也不表示运行时已经实现。整体职责见 [设计者指南](architecture.md#runtime)，渐进理解见 [使用与开发指南](usage-guide.md#usage-updates)。

## 执行基线与设计状态 {#l3-baseline}

核心路径是：外部 Operation 发出 Command → Working Data 即时更新 → 有效变化使相关消费者失效 → 合并待执行 Reaction 实例 → 延迟启动一次 Flush → 同步执行到收敛或安全停止。Reaction 写回继续进入当前 Flush；前轮结束后到达的 Host 异步结果形成新的失效和轮次。

| 状态 | 内容 |
| --- | --- |
| 已确认 | 不可变 Working Data 与结构共享；单条有效 Command 同步生效；batch 默认非原子；Reaction 最新状态收敛与待执行合并；内部级联属于当前 Flush；V1 延迟启动、同步执行；Operation 仅表示来源；临时有序 Trace 与异常上报 |
| 已确认方向 | Devtools 可独立观察并保存执行历史，开启与关闭不改变语义 |
| 推荐 | 首次失效建立 Context；稳定规则顺序与首次入队顺序；Watch / Write 静态 SCC；超限中止整个本轮；Trace 在预算内保留全程、溢出保留起点与尾部 |
| 待决策 | 普通执行错误如何隔离；待执行队列如何结束和恢复；同步通知重入；精确排序；Trace 截断与参数记录；异常影响 Submit 的范围；初始化 / Reset 的首次 Reaction |
| 待实现标定 | 执行次数、耗时、记录容量和上报限频阈值 |
| 延期 | 时间切片 / 优先级、全量或局部 Hash、高级因果图分析、历史 Snapshot 恢复与确定性 Replay |

优先补正确性契约：异常后哪些命令和规则继续、如何避免无限自动重试、同步通知如何有界交付。记录容量与阈值可以随后标定。来源中的后续会议建议和个人复核控件只用于追溯，不改变上述决策状态。

## 概念与状态所有权 {#l3-ownership}

| 概念 | 含义与身份 | 生命周期 |
| --- | --- | --- |
| Operation | 外部 dispatch 的来源，可有 Operation ID | 不独占一轮 Flush；未命中 Reaction 时可无需 Flush |
| Command | set / patch / remove / array.* / batch 数据修改意图 | 按顺序执行，保留显式动作次数 |
| Data Change | 真实有效变化；Change ID 关联目标 Scope / Path | 用于失效匹配与追踪；同值调用不虚构有效变化 |
| Reaction Instance | Reaction ID + 实际 Scope 身份 | 随 Form / Scope 激活，可在同轮多次执行 |
| Pending | 按 ReactionInstanceKey 去重的待执行集合 | 属于 Reactive Engine，执行或中止时消费 / 处理 |
| Flush | 一次消费待执行实例的过程，具有 Flush ID | 队列清空、执行错误处理或保护停止时结束 |
| Flush Context | 本轮计数、来源、临时 Trace、预算和异常标志 | 推荐首次失效时创建；结束后释放 |

| 所有者 | 状态 | 释放 / 更新条件 |
| --- | --- | --- |
| L3 Data / Scope | 当前不可变 Root、Baseline、数组稳定身份与索引映射 | Runtime 生命周期；有效 Command 更新当前状态 |
| Reactive Engine | 依赖索引、活跃观察者、pending、调度阶段 | 订阅 / Runtime 生命周期；不是全部放进 Context |
| Flush Context | 总执行数、单实例次数、外部重入标记、有序执行证据 | 本轮结束 / 中止；异常先提取报告 |
| Validation | Issues、校验状态、请求新鲜度及失效状态 | 独立于 Reaction Flush |
| Runtime Health / Diagnostics | 必要的未收敛范围、可信度标记、有限诊断摘要 | 跨轮保留，直到对应恢复或实例销毁 |
| L4 / Host / Devtools | UI 状态与框架订阅、外部任务、可选历史 | 各自消费者生命周期 |

调度阶段、轮次结果和长期可信度分别表达。`idle / scheduled / flushing` 是阶段草图；`settled / aborted / completed_with_errors` 是结果草图。最后一种结果依赖局部隔离决策，均非正式冻结枚举。`idle` 不能证明派生值健康。

## 即时不可变数据与有序 Command {#l3-data}

五项不变量：

1. 业务值允许暂时不合法。清空必填项、超出年龄限制可以进入 Working Data，Validation 报告问题。
2. 有效 Command 同步生效。紧接着读取当前 Data 应看到修改，不等待 Reaction 或校验完成。
3. 每次更新形成不可变 Root，未变化子树可以结构共享；旧 Snapshot 保持稳定，不逐步深拷贝整张表单。
4. 单次数组结构操作同时保持 Data 与 Scope Identity 一致，不能暴露索引与身份映射错位的半完成状态。
5. 数据已更新不等于 Renderer 已绘制；调度延迟不保证浏览器先画一帧。

```text
读取 Snapshot v1：age = 20
执行 set age = 25
立即读取当前 Snapshot v2：age = 25
再次读取先前持有的 v1：仍为 age = 20
联动 premium 此刻可能尚未完成，需分别判断收敛状态。
```

默认 `batch` 和 Reaction 的 `then[]` 都按顺序执行 Command，各条有效修改实时生效，不默认回滚先前成功写入。该边界取代“候选数据树中完成整个 batch 后原子提交”的早期候选。业务 Invalid、Scope 已删除、非法数组位置、非法 Command 是不同结果；后几种属于结构性执行失败，单个结构操作仍须保持内部一致性。失败后是否继续后续子命令属于待固化的错误契约。

两条显式 `array.insert` 各执行一次，不能因目标相同被合并；待执行 Reaction 的多次失效可以合并，两者属于不同层次。同值短路放在实际变化判定中，基本值应避免无意义传播；对象不默认全量深比较，引用、替换与结构操作的准确等值契约仍待固化。

## Flush 生命周期与外部操作归属 {#l3-flush}

```diagram
{
  "id":"figure-l3-flush",
  "title":"即时写入与一轮联动收敛",
  "rows":[
    [{"title":"Operation → Command","body":"同步更新不可变 Root 与 Scope；按有效变化匹配依赖"}],
    [{"title":"idle → scheduled","body":"首次出现 pending 后安排一次启动；推荐此时建立 Context 保存起点"}],
    [{"title":"flushing · 取出实例","body":"从 pending 移除，读取最新 Data，求值 when，按序执行 then","major":true}],
    [{"title":"当前轮继续","body":"内部有效修改追加失效；同实例执行后可再次入队"},{"title":"本轮结束 / 停止","body":"队列空或安全停止；更新可信度，必要时提取异常报告"}],
    [{"title":"释放本轮 Context","body":"正常不留生产完整历史；Devtools 自行保存；Health 按恢复契约跨轮保留"}]
  ],
  "arrows":["↓","↓","↕","↓"],
  "note":"Flush 是联动调度边界，数据在每条 Command 时已经生效。图示不冻结错误隔离、精确排序和通知重入策略。"
}
```

V1 延迟一次启动，然后在同一同步执行过程消费任务直至结束；不实现时间切片。微任务可作为启动方式，但精确启动契约仍待固化。首次失效进入 scheduled 时建立 Context 是推荐方向：必须能够保留第一次有效变化及 scheduled 期间后续合并的来源，避免执行开始时才记录而丢失起因。

| 发生时机 | 数据 | Reaction 归属与状态 |
| --- | --- | --- |
| scheduled 期间多个 Operation | 每次同步生效 | 加入已安排轮次，合并同一 pending 实例 |
| Flush 内部 Reaction 发出 Command | 同步生效 | 新失效加入当前轮，不为 A → B → C 各开一轮 |
| 前轮结束后 Host 异步返回 | 同步生效 | 新失效安排下一轮，计数独立 |
| 同步 Flush 中外部回调重入 dispatch | 同步生效 | 推荐加入当前轮并记 hadExternalReentry；策略仍待确认 |
| 外部修改未命中 Reaction | 同步生效 | 无需安排 Reaction Flush；Validation / View 仍按自身契约响应 |

同一 JS 主线程的普通输入事件或 Promise 回调不能插入已经开始的同步 Flush 调用栈。同步订阅回调、外部注册代码的重入是另一种情况：通知链需要独立保护，不能只靠 Reaction 执行次数兜底。外部重入不重置本轮计数；此时队列能否清空仍可判断，但报告不能轻率归因为纯内部循环。

## Reaction 合并、重入队与执行顺序 {#l3-reactions}

Reaction 是最新状态驱动的收敛行为。年龄和产品在执行前各变化一次，同一个保费实例只保留一份 pending，执行时读取最终年龄与产品；追踪保留两条失效来源。需要每次点击都新增一条记录的业务，使用明确 Command / Host 事件表达，不依赖 Reaction 的触发计数。

```text
invalidate(instance, change):
  尚未 pending → 登记实例与触发来源
  已经 pending → 合并触发来源，不重复入队
takeNext():
  从 pending 取出并移除实例
  执行时读取最新状态
  执行后再被有效变化命中 → 允许重新入队
```

推荐按 PreparedForm 稳定规则顺序完成初始入队，执行中新增任务按首次登记顺序追加；重复失效不移动已排队实例。推荐当前 Reaction 不被新失效打断，完成当前 `then[]` 后再取下一项，避免规则嵌套调用。准确顺序和运行中再次失效细节仍是 R13 / R18 的待确认契约。

稳定顺序帮助复现，不能保证冲突写入的最终值与顺序无关。同目标覆盖、互相依赖、结构修改都需验收。`then` 允许 array.insert/remove/move，但配置必须符合状态收敛意图；无条件反复新增需诊断风险，不能据此假定每次触发均应完整保留为业务事件。

## 四种执行轨迹 {#l3-traces}

以下是逻辑演示，字母为规则实例，数值为解释用途，不是运行算法或真实性能数据。

| 场景 | 步骤 | 可观察结论 |
| --- | --- | --- |
| 正常级联 | Operation 写 age=25 → pending A；Flush #1 中 A 写 premium=150 → B；B 写 totalPremium=150 → C；C 无有效修改 | 全部在 #1；队列清空，正常释放 Context |
| 多次输入合并 | scheduled 时 Operation #1 写 age=21 使 A 入队；#2 写 product=PLUS 再命中 A；A 执行一次读取最终二者 | 同一 pending，多对一 triggeredBy 来源 |
| 往复震荡 | A 将 age 17→18 使 B 入队；B 将 18→17 再使 A 入队，持续有效变化 | pending 去重不能阻止循环；预算停止，保留异常可信度并报告 |
| 同步外部重入 | Flush #4 中 A 写 premium；通知回调由 Host 同步写 discount；新失效使 B 入队 | 推荐归当前轮并标记外部干预；通知有界策略待决策 |

同规则的 `A#1 → B#1 → A#2` 是三次独立执行，需要各自 executionId；不能把 A 的所有执行折叠成一条运行记录。

## 静态风险与运行时有限执行 {#l3-protection}

| 机制 | 发现 / 保护什么 | 取舍与状态 |
| --- | --- | --- |
| 同值短路 | 相同值反复写入 | 基本保护；复杂对象等值需明确，不默认深比较 |
| 同实例 pending 去重 | 执行前的重复失效 | 必须；不解决执行后的往复循环 |
| 本轮总执行数 + 单实例次数 | 无界传播与局部重复 | 必须；计数低成本，具体阈值待标定 |
| 执行边界耗时检查 | 过慢轮次 | 可以报告并阻止继续调度；不能强制抢占正在执行的同步函数 |
| L2 Watch / Write 图与 SCC | 潜在规则环链 | 推荐；Tarjan / Kosaraju 可用，风险默认 Warning，不能禁止所有环 |
| 每步全量 Data Hash | 重复数据状态 | 不做默认判环；单次 O(S)，K 次为 O(K×S)，也漏掉无限增长 |
| Runtime 执行图与 SCC | 实际反复触发的规则集合 | 不进入默认热路径；留给 Devtools / 高级诊断 |
| 局部指纹 / Merkle 式 Hash | 局部往复状态 | 延期；需要完备读取、Scope 和状态信息 |

重复 Data 不等于重复完整执行状态，图中有环也不等于一定不终止。V1 目标是提前提示风险、限制执行、解释异常，无法对任意函数与修改组合通用证明终止。正常多轮收敛不用报错；已删除 Scope 的过期待执行任务正常取消。

早期本地 Node 的毫秒数不能成为 Web / Flutter 的性能预算。全表 Hash 的复杂度随数据字节数 S 增长；轻量记录成本主要随执行事件数、实际变化与额外复制参数量增长。具体常数须用大型数组、高频输入及目标平台 benchmark 标定。

## 异常、熔断、可信度与恢复 {#l3-errors}

| 现象 | 当前约束 | 尚需决定 |
| --- | --- | --- |
| 合法多轮收敛 | 正常结束，不持久上报完整轨迹 | 无需将次数多直接判错 |
| 疑似往复写入 / 持续覆盖 | 可以报告异常模式，最终如实记录是否收敛 | 告警分类与限频 |
| 纯函数 / Reaction 执行抛错 | 报告错误；不回滚先前有效 Data | 停剩余 then[]、隔离当前实例，还是中止整轮；其他规则是否继续 |
| 单实例 / 总执行数超限 | 必须停止无界执行；不自动把剩余任务移到下一轮重试 | 推荐中止整个当前 Flush；准确队列与隔离边界待定 |
| 耗时异常 | 在执行边界判断，报告超时信息 | 阈值与后续任务处理 |
| Scope 已删除 | 取消过期实例任务，回收关联 | 不作为业务错误上报 |

熔断后的最小正确性约束：

1. 已生效的数据保留；异常不会自动撤销用户输入。
2. 停止继续启动本轮 Reaction；清理或隔离遗留任务，防止无条件自动重试形成无限 Flush。
3. 先提取异常路径与必要报告，再释放临时 Context。
4. 长期状态保存最小 degraded / 不可信范围；调度回到 idle 不代表派生值可靠。
5. 对应规则后续正常收敛后才能恢复相应可信度；无关字段变化不能抹掉旧异常。

普通函数错误推荐局部隔离，超限推荐整轮中止，但两者尚未冻结。是否使用 Dependency Plan 精细传播不可信范围、什么新输入或显式操作允许恢复、如何验证恢复均需契约。不能把“保留健康标记”理解成已经解决全部恢复算法。

## Trace：事实、来源与记录边界 {#l3-trace}

Runtime 记录有序执行事实与实际变化，Devtools / 离线平台重建因果关系。记录应能表达 Operation 来源、Reaction / Scope、执行顺序、状态和产生的有序修改，`triggeredBy[]` 支持多个变化合并触发一次执行。

```text
Operation #1 → Change #11：age 20→17
Operation #2 → Change #12：product BASIC→PLUS
Reaction A · Execution #13 · triggeredBy [#11,#12]
  → Change #14：premium 100→150
Reaction B · Execution #15 · triggeredBy [#14]
  → Change #16：discount 0→10%
Reaction A · Execution #17 · triggeredBy [#16]
```

| 信息 | 用途 | 限制 |
| --- | --- | --- |
| executionId | 区分同一实例在本轮的多次执行 | 不等于 L1 Reaction ID |
| changeId | 定位 Command 造成的真实变化 | 无变化调用可记录执行事实，不伪造有效 Change |
| triggeredBy | 标识使本次执行失效的变化 | 表示调度原因，不证明每项都是业务计算的必要条件 |
| dataVersion | 标识读取的工作状态版本及变化前后版本 | 版本号本身不保存历史值 |
| Scope / Path / op | 解释实际对象与修改位置 | Scope 稳定身份与当时路径需分别说明 |

概念级结构如下；字段、ID 空间、操作与变化粒度、失败 / 无变化的编码继续固化，不直接发布成正式 TS 包：

```typescript
interface ExecutionRecord {
  id: number;
  kind: 'operation' | 'reaction';
  name: string;
  scopeId?: string;
  triggeredBy?: ChangeId[];
  changes: DataChangeRecord[];
  status: 'success' | 'error';
}
interface DataChangeRecord {
  id: ChangeId;
  target: { scopeId?: string; path: string };
  op: string;
  beforeVersion: number;
  afterVersion: number;
}
```

来源草图同时给变化记录放入 `changed` 标志；本篇将有效变化与无变化 Command 事实分开说明，保留其信息需求，不冻结两套并行变化模型。首个失效之前的 Operation / Change 必须能在建立 Context 时被关联，具体采集方式待定。

## 记录预算、参数与异常上报 {#l3-trace-budget}

执行预算与记录预算独立：前者停止无限联动，后者限制事件条数及字节数。Trace 满了可停止详细采集或截断，但计数与循环保护必须继续。合并来源、参数副本等附属记录也需计入容量，不能通过大 `triggeredBy` 绕过记录预算。

推荐在正常容量内保留完整本轮，溢出时保留初始来源与最近一段，并标记 `truncated`；仅保留尾部是替代方案，最终策略仍待决策。截断造成的缺失引用必须如实表达，不能伪造完整因果链。

| 对象 | 生产临时 Trace 方向 | Devtools 可选扩展 |
| --- | --- | --- |
| Reaction / Scope、实际 Command 与目标 | 记录身份和事实 | 同一来源进一步展示 |
| when 结果 / Pure Function ID | 必要的少量元数据 | 更细的求值过程 |
| 标量业务参数 | 脱敏值、受限摘要或不留原值，策略待定 | 在明确授权范围扩展 |
| 大对象 / 数组参数 | 类型、大小、摘要，避免逐步深拷贝 | 受限稳定副本或检查点 |
| Working Data 全量 Snapshot | 不逐步复制 | 历史恢复属于延期能力 |

保存可变 Context / 外部对象引用不能证明历史参数；需要审计时必须明确受限副本或摘要形成的时点。正常结束释放生产完整记录，异常先提取报告；Devtools 可自行长期保留。异常报告至少应定位 Definition / 发布身份、Reaction / Scope / Path、轮次结果、保护原因及截断信息，具体字段、脱敏映射和限频待固化。注册能力、Runtime 和平台的版本信息也影响可解释范围。

## Devtools 因果分析与复现的三种层次 {#l3-devtools}

事后先扫描 changes 建立 `changeId → executionId` 索引，再扫描 triggeredBy 连边。记录完整时，成本随执行数、变化数和引用数线性增长；Runtime 无需实时维护父子树或运行 Tarjan。以执行实例为节点按时间向前连边，以 Reaction Instance 折叠展示时才可能出现 A ↔ B。

| 能力 | V1 边界 | 额外条件 |
| --- | --- | --- |
| 复原执行顺序和触发链 | 推荐支持；受截断范围限制 | 有序记录与 Change 关联 |
| 复原历史 Data 值 | 暂不承诺 | 初始 Data + 可重放的实际修改日志 + 数组 / Scope 恢复信息 |
| 确定性重新执行 | 暂不承诺 | Definition / Prepared / Function 版本、初始 Data / Context、外部输入、非确定性来源与环境约束 |

异常可定位不等于时间旅行。Devtools 关闭也必须得到同样的 Reaction 输出与调度结果。

## Validation、Renderer 与 Submit 的边界 {#l3-consumers}

共用匹配不等于共用完成条件。Reaction Flush 处理同步联动收敛，不等待所有外部校验或 UI 绘制。

| 消费者 | 失效时 | 执行 / 完成时 |
| --- | --- | --- |
| Reaction | 合并 pending 与来源 | 读取最新 Data；有效写入归当前轮 |
| Internal Validation | 旧结果及时失效 | 按策略重评估，维护自身 Issue / Status / Scope |
| External Validation | 旧结果失效，必要时取消旧请求 | 发起时固定输入；返回时检查请求、Scope 与输入新鲜度 |
| Renderer | 获知最新状态变化 | 框架读取最新状态，不要求消费每个中间版本 |
| Submit | 不能依赖未完成或不可信派生值 | 确认相关 Reaction 收敛、必需校验有效，再构建一致提交候选 |

异常时阻止全部提交，还是只阻止使用受损派生值的提交，仍是 R22 待决策。Readiness 必须纳入相应可信度要求，不能只看队列为空或没有 Issue。实际提交、权限和风控仍由 Host 负责。

微任务启动 Flush 可能仍发生在浏览器绘制前，耗时同步纯函数会阻塞主线程，这是 V1 接受的简化取舍。未来可以替换 Scheduler，但需保持数据写入、收敛、身份及异常契约。

## 跨层修订、替代方案与取舍 {#l3-impact}

| 层 / 早期候选 | 现行处理 | 保留理由与影响 |
| --- | --- | --- |
| L3 可变 JSON + 按需 Snapshot | 不可变 Working Data + 结构共享 | 稳定旧快照；更新算法保留优化空间 |
| batch 候选树统一提交 / 回滚 | 逐 Command 有序即时生效，不默认整体回滚 | 输入反馈与状态语义；通知合并独立处理 |
| Reaction 每次失效均独立执行 | 最新状态收敛、pending 去重 | 状态联动与事件记账分离；L1 同步说明 |
| Operation 包含完整联动事务 | 仅记录外部来源，多个 Operation 可共用 Flush | 调度轮次独立于修改来源 |
| 同步 / 全延迟 / 混合 / 分段调度候选 | V1 延迟启动、同步消费到结束 | 保持简单，可替换入口，暂不做 Fiber 式优先级 |
| 每步 Hash / 热路径完整因果图 | 同值短路、次数预算、轻量有序 Trace | 降低热路径成本；静态风险和离线解释分工 |
| 最近 N 条或长期生产历史 | 临时轮次记录；预算与截断待定；异常提取报告 | 保留起点有助定位，同时控制内存与复制成本 |
| L2 Read / Watch 分离 | 保持；推荐 Watch / Write SCC 风险诊断 | Write 不改变 Reaction 触发逻辑 |
| L1 then 中数组操作 | 保留，但需符合收敛意图并提示非幂等风险 | 显式 Command 次数不合并，Reaction 不承诺每次触发次数 |
| Scope / Validation / L4 | 保持稳定身份、校验所有权与新鲜度、按挂载订阅 | Trace 也按稳定 Scope 定位；Runtime 不控制 UI 帧与 Loading |

不默认整体回滚、逐步全表快照、运行时因果图或复杂调度，是具体成本与表单状态语义之间的选择；不意味着异常隔离、输入保留和结果可信度可以省略。旧候选及整合前全文见 [原始来源包](../history/README.md#l3-integration)。

## 决策总账 {#l3-decisions}

以下保留来源 R01–R26 的编号与状态；“推荐”不是已经冻结，“待实现标定”也不是实现完成。

| 编号 | 决策 | 状态 | 说明 / 所属层 |
| --- | --- | --- | --- |
| R01 | Working Data 不可变 + 结构共享 | 已确认 | 旧 Snapshot 稳定；每条有效 Command 可发布新 Root；L3 Data |
| R02 | 单个有效 Command 同步生效 | 已确认 | 业务合法性由 Validation 判断；结构操作保持内部一致性；L3 Data |
| R03 | 默认 Batch 非原子事务 | 已确认 | 子 Command 有序实时写入，不默认回滚前序成功修改；L1 / L3 |
| R04 | Reaction 是最新状态收敛行为 | 已确认 | 不依赖触发次数；同一待执行实例可以合并；L1 / L3 |
| R05 | 内部 Reaction 写入属于当前 Flush | 已确认 | 不为每条联动创建新 Flush；执行后可重新入队；L3 Reactive Engine |
| R06 | V1 延迟启动、同步执行到结束 | 已确认 | 不做分段调度/时间切片；L3 Scheduler |
| R07 | Operation 是来源，不是隔离事务 | 已确认 | 多个 Operation 可影响同一个 Flush；L3 |
| R08 | Trace 为顺序行为记录 + Change 来源 | 已确认 | 不构建运行时因果图；Devtools 事后分析；Diagnostics |
| R09 | 正常 Flush 不持久上报 | 已确认 | 执行结束后释放临时 Context；异常才提取报告；Diagnostics |
| R10 | Devtools 可观察完整执行 | 已确认方向 | 启用时由 Devtools 自行保存历史，不能改变执行语义；Devtools |
| R11 | L2 做 Watch/Write 图与潜在环诊断 | 推荐 | 静态 SCC 可辅助定位，但不禁止所有成环规则；L2 |
| R12 | Flush Context 自首次失效建立 | 推荐 | 包括 scheduled 期间的初始来源和合并原因；L3 |
| R13 | 执行时使用稳定顺序与去重队列 | 推荐 | 稳定规则排序 + 首次入队顺序，具体语义需再确认；L3 |
| R14 | 超限熔断整个本轮 Flush | 推荐 | 防止未收敛数据进一步扩散；局部隔离为后续空间；L3 |
| R15 | Function 错误局部隔离与是否继续 | 待决策 | 是停当前 then[]、整条 Reaction，还是继续其他独立规则？；L3 |
| R16 | 熔断后的待执行队列与恢复条件 | 待决策 | 如何保留未收敛影响范围，避免无条件自动重试？；L3 |
| R17 | 同步订阅重入时的递归通知保护 | 待决策 | Data 同步写入不变；通知交付需要有界处理；L3 / L4 |
| R18 | 单次 Flush 的启动与执行排序细节 | 待决策 | 运行中被再次失效、同层/跨层写入冲突如何排序？；L3 |
| R19 | Trace 预算溢出策略 | 待决策 | 完整到上限后保留头尾并标注截断，还是仅尾部？；Diagnostics |
| R20 | 详细参数记录的边界 | 待决策 | 实际值/摘要/大小/类型、敏感数据与稳定拷贝；Diagnostics |
| R21 | 异常检测阈值与重复上报限频 | 待实现标定 | 单实例和总次数硬限制、耗时统计、告警聚合；L3 / Host |
| R22 | 异常影响 Submit 的范围 | 待决策 | 全局阻止或只阻止使用受损派生数据？；L3 / Host |
| R23 | 确定性 Replay、历史 Snapshot | 延期 | 先保证执行链说明；需要时再引入检查点与重放数据；Devtools |
| R24 | 全量 Hash、局部 Hash、完整因果图 | 延期 | 仅高级诊断/开发分析有明确需求时再实现；L2 / Devtools |
| R25 | 复杂分段调度 / 优先级 | 延期 | 先做可替换调度入口，V1 不实现 Fiber；L3 |
| R26 | 初始化/Reset 对 Reaction 首轮触发语义 | 待决策 | 初始化读依赖不等于执行初始校验；初始 Reaction 何时求值？；L3 Lifecycle |

## 设计验收与下一步 {#l3-acceptance}

| 用例 | 场景 | 输入 / 过程 | 必须观察到 |
| --- | --- | --- | --- |
| C01 | 单步输入 | set age=25 后立即读取 | 返回 25，不等待 Flush |
| C02 | 多次合并 | 启动前两次修改 A 的 watch | A 仅一份 pending，执行读最终值 |
| C03 | 链式写入 | A 写 premium，B 观察 premium | B 进入当前 Flush |
| C04 | 重复失效 | A 执行后 C 再改其 watch | A 可重新入队，保留新来源 |
| C05 | 同值短路 | A set 与当前原始值相同 | 无有效 Change，不继续触发 |
| C06 | 动态数组移动 | B 从 index1 移到 index0 | Scope B 稳定；订阅与 Trace 不串项 |
| C07 | 业务校验失败 | 输入超范围年龄 | Data 接受，Validation 产生 Issue |
| C08 | 简单自环收敛 | age16→A 设置18，再执行无修改 | 正常结束，无错误上报 |
| C09 | 往复震荡 | A→B→A 持续有效变化 | 达到预算停止并生成定位报告 |
| C10 | 合并来源 | 两个 Change 命中待执行 A | A 的一次执行关联两个 Change ID |
| C11 | 多次规则执行 | A#1→B#1→A#2 | 独立 executionId，可还原链条 |
| C12 | 正常清理 | 正常 Flush 完成 | 生产 Runtime 不保留完整 Trace 历史 |
| C13 | 异常上报 | 熔断后提取报告 | 定位 Definition 版本、Reaction / Scope / Path 和截断 |
| C14 | 记录预算满 | Trace 先于执行保护达到上限 | 停止详细采集 / 截断，保护仍工作 |
| C15 | 异步 Host 操作 | 前轮结束后 Host 写入 | 新轮次，不复用旧执行计数 |
| C16 | 同步重入 | 通知回调再次同步 dispatch | Data 即时更新，通知不会无限递归；策略待定 |
| C17 | 异常后恢复 | 超限后无关字段变化 | 不能清掉受影响派生结果的不可信标记；恢复契约待补 |
| C18 | Devtools 关闭 | 开关 Devtools 运行同表单 | Reaction 输出和调度语义一致 |

这些是未来 Runtime 的设计验收，当前候选协议检查与有界探针不实现 Flush / Health / Trace，不能将其通过计数当成本表已经通过。C16、C17 等需先补正确性契约才能转为完整可执行断言。

后续按四步推进：先冻结普通错误与熔断的隔离、队列结束和恢复；再冻结通知重入与排序；随后固化 Trace 事件、容量、截断、参数和报告协议；最后实现 V1 并用 C01–C18、动态数组与高频输入标定预算。初始化 / Reset 的首次 Reaction 与 Submit 异常阻断范围一并明确。正式类型、Schema、Prepared ABI、Runtime 与适配器按落地任务建立，不将本篇概念结构当成生产发布包。
