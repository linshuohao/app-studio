# 历史归档与收敛记录

历史文件保留当时的结论与候选方案，不与当前定稿并列生效。当前 L1 唯一依据是 [V1.0 架构与语义定稿](../reading/l1-definition-protocol-v1.html)。

## L3 Flush / Trace 决策整合与两份指南 · 2026.10.18 {#l3-integration}

用户提供的《L3 Reactive Engine · Flush / Trace / Diagnostics 完整决策归档 V0.4》20 节，已整合为 [L3 现行专题](../design/l3-reactive-engine.md)，完整保留 R01–R26 的来源状态与 C01–C18 的设计验收，以及四种执行轨迹、跨层修订、取舍和未决路线。来源中的个人复核 UI 和会议建议不视为新的用户指令或已确认结论。

本次同步整体架构、L1 Command / Reaction / Readiness / 生命周期、L2 风险分析、依赖订阅与词汇。现行设计选择即时不可变数据更新、batch 默认非原子、Reaction 最新状态合并、延迟启动同步 Flush 与临时事实追踪，取代相关旧候选；错误隔离与恢复、通知重入、排序、Trace 细节及 Submit 异常范围保持未决。

整体阅读分为 [使用与开发指南](../design/usage-guide.md) 与 [设计者指南](../design/architecture.md)。后者延续原整体架构文件与稳定锚点，保留完整分层、模型、依赖、修改流程及 Host 图示和各层设计说明；前者从实际场景渐进解释。L1 / L2 / 跨层依赖 / L3 / 样例继续作为详细契约和证据，共用既有外壳与侧栏，不复制两套正式规范。

| 来源章节 | 现行承接位置 |
| --- | --- |
| 01–03 总览、术语与状态归属 | L3 基线 / 所有权；词汇嵌入设计者指南 |
| 04–05 数据不变量与 batch 修订 | L3 数据；架构 State Store / Command；L1 Command |
| 06–09 Flush、归属、合并与轨迹 | L3 Flush / Reaction / 四种轨迹；依赖订阅时序 |
| 10–11 保护、异常与恢复 | L3 保护 / 错误；L2 Watch / Write 风险；Readiness |
| 12–14 Trace、预算、参数和事后分析 | L3 Trace / 预算 / Devtools；架构 Tooling |
| 15 消费者与 Submit | L3 消费者；L1 校验和生命周期；指南接入 |
| 16–17 跨层影响与取舍 | L3 修订表；架构图文、决策与路线 |
| 18–20 总账、验收与后续路线 | L3 R01–R26、C01–C18 与下一步；状态未升级 |

[原始附件与整合前来源包](2026-10-18-l3-flush-sources.zip) 保存未修改的 `l3-reactive-engine-flush-trace-v0.4.html` 和 `before-l3-integration/` 下的 17 份来源文件（既有设计 Markdown、维护入口、词汇、归档说明和阅读生成器）。附件原始 SHA-256：`623d0e5c8fcf327fe6cc3054d6ba484fbc4b2f2f641b3643969a73d869110d2c`；来源包 SHA-256：`2c1ce7a76ef1b89ae33be214901e57f00079b0184a53ec408451a9e78dee20ba`。

本次为设计与阅读组织整理，没有实现生产 Runtime、Flush、Health、Trace 或框架适配。以下历史中的调度未决及候选机制，只记录当时状态；现行主题正文优先。

## 跨层依赖与响应式订阅模型整合 · 2026.10.17 {#dependency-integration}

用户提供的《L1–L4 跨层依赖编译与响应式订阅模型 · 架构设计 V0.1》共 23 节，按概念、L1 使用位置、L2 编译 / Scope、L3 观察、L4 生命周期、时序、验收与决策整合至 [现行跨层专题](../design/dependency-reactivity.md)，并同步整体架构、L1 / L2、词汇与验证样本。专题复用共享侧栏与文档外壳，术语并入架构，不保留第二套现行索引或独立样式。

本次采纳 External `dependsOn` → `watch`，保留 Reaction 显式触发边界；L2 统一计划、L3 统一匹配、L4 按挂载激活。来源中的 flush、计划字段、状态编码、View 粒度与调度选项保留候选状态。External Payload 目前不是 L1 字段，运行时 Validation / Field Meta 观察不扩展 L1 Reference。旧事务图同步说明匹配与交付的边界，保留完整层级、模型、事务与 Host 设计。

[原始附件与整合前正文包](2026-10-17-dependency-reactivity-sources.zip) 包含未修改的 `l1-l4-dependency-reactivity-v0.1.html`，以及 `before-dependency-reactivity/` 中的 13 份 Markdown 来源。原始附件 SHA-256：`c6a5c94bbe6306adce553baac231cd30f39017cb422b676deccc39ffdfa65e23`；来源包 SHA-256：`19810c3779f1e42c4444177764e7dcf64e04cebe6ccee44e8741b4a3af53051b`。

本次仅固化设计与候选样本形态，不代表 Dependency Plan 编译器、生产订阅、调度或框架适配已实现。以下旧统计和结论仍是当时的历史检查点，现行设计与实际验证报告优先。

## L2 决策整合与 Pure Function 术语统一 · 2026.10.17 {#l2-integration}

用户提供的《L2 Preparation · 平台能力治理与编译发布架构 · 决策归档 V0.1》共 21 节，已整合为 [L2 现行设计](../design/l2-preparation.md)。整体架构同步补充平台 / 编译器 / Runtime 分工、Manifest、Host 注册、能力构建与 Definition 编译、版本锁定、依赖边类型和验收路线；L1 同步纯函数能力边界与修订记录。

本次架构决策将能力类别统一命名为 **Pure Function（纯函数）**。现行 Markdown、图示、协议说明、样例生成源与可阅读历史副本均同步术语，相关历史文件名、链接及测试 Manifest 改用 `pure-function` / `pure-functions`。L1 的 `op + args` 字段保留，字段与内置短 ID 迁移不混入本次改名。

为保留证据，[原始来源包](2026-10-17-decision-sources.zip) 保存以下内容的原始字节；下载附件未修改：

- `l2-preparation-platform-capability-v0.1.html`：本次 L2 用户来源原件。
- `before-pure-function-terminology/`：术语统一前各历史目录的 Markdown / HTML 与既有 V1.0 来源阅读文件；阅读副本保留当时布局和设计状态，仅同步术语与链接。

L2 原件 SHA-256：`10a5c35ce07fdaa981c43a2f1829b46688455cce018bd3be813bea51252acbc0`。

来源包 SHA-256：`8b49c9ed942f2f34162adb373323bacf6adaeb4c5128dea27c3ae9a7a8a4ee55`。

下文的“原样”与旧统计描述当时的归档检查点；若需逐字复核，读取来源包。原始验证 ZIP 继续保持不变并由验证入口核对摘要，不是现行术语文档。

## 2026.10.16 · 定稿归档与文档收敛 {#consolidation}

根目录 HTML 从 11 份收敛为 3 份：首页、整体架构、L1 定稿。移除重复维护的主台账、能力清单、设计草稿和六轮专题入口，保存最后同步版供追溯。

最终决策覆盖旧结论：Canonical 为 bindings / slots；模板采用 schemaRef + DataReference；取消独立 ValidationMetadata DSL 的倾向；生命周期基线语义确认。下一步改为 Type / Schema / 正反例验收，不再将 Material Validation Metadata 单列为 L1 前置设计。

定稿的 32 节正文与来源一致，保留完整保险示例、简单示例、修订史与发布清单。架构冻结与正式规范发布的状态分开记录。

归档检查：32 节定稿正文与用户来源逐节一致；659 个 HTML 链接/资源路径与锚点、50 个 Markdown 文件链接检查通过，未发现重复 ID；19 个 JSON 值解析通过。当前 HTML 为 3 份，其余均位于历史目录。此为静态文档检查；浏览器工具限制 file:// 页面，未完成视觉预览。

## 验证包归档与图鉴补充 {#archive-2}

原始 l1_protocol_validation 完整保留为 [来源 ZIP](l1-protocol-validation-source.zip)；01–05 Definition 与 Fixture 原样，新增 06–08 演示多级联动、日期/地区规则与命令/事件边界。

[样本图鉴](../validation/index.html) 集中图示与 48 项能力覆盖，不按讨论轮次新增主体文档。原包绝对路径改为相对定位，并复用现行定稿的保险基线；原始来源摘要和可复现检查见 [机器报告](../validation/report.json)。8/8 样本、22/22 反例、6+34 项抽测通过；未完成项继续明确标识，不改变 L1 架构定稿状态。

## 样例阅读形式调整 {#archive-3}

根据阅读反馈，验证附件改为协议定义优先，每个事例按顶层模块横向排列卡片，完整展示 FormDefinition，不再以局部片段代替。移除仿真表单、输入框及组件预览；用词法结构树和具体触发/计算/修改流程说明关系。数据前后对照折叠为举证，保留原协议、覆盖表与验证结果。

[阅读协议样例](../validation/index.html)

## Profile 与定义信息修订 · 2026.10.16 {#profile-revision}

现行所有规范、示例、类型关系、候选 Schema、校验器、覆盖 Pointer 与结构图统一采用 views: Record&lt;string, ViewNode&gt;。移除无独立语义的 entry 包装，保留具名 Profile 选择与 slots.default 插槽。metadata 与协议标识、版本合并在“定义信息”卡片，不新增 basicInfo 域。

原始归档、ZIP 和上文统计是历史检查点。现行 01–05 Definition 仅做确定的包装迁移，Fixture 不变；8/8 样本、23/23 反例和 40 项有界检查通过。旧 entry 包装新增为反例，不再被 Canonical 校验接受。

## 来源与过程记录 {#archive-5}

- [V1.0 用户来源阅读副本](2026-10-16-v1-final-original.html)（纯函数术语已统一；术语统一前字节见上方来源包）
- [定稿前完整快照说明](2026-10-16-before-v1-final/README.md)
- [历轮集成日志](2026-10-16-before-v1-final/changes-2026-10-16.md)
- [历轮一致性检查记录](2026-10-16-before-v1-final/consistency-review-2026-10-16.md)
- [第一至三组来源原稿](2026-10-15-round-originals/README.md)
- [第四至六组来源原稿](2026-10-16-round-originals/README.md)
- [最初架构历史快照](2026-10-14/README.md)

### 定稿前 11 份 HTML 快照

- [l1-definition-decisions-and-roadmap.html](2026-10-16-before-v1-final/l1-definition-decisions-and-roadmap.html)
- [index.html](2026-10-16-before-v1-final/index.html)
- [l1-round05-form-lifecycle-validation-submission.html](2026-10-16-before-v1-final/l1-round05-form-lifecycle-validation-submission.html)
- [l1-definition-design-draft.html](2026-10-16-before-v1-final/l1-definition-design-draft.html)
- [l1-round03-behavior-reaction-command.html](2026-10-16-before-v1-final/l1-round03-behavior-reaction-command.html)
- [l1-round02-expression-pure-function-constraint.html](2026-10-16-before-v1-final/l1-round02-expression-pure-function-constraint.html)
- [l1-round01-data-value-reference-scope-binding.html](2026-10-16-before-v1-final/l1-round01-data-value-reference-scope-binding.html)
- [complex-dynamic-form-architecture-v1.html](2026-10-16-before-v1-final/complex-dynamic-form-architecture-v1.html)
- [l1-capabilities-and-abstraction-boundaries.html](2026-10-16-before-v1-final/l1-capabilities-and-abstraction-boundaries.html)
- [l1-round06-definition-protocol-convergence.html](2026-10-16-before-v1-final/l1-round06-definition-protocol-convergence.html)
- [l1-round04-view-profile-material-interaction.html](2026-10-16-before-v1-final/l1-round04-view-profile-material-interaction.html)

历史台账记录的 V1.0 初始用户来源 SHA-256：`de1dce61f695e45d7a2a4355448b08a0fbc8f8c59fb0e0040c45abe28bd63593`。该记录不等同于既有站内阅读副本摘要；本次来源包保存的术语统一前副本 SHA-256 为 `bb93e9e90e5f251c20f9d3bf1a1f1a7023cde2f1d25d723a8233bdeacde0a510`。
