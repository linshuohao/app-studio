# ADR-FE-003：静态视图复用与容器物料呈现

> id: ADR-FE-003 · type: decision · status: 已确认，端口子类型与适配 API 待固化 · module: L1 View / L4 / Material · tags: profile, binding, slots, template · last_reviewed: 2026-10-19

## 背景与约束 {#adr-003-context}

同一数据需要 PC 平铺、移动卡片或底部弹层等交互。早期 View Root / Target / Fragment 与 Presentation 契约存在重叠，也曾考虑独立 Validation Binding 和更泛化的模板参数。需要保留复用，同时控制协议概念数量与状态所有权。

## 已确认选择与取舍 {#adr-003-decision}

ViewNode 统一为 MaterialNode / ScopeNode / TemplateUse；具名 Profile 直接是 ViewNode，`default` 不是固定入口。Canonical 使用具名 bindings 和数组 slots；bind / children 仅是 Authoring 简写。Template 采用静态 `$use`、schemaRef 与 Typed DataReference，不共享 UI 实例或业务数据副本。

撤回 `view.present / view.dismiss` 及核心 Presenter，采用 Modal / Drawer / BottomSheet 容器物料和 Slots 自管开闭、焦点与动画。字段 / 校验状态由 Runtime 经已有 Binding 接入，不新增 validationBind / errorBind。Protocol 管统一机制，Manifest 管具体端口 / Props / Slots / Events，业务合法性仍由 Schema / Constraint 管。

这减少重复的展示控制器和参数类型系统，代价是容器物料承担平台交互与组合契约，模板不支持任意配置参数、动态模板 ID 或泛型证明。交互限制如 maxLength 不替代业务约束。

## 影响与状态 {#adr-003-consequences}

Profile 切换只替换视图订阅与局部状态，共享规则不能因不可见被裁剪。L4 使用 Prepared View，不再解析 AST。挂载 / 改绑 / 首次读取的一致性、端口类型和解析失败接口仍待设计；“Typed Params 可落地”不代表其正式类型包已经交付。

## 来源、替代与关联 {#adr-003-sources}

- 现行：[View / Binding / Slots / Template / Material](../l1/05-view-material-host.md#view)、[Renderer](../architecture.md#renderer)。
- 历史：[L1 修订 04–09 / 11](../l1/08-decisions-release.md#history)、[第四至六组与最终稿](../source-map.md#src-l1)、[Profile 去包装修订](../../history/README.md#profile-revision)。独立 fragments、entry 包装、Presentation 和 ValidationMetadata 候选已被明确替代。
- 关联：[ADR-FE-001](ADR-FE-001-boundaries.md)、[ADR-FE-005](ADR-FE-005-watch-subscription.md)；[OD-10 / 11 / 13](../governance.md#open-decisions)继续固化跨端接入。
