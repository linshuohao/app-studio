# ADR-FE-004：PreparedForm 是 Runtime 唯一执行入口

> id: ADR-FE-004 · type: decision · status: 已确认，ABI 未冻结 · module: L1 / L2 / L3 / L4 · tags: prepared, compiler, abi, source-map · last_reviewed: 2026-10-19

## 背景与约束 {#adr-004-context}

若 Runtime 同时解释原始 L1 和编译产物，诊断、依赖、能力锁及兼容检查可能出现双轨语义。编译发生在客户端还是发布期，不应改变执行含义；Prepared 必须可供多实例复用，不能携带会话数据。

## 已确认选择与原有备选 {#adr-004-decision}

FormDefinition 供作者编辑与审查，L2 静态转换为确定 PreparedForm，L3 只消费兼容 Prepared，L4 消费准备好的视图及观察关系。Authoring / Canonical 是同一 L1 的表示形式。客户端接收原始定义时也先调用 L2；ABI 或能力不兼容时明确失败，不静默回退直接解释 L1。

相对双轨候选，唯一入口减少语义漂移和重复解析，代价是编译与运行之间必须提供明确格式、兼容检查和分发契约。L2 不读取 Working Data、不执行业务纯函数或真实 Scope 实例化；Prepared 只保存静态关系与求值准备信息。

## 影响、限制与未决项 {#adr-004-consequences}

Prepared 的 Form / View / Dependency Plan 是结构方向，JSON / 二进制、具体字段、feature 与兼容矩阵尚未冻结。来源映射与编辑期增量分析仍为推荐；编译诊断的源位置需求已存在，不能据此宣称已实现逐行 Source Map。L1 Protocol、Compiler 与 Prepared ABI 独立识别。

## 来源、演进与关联 {#adr-004-sources}

- 现行：[双结构对照](../dependency-reactivity.md#dependency-compiled-protocol)、[L2 输入输出](../l2-preparation.md#l2-compile)、[兼容性](../l2-preparation.md#l2-versions)。
- 明确依据：V0.5 D01 / D02 / D05；[原件与整合记录](../source-map.md#src-v05)，原件第 01 / 02 / 06 章。阶段 V0.5 不是新的正式 Protocol Version。
- 关联：[ADR-FE-005](ADR-FE-005-watch-subscription.md)、[ADR-FE-011](ADR-FE-011-release-lock.md)；[OD-10 / T06](../governance.md#design-roadmap)应以实际消费需求固化 ABI。
