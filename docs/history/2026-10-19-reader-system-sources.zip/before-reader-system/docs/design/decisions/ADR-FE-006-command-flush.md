# ADR-FE-006：即时非原子 Command 与最新状态 Flush

> id: ADR-FE-006 · type: decision · status: 已确认，排序与异常完成待固化 · module: L1 Command / L3 · tags: immutable, batch, reaction, flush · last_reviewed: 2026-10-19

## 背景与原有候选 {#adr-006-context}

早期曾要求在候选树中执行整个 batch，全部成功后统一提交，执行失败不部分成功；也曾要求每次 Reaction 触发保留独立执行。V0.4 明确指出这些方向与即时输入和状态收敛目标不符。比较重点是输入可见性、动作次数、状态一致性和事务复杂度。

## 已确认选择 {#adr-006-decision}

采用不可变 Working Data Root 与结构共享，有效 Command 同步可见、旧 snapshot 稳定。batch / then[] 按序实时写入，默认非原子，不回滚已成功修改；单次结构操作仍须保持 Data / Scope 一致。

每条 Command 单独检测前后变化。Reaction pending 按实例去重，执行读取最新 Data，执行后再次失效可重新入队。显式 Command 保留顺序与次数，两次 insert 不合并；Reaction 不用于逐次事件记账。

V1 延迟一次启动同步 Flush，内部级联继续当前轮，多个外部 Operation 可共用一轮；Operation 是来源，不是独占业务事务。前轮结束后的异步回写形成新轮次。

## 代价与影响 {#adr-006-consequences}

可存在数据已更新而联动未完成的工作态；Flush 不提交或回滚整轮 Data，也不保证 UI 已绘制或异步校验结束。微任务不保证先画一帧，同步纯函数无法强制抢占。时间切片 / 优先级延期；准确启动点、排序和同步重入未冻结。

可隔离错误继续与整体熔断见 [ADR-FE-009](ADR-FE-009-errors-trace.md)；完整校验 / Submit 不能把 dispatch 返回或队列空当成全部完成，见 [REV-03](../governance.md#rev-03)。

## 来源与替代关系 {#adr-006-sources}

- 现行：[数据五不变量](../l3-reactive-engine.md#l3-data)、[Flush 归属](../l3-reactive-engine.md#l3-flush)、[Reaction 合并](../l3-reactive-engine.md#l3-reactions)。
- 历史候选：[第三组 B6 集成记录](../../history/2026-10-16-before-v1-final/changes-2026-10-16.md)；明确替代：[V0.4 第 04–09 章 / R01–R07](../source-map.md#src-v04)，V0.5 D06–D10 继续确认；V0.6 D05 确认逐 Command 检测。
- 旧“失败不部分成功”保留为历史，不与当前非原子契约并列生效。正式接口由 [OD-03 / 04 / 05](../governance.md#open-decisions)继续固化。
