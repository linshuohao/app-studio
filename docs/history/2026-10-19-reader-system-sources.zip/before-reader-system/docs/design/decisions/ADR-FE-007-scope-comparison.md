# ADR-FE-007：逐 Command 逻辑观察与相对 Scope 位置

> id: ADR-FE-007 · type: decision · status: 原则已确认；等值、索引与整数组策略为推荐 · module: L2 Plan / L3 Data-Scope / L4 · tags: identity, scope, change-context, dependency-index · last_reviewed: 2026-10-19

## 背景与问题 {#adr-007-context}

整对象导入不一定改变其内部被观察字段，数组移动改变位置也不等于同一人的年龄改变。不可变旧 Root 保住旧 Data，却不能自动保住原地修改的 Scope 旧位置。需要在变更边界解决比较，不把移动历史传给每条规则或 Renderer。

## 已确认原则 {#adr-007-decision}

每条 Command 取得前后 Data 与可稳定读取旧绑定的 Scope 视图，一致提交 Data / Scope 后定位候选，再比较同一逻辑观察目标。相对观察沿同一 ScopeId，固定路径观察同一位置。ChangeContext 只服务当前 Command，比较后释放，不进 pending 或沿规则链传播 ScopeChange。

ScopeId 与下标分离。Scope Index 的位置事实是父 Scope + 相对集合位置 + 本层位置，绝对路径按需解析；父移动不重写所有后代路径。Dependency Index 查观察者，Scope Index 查身份与位置，辅助索引不能成为第二个独立事实源。L1 不建全局词法注册表与 L3 实例登记并不冲突。

## 推荐方案与取舍 {#adr-007-options}

来源比较过周期全量快照、每规则保存上次执行参数、当前 Command 前后 Root，确认最后一种原则。前两者分别增加全表历史成本或常驻参数缓存，而且不准确代表上条 Command。逐条检测保留 25→26→25 两次失效，最终值相同也不撤销已有 pending。

Object.is / 存在性比较、Trie + 模板、局部旧 ScopeReadView、整数组默认重建仍为**推荐**；不能因来源正文写“已收敛具体结论”就高于其决策表状态。推荐引用比较避免全表深比较，代价是整对象新引用可保守失效；子字段同值可跳过。Trie 的真实成本取决于深度及命中的观察者，不能宣称所有操作恒定时间。

整行对象替换保留行身份，嵌套结构另行处理；整数组身份协调未冻结，不按姓名猜身份。删除回收旧实例，真实新实例才应用激活策略。Host 输入对象防御、连续结构操作与旧位置可信度仍需验证。

## 来源与关联 {#adr-007-sources}

- 完整规范：[检测](../l3-reactive-engine.md#l3-change-detection)、[等值](../l3-reactive-engine.md#l3-observed-equality)、[Scope](../l3-reactive-engine.md#l3-scope-index)、[数组生命周期](../l3-reactive-engine.md#l3-array-lifecycle)。
- 来源：[V0.6 第 05–14 / 16–19 章](../source-map.md#src-v06)，D04 / D05 / D10–D14 为确认，D16–D20 为推荐，D23–D25 为实现验证。
- 关联：[ADR-FE-005](ADR-FE-005-watch-subscription.md)、[ADR-FE-008](ADR-FE-008-host-editing.md)、[REV-07 / OD-07 / T04](../governance.md#rev-07)。本项不新增 L1 通配 Pointer、./ 路径或 length 语法。
