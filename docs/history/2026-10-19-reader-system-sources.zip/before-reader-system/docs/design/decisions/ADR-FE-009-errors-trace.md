# ADR-FE-009：可隔离错误继续、整轮保护与临时 Trace

> id: ADR-FE-009 · type: decision · status: 基线已确认；Pending、通知、Trace 接口仍待固化 · module: L3 / Diagnostics / Host · tags: errors, budget, trace, health · last_reviewed: 2026-10-19

## 背景与演进 {#adr-009-context}

状态规则可以成环但最终收敛；静态图有环不能证明死循环，运行时也无法通用证明任意函数终止。V0.4 保留普通错误隔离与整体 / 局部停止的选择，并提出跨轮局部不可信范围和 Health 恢复候选。V0.5 明确缩减其执行控制复杂度。

## 已确认选择与代价 {#adr-009-decision}

可隔离单 Command 错误记录后，后续独立命令和规则继续，已写 Data 不回滚。Reaction 不检查上游健康，只按自身 Watch / Scope / when 响应。执行预算超限停止整个当前 Flush，不维护父子规则控制、失败下游禁用、局部熔断或链级 Health。

保护采用同值过滤、pending 去重和本轮总数 / 单实例计数，阈值待标定。L2 的潜在环诊断不替代运行保护；SCC 具体算法为推荐。默认逐步全表 Hash / 热路径因果图被排除，局部指纹和高级图分析延期。取舍是以有限执行和可定位异常替代形式化终止证明和复杂影响链状态机。

Trace 是有序执行事实、实际 Change 与 triggeredBy 来源；首次 Reaction 入队建立临时 Context，正常轮结束释放，异常先提取受限报告，Devtools 自行持久保存。执行预算与记录预算独立，Trace 截断不能停止保护；同一规则多次执行有不同 executionId。

## 未决边界与影响 {#adr-009-open}

整体停止后的 Pending 清理 / 保留 / 再触发、错误分类与门控失败、通知重入、Outcome 对完整校验 / Submit 的影响仍待决策。禁止自动无限重启遗留任务，但不据此推断所有具体重试行为已经确定。

头尾或仅尾截断、参数摘要 / 脱敏、副本、事件 API、限频与阈值尚未冻结。Trace 解释调度原因，不证明所有输入为业务计算必要条件，也不承诺历史值恢复或确定性 Replay；Trace 不参与调度许可。

## 来源、替代与关联 {#adr-009-sources}

- 现行：[保护](../l3-reactive-engine.md#l3-protection)、[错误](../l3-reactive-engine.md#l3-errors)、[Trace / 预算](../l3-reactive-engine.md#l3-trace)。
- 来源：[V0.4 第 10–15 章 / R08–R24](../source-map.md#src-v04)；[V0.5 第 08 / 10–13 章与 D09–D12](../source-map.md#src-v05)明确替代局部 Health 候选，现行 R12 / R14 / R15 / R16 保留修订说明。
- 关联：[ADR-FE-006](ADR-FE-006-command-flush.md)、[REV-03](../governance.md#rev-03)、[OD-03 / 04 / 12 与 T02](../governance.md#open-decisions)。
