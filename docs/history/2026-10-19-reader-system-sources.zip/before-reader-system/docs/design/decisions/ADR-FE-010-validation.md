# ADR-FE-010：完整 Schema、增量 Constraint 与字段错误消费

> id: ADR-FE-010 · type: decision · status: 主线已收敛；前置增量边界待决策，存储 / 消息为推荐 · module: L1–L4 Validation / Host · tags: schema, pending, requires, issues, readiness · last_reviewed: 2026-10-19

## 背景、约束与原有方案 {#adr-010-context}

Schema 组合语义难以安全拆成每字段 Keyword 单元；固定“Schema→全部同步→全部异步”不能表达真实前置；给 Validation 再建结果 PubSub / 通用异步 DAG 会重复响应式调度。UI 主要需要字段错误，但执行正确性仍依赖新鲜度、是否完成和适用性。

## 已收敛选择 {#adr-010-decision}

首版保留完整根 JSON Schema，经平台 Adapter 只读执行；业务 Constraint 独立于 Ajv Keyword ABI。复用 Data / Scope / 依赖匹配，命中后去重登记本轮 Constraint；正常 Reaction 收敛后校验，没有 Reaction 也有入口。普通增量不在 Runner 扫全部规则推断依赖；完整校验显式覆盖全部适用规则。

本轮检查前置并必要重排，不把发起顺序当成通过，不建立结果反向 PubSub 或通用跨异步 DAG；多步异步优先封装为同一 Host External。按字段聚合错误供 L4 / Host 消费，规则不随 View 挂载失效，校验不写 Data 或自动触发 Data-only Reaction。

来源比较过局部 Schema 引擎、固定同步 / 异步阶段、结果反向索引、向 UI 暴露每源复杂状态机和自动补齐前置；以上均未作为当前采用方案。代价是根 Schema 仍需完整校验，前置任务选择需进一步验证，不能用“更简单”隐藏其影响。

## 推荐实现与未决边界 {#adr-010-open}

按 Source 保存、字段索引派生、同步原子替换、聚合内容变化才通知、默认消息模板加局部覆盖为推荐。过期 / 已销毁实例返回不能提交是必要正确性，具体代次 / token 实现为推荐。Issue、消息覆盖、多语言、Source / SDK 均未冻结。

严格“前置不在本轮则诊断跳过”只是当前倾向：A 的旧结果有效、仅 B 入增量 Pending 时的行为未解决；跨轮前置变化而 B 未入队的资格撤销同样待设计。`requires` / `validationMessages` 未作为当前候选 Canonical 字段发布，不通过本 ADR 自动加入。

无 Issue 不证明通过。完整返回需表达业务失败、不完备和输入过期，必要外部义务与输出仍须核对；准确 valid / invalid / incomplete / stale 编码、异常 Flush 交接、等待范围、Context 证明均待固化。Web Ajv / Dart 是 Adapter 方向，不宣称现有 Dart 库已通过；性能必须实测。

## 来源、演进与关联 {#adr-010-sources}

- 当前完整规范：[L3 校验全文](../l3-validation.md)、[L1 Constraint / Readiness](../l1/03-expression-validation.md#constraint)。
- 来源：[第五组义务与 Readiness 演进](../../history/2026-10-16-before-v1-final/changes-2026-10-16.md)；[V0.7 原件](../source-map.md#src-v07)第 03 / 05–14 / 16 章。D06 的收敛倾向须与 D14 待验证一起读，D09–D13 不提升为冻结接口。
- 关联：[ADR-FE-005](ADR-FE-005-watch-subscription.md)、[ADR-FE-008](ADR-FE-008-host-editing.md)、[ADR-FE-009](ADR-FE-009-errors-trace.md)；[REV-01 / 02](../governance.md#rev-01)、[OD-01 / 02 / 09 / 12](../governance.md#open-decisions)。
