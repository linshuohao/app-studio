# 架构治理：一致性审查、设计状态与后续路线

> id: GOV-FE-001 · type: architecture-review · status: 审查记录与建议，非新增架构决策 · module: 全层 · tags: constraints, conflicts, readiness, open-decisions, roadmap · last_reviewed: 2026-10-19

本篇集中维护设计约束索引、审查问题、模块完成度和设计任务，规范性规则继续在所属主题维护。完整现行设计从[整体架构](architecture.md)进入；重要结论的来源和 ADR 见[来源映射](source-map.md)。本次未实现或发布生产引擎，也未替用户选择未决方案。

## 资料范围与判定方法 {#review-scope}

**事实**是资料中可直接定位的内容；**已确认决策**须有明确结论或替代记录；**推断 / 建议**是本次审查提出的分析；**未知 / 待决策**表示来源未闭环。这四类不能相互替代。本篇的问题严重程度、实施准入判断和建议顺序均属于审查判断，不冒充原讨论结论。

本地范围包含现行整体架构、使用指南、L1 八个主题及阅读分组、L2、依赖订阅、L3 执行、L3 校验、领域词汇、历史索引与轮次记录、历史 HTML 和 ZIP 来源、候选验证源及现有报告。读取历史是为了核对决策演进；旧内容不因较长或更具体而恢复效力。来源包中的脚本只作为文本证据，不执行附件代码。目录 / 文件 / 章节及摘要由[覆盖清单](source-map.md#source-inventory)记录。

原始对话没有完整逐字导出。Runtime / Host 修订仅有明确标识的决策摘录，不能补造决策人、会话轮次或逐字引语。站内历史 HTML 曾统一纯函数术语，逐字证据应使用原始 ZIP。不存在于本地的外部材料、未保存的讨论和生产实现均不在本次覆盖范围内。

完成度以“职责 → 模型 → 接口 → 流程 → 生命周期 → 异常 → 验收证据”逐项判断，不按篇幅或写代码与否打百分比。**可局部验证**允许探索实现；**可形成正式实现契约**要求相关未决项已解决；**生产验收通过**必须另有实现证据。

## 全局约束与模块责任 {#global-constraints}

下表是约束检索入口，完整技术说明以链接正文为准。编号 G01–G12 是本次建立的稳定索引，不是新协议字段。

| ID | 已确认约束 | 权威正文 | 关联 ADR |
| --- | --- | --- | --- |
| G01 | 表单数据交互为核心范围；请求、提交和业务流程归 Host | [产品边界](architecture.md#boundary)、[Host](l1/05-view-material-host.md#host) | [001](decisions/ADR-FE-001-boundaries.md) |
| G02 | 单实例唯一 Working Data；View / Profile 不复制权威业务数据；工作态允许业务不合法 | [Data](l1/02-data-reference-scope.md#data) | [001](decisions/ADR-FE-001-boundaries.md) |
| G03 | 受限纯 AST、结构化 Reference、局部词法 Binder；无任意脚本或动态写路径 | [表达式](l1/03-expression-validation.md#expression)、[Scope](l1/02-data-reference-scope.md#scope) | [002](decisions/ADR-FE-002-static-language.md) |
| G04 | L3 只消费兼容 Prepared；L2 静态编译，不读取实例或执行纯函数 | [双结构](dependency-reactivity.md#dependency-compiled-protocol)、[编译边界](l2-preparation.md#l2-boundary) | [004](decisions/ADR-FE-004-prepared-entry.md) |
| G05 | Read / Watch / Subscription 分离；Reaction 显式 Watch 由作者确认，不自动增删 | [Watch 审查](dependency-reactivity.md#dependency-watch-review) | [005](decisions/ADR-FE-005-watch-subscription.md) |
| G06 | Command 即时不可变写入；batch / then 默认有序非原子；逐 Command 检测 | [Data / Command](l3-reactive-engine.md#l3-data)、[检测](l3-reactive-engine.md#l3-change-detection) | [006](decisions/ADR-FE-006-command-flush.md) |
| G07 | Reaction pending 可合并、执行读最新状态、内部级联归本轮；显式 Command 保留次数 | [Reaction](l3-reactive-engine.md#l3-reactions)、[Flush](l3-reactive-engine.md#l3-flush) | [006](decisions/ADR-FE-006-command-flush.md) |
| G08 | Scope 身份与下标分离；Data / Scope 一致发布；位置存父级相对关系 | [Scope Index](l3-reactive-engine.md#l3-scope-index) | [007](decisions/ADR-FE-007-scope-comparison.md) |
| G09 | runOnActivate 仅新规则实例；稳定 snapshot；业务 Baseline / Dirty / Reset 归 Host；Context 保留现行只读契约 | [四条原则](l3-reactive-engine.md#l3-runtime-host-boundary) | [008](decisions/ADR-FE-008-host-editing.md) |
| G10 | 可隔离错误继续独立行为；预算超限停整个 Flush；无局部 Health；Trace 不参与执行许可 | [错误](l3-reactive-engine.md#l3-errors)、[Trace](l3-reactive-engine.md#l3-trace) | [009](decisions/ADR-FE-009-errors-trace.md) |
| G11 | 完整根 Schema + 独立 Constraint；校验只读，字段聚合不等于完整通过；过期异步结果不可提交 | [校验](l3-validation.md#validation-baseline)、[完整性](l3-validation.md#validation-completeness) | [010](decisions/ADR-FE-010-validation.md) |
| G12 | Material / Pure Function / Host 分责；发布锁定版本和不可变制品；L1 Protocol 与 Prepared ABI 独立 | [能力与发布](l2-preparation.md#l2-release) | [011](decisions/ADR-FE-011-release-lock.md) |

跨模块规则的主要维护位置：L1 管声明语义；L2 管编译、能力绑定与发布交接；依赖专题管使用位置和订阅生命周期；L3 执行专题管数据 / Scope / Flush；校验专题管校验结果与完备性；整体架构保留各层目标、取舍、图示及集成，不退化成摘要。术语只在[领域词汇](../CONTEXT.md)维护，历史和 ADR 解释原因，不成为另一份运行规则。

## 一致性审查结论与问题 {#consistency-findings}

没有发现必须推翻四层主架构的证据。已确认的全局边界基本一致；真正妨碍正式跨模块实现的是若干未闭环契约。下列“高”表示应阻止相关接口冻结或发布，不代表线上事故。问题区分设计张力、缺口、表面冲突和已有明确替代的历史差异。

### REV-01：严格本轮前置与增量集合尚不兼容 {#rev-01}

- **双方与来源：**[仅命中 Constraint 入 Pending](l3-validation.md#validation-pending)；[前置不在本轮则诊断跳过](l3-validation.md#validation-round)，以及 V0.7 D06 / D14 的不同成熟度。
- **类型 / 严重程度：**设计张力，已知未闭环，高。不是两份已冻结协议冲突。
- **具体表现：**A 只读 idNumber，B 只读 name 且依赖 A；仅改 name 时 B 入队、A 旧结论仍有效却不在本轮。严格检查会跳过 B，即使本次输入满足业务条件。
- **影响：**增量执行、前置编译、Host 请求、完整校验返回和作者诊断。
- **解决方向（建议）：**用同一案例比较严格本轮、编译保证共同入队、允许使用仍有效前置结论的取舍；现行仅保留严格倾向，不自动补齐、不改 Watch。**需要决策：是，OD-01 / T01。**

### REV-02：跨轮前置资格撤销没有完整触发闭环 {#rev-02}

- **双方与来源：**[异步结果要求前置资格有效](l3-validation.md#validation-async)；[不建立前置结果反向 PubSub、只消费本轮 Pending](l3-validation.md#validation-round)。
- **类型 / 严重程度：**隐含依赖缺口，高；来源已明确待固化。
- **具体表现：**B 的异步请求在途，随后仅 A 的输入变化使 A 不通过，B 自身输入未变且不入本轮。需要说明谁撤销 B 资格、旧 Issue 和在途结果；仅比较 B 的 Data watch 不足以说明该行为。
- **影响：**过期结果隔离、Scope 内前置关系、Source 贡献和 Submit。
- **解决方向（建议）：**随 OD-01 明确资格的依赖范围和失效入口，再验证 A valid→invalid→valid、B 乱序返回。不得借此悄悄建立被排除的结果订阅系统。**需要决策：是，OD-01 / OD-02 / T01。**

### REV-03：异常 Flush 到校验与提交的交接仍未定义 {#rev-03}

- **双方与来源：**[可隔离错误继续 / 整轮预算停止](l3-reactive-engine.md#l3-errors)；[正常联动后校验及完整返回](l3-validation.md#validation-completeness)。
- **类型 / 严重程度：**跨模块完成契约缺口，高。
- **具体表现：**已写 Data 保留，但剩余 Pending、后续触发资格、是否继续校验、Outcome 如何影响完整校验和 Submit 均未冻结。队列空不能证明成功；不得恢复旧局部 Health 机制填补空白。
- **影响：**Runtime、Validation、Host 保存 / 提交和执行观察 SDK。
- **解决方向（建议）：**联合固化整轮 Outcome 与 Pending 状态转换，给出错误后继续、熔断、再次输入、销毁四类轨迹。**需要决策：是，OD-03 / OD-04 / T02。**

### REV-04：数组命令的 Schema 限制存在歧义 {#rev-04}

- **双方与来源：**[L1 Command 表](l1/04-command-reaction.md#commands)将 array.insert 描述为“受目标 Schema 约束”；[L3 数据不变量](l3-reactive-engine.md#l3-data)允许业务不合法工作态。
- **类型 / 严重程度：**可能的接口行为冲突，资料不足，中。尚不能断言已违反 G02。
- **具体表现：**目标是数组且 maxItems=5，插入第六项应写入后报 Issue，还是拒绝 Command？“结构位置合法”与“满足业务 Schema”没有在该行区分。原子结构一致性不自动回答业务限制是否拦截。
- **影响：**所有数组操作、导入、Command 错误分类、校验一致性。
- **解决方向（新增建议）：**按结构可执行性与业务合法性逐例界定，保留现有文字直至形成明确结论。**需要决策：是，OD-05 / T03。**

### REV-05：外部规则身份到 Host Validator 的映射缺失 {#rev-05}

- **双方与来源：**[L1 External Constraint](l1/03-expression-validation.md#constraint)只有规则 id / watch / target 等；[L2 Host 示例](l2-preparation.md#l2-host)用 `insurance.eligibility` 注册 Validator；[完整样例](l1/07-examples.md#sample)的规则 id 为 `insured-eligibility`。
- **类型 / 严重程度：**责任交接与接口缺口，中。
- **具体表现：**示例名称不必相同，但未说明规则 id 是否就是能力 key，还是由 Host / 编译上下文另作映射。不能推断存在未声明的 validator / payload 字段。
- **影响：**Host Requirements、必需能力预检查、同能力多条规则复用、请求输入和结果归属。
- **解决方向（新增建议）：**先用两条规则复用一项 Validator 的例子比较同名约定与显式外部映射；选择后对齐 L1 / L2 / SDK。**需要决策：是，OD-08 / T05。**

### REV-06：Context 与完整校验证明的新鲜度缺少接入机制 {#rev-06}

- **双方与来源：**[现行 Context 只读 / Data-only Watch](l3-reactive-engine.md#l3-runtime-host-boundary)；[完整证明关联 Context](l3-validation.md#validation-async)。
- **类型 / 严重程度：**新鲜度接口缺口，中；两项原则可以共存，不构成扩展 Context Watch 的依据。
- **具体表现：**完整校验使用渠道或策略上下文后，Host 换入新上下文，旧证明怎样被识别为不可复用尚无 SDK。局部请求有效性与整体输入证明也须分别处理。
- **解决方向（建议）：**明确受控输入身份和 Host 重新完整校验的入口，不自动增加 Context Command / Reaction Watch。**需要决策：是，OD-09 / T02 / T05。**

### REV-07：稳定旧值依赖外部共享对象不被原地修改 {#rev-07}

- **双方与来源：**[不可变 Snapshot](l3-reactive-engine.md#l3-data)；[共享对象防御仍待验证](l3-reactive-engine.md#l3-observed-equality)。
- **类型 / 严重程度：**实现前提尚待证明，中；不是另建历史快照系统的理由。
- **具体表现：**Host 持有导入对象后原地修改，会破坏旧 Root、观察值比较和快照稳定性。禁止、复制、冻结等方式的成本与边界未决定。
- **影响：**所有读取、变化检测、snapshot 和异步输入。
- **解决方向（建议）：**写入入口与输出入口各验证对象别名泄漏，选择最小防御契约；不要求每步深拷贝全表。**需要决策：OD-06 中的对外约束；具体数据结构归 T04 的实现验证。**

### REV-08：候选规范与样本之间有明确的未迁移边界 {#rev-08}

- **来源：**[短 ID 与 core.*](l2-preparation.md#l2-function-identity)、[runOnActivate 尚未定型](l1/04-command-reaction.md#reactions)、[前置和消息语法未发布](l3-validation.md#validation-layers)、[验证证据边界](../validation/README.md)。
- **类型 / 严重程度：**已知规范固化差异，中；本次不按正式发布后的兼容缺陷处理。
- **具体表现：**现有 Canonical 候选样本保留短函数名，类型汇编没有激活策略，候选 Schema 不支持 requires / validationMessages。通过现有探针不能证明新契约已覆盖。
- **解决方向（建议）：**正式固化时一次对齐类型、Schema、别名、正反例与版本说明；本次保留样本和边界说明。**需要决策：OD-06 / OD-07 / OD-11；迁移由 T03 / T06 验收。**

### REV-09：历史替代及同名概念不是现行冲突 {#rev-09}

| 表面不一致 | 审查判定与来源 | 是否重新决策 |
| --- | --- | --- |
| L1 不建全局 Scope Registry，L3 却有 Scope Index | 前者是词法 Binder，后者是实例位置登记；[L1](l1/02-data-reference-scope.md#scope-handle)已区分 | 否 |
| V0.6 自动 Baseline / Reset 重算与当前 Host 边界相反 | 有明确用户替代；[ADR-008](decisions/ADR-FE-008-host-editing.md)保留旧依据 | 否 |
| 旧 batch 失败不部分成功与当前非原子 batch 相反 | 已由 V0.4 / V0.5 明确替代；[ADR-006](decisions/ADR-FE-006-command-flush.md) | 否 |
| V0.4 局部 Health 与当前整体熔断相反 | V0.5 明确撤回 Health；[ADR-009](decisions/ADR-FE-009-errors-trace.md) | 否 |
| Schema 根全量与 Constraint 增量同时存在 | 不同校验域、不同成本；[校验入口](l3-validation.md#validation-pending) | 否 |
| UI 聚合 Issue 简化，但内部保留完备性 / 请求代次 | 显示消费与执行正确性不同；[校验结果](l3-validation.md#validation-results) | 否 |
| Prepared activation 与 runOnActivate 都含激活字样 | 前者说明观察生命周期归属，后者是首次执行策略；[计划边界](dependency-reactivity.md#dependency-plan) | 字段消歧归 OD-06 / OD-10，不重开职责 |

未发现必须新建 View Engine、Workflow Engine、校验结果总线或独立同步 Validator DSL 的证据。为填补以上缺口引入这些机制是新增设计提案，必须另作成本评估，不能当作文档整理。

### REV-10：规范化输出仍只有目标，没有完整转换契约 {#rev-10}

- **双方与来源：**[L1 Data / Output](l1/02-data-reference-scope.md#data)要求输出转换后单独校验；[整体状态所有权](architecture.md#runtime)区分 Working Data 与 Normalized Output；[Submit 准备](l3-validation.md#validation-completeness)又依赖输出有效性。
- **类型 / 严重程度：**跨模块数据交付缺口，中。
- **具体表现：**转换由哪个接入层调用、输入 / 输出类型、是否存在独立输出 Schema、转换失败如何归类、完整校验证明关联转换前还是转换后结果，尚无足够信息。不能把“全表校验通过”直接当作输出转换已定义。
- **影响：**M02 / M13 / M15、Host 保存与正式提交；不阻止不涉及提交的局部原型。
- **解决方向（新增建议）：**从一个工作态含临时输入但输出需明确类型的例子推演，确定最小只读输出契约及失败 / 新鲜度关联；不默认增加通用 Codec DSL 或在校验中回写 Data。**需要决策：是，OD-14 / T05。**

## 纵向与横向完整性矩阵 {#design-status}

以下为 2026-10-19 基于正文与附件的**审查判断**。模块 ID 用于检索，不宣称对应代码包已存在。“可开始”仅针对所列范围；所有生产模块都缺少正式端到端实现验收证据。

| 模块 ID / 范围 | 已确定内容及依据 | 尚未确定 / 阻塞项 | 设计闭环判断 | 可进入的工作 |
| --- | --- | --- | --- | --- |
| M01 全局分层 | [四层与 Host / 扩展责任](architecture.md#architecture) | 不要求先决定物理包或部署 | 架构责任闭环；不等于每层契约闭环 | 可作为后续设计和包边界约束 |
| M02 L1 数据 / 引用 / 词法 Scope | [结构化引用、局部 Binder、Missing / null](l1/02-data-reference-scope.md#reference) | Union、存在性、位置命令、Schema 兼容；OD-05 / 06 / 11 | 主体语义收敛，正式规范未闭环 | 可固化类型 / 反例；不标正式协议可发布 |
| M03 Expression / Pure Function | [纯 AST、递归 ValueSpec、boolean assert](l1/03-expression-validation.md#expression) | 短名映射、签名、错误、跨端类型；OD-11 | 职责闭环；机器契约未闭环 | 可做纯求值与静态分析原型 |
| M04 L1 View / Template / Binding | [三类节点、端口、Slots、Typed Params](l1/05-view-material-host.md#view) | 端口子类型、组合 Schema 兼容；OD-11 | 声明模型收敛，类型证明未闭环 | 可固化 Canonical 和 Manifest 测试 |
| M05 L2 编译与诊断 | [四项工作与作者确认](l2-preparation.md#l2-compile) | Prepared / Diagnostic / Host 映射；OD-08 / 10 / 11 | 模块设计部分闭环 | 可做受控解析 / 分析验证；正式输出待冻结 |
| M06 能力与发布治理 | [双流水线、不可变锁与回滚](l2-preparation.md#l2-release) | 摘要对象、兼容矩阵、Host 缺失分级；OD-08 / 10 / 11 | 原则闭环；发布接口未闭环 | 可设计发布契约；不能称有生产发布平台 |
| M07 数据 / Snapshot | [即时不可变 Root、稳定读](l3-reactive-engine.md#l3-data) | 外部对象防御、Missing、snapshot SDK；OD-06 | 不变量明确，接入细节部分闭环 | 可验证结构共享、旧快照；不作稳定 SDK 承诺 |
| M08 Scope / 变化索引 | [逐 Command 比较、相对位置](l3-reactive-engine.md#l3-change-detection) | 等值、整数组替换、旧位置视图 / 性能；OD-07 | 原则闭环；身份与观察契约未全闭环 | 可跑 V0.6 场景原型，Trie 仍推荐 |
| M09 Reaction / Flush / 错误 | [最新态合并、同轮级联、整体停止](l3-reactive-engine.md#l3-flush) | 重入、排序、Pending、Outcome；OD-03 / 04 | 正常流程明确；异常 / 重入未闭环 | 可验证正常路径；正式调度接口受阻 |
| M10 Schema Adapter | [完整只读 Schema](l3-validation.md#validation-schema) | Draft / 关键词 / format / Dart 等价与性能；OD-11 | 方向明确，跨端契约未闭环 | 可验证 Adapter；没有跨端通过证据 |
| M11 Constraint 前置与增量 | [共享匹配、本轮整理](l3-validation.md#validation-round) | 缺失前置、跨轮资格、引用语法；OD-01 / 02 | 未闭环，高优先级 | 先推演和决策；不冻结 requires |
| M12 异步校验 / Issues | [有效性保护、来源与字段聚合](l3-validation.md#validation-results) | Source / Issue、token、通知 / 前置撤销；OD-02 / 09 / 12 | 正确性约束明确；接口未闭环 | 可做来源隔离与乱序验证原型 |
| M13 完整校验 / Submit 交接 | [全适用覆盖、不能以无 Issue 判通过](l3-validation.md#validation-completeness) | 异常、等待范围、输入证明和输出转换；OD-03 / 09 / 12 / 14 | 未闭环 | 先完成跨模块契约，Host 真实提交另实现 |
| M14 L4 / Material Adapter | [挂载订阅、Profile、UI 生命周期](dependency-reactivity.md#dependency-view) | Prepared 求值、首次读 / 改绑一致性、解析失败；OD-10 / 13 | 责任明确，SDK 未闭环 | 可做最小主端适配验证，不能直接照草图交付 |
| M15 Host / 实例生命周期 | [三路径、业务编辑归 Host](l1/06-lifecycle-profiles.md#lifecycle) | 创建 / 替换 / 销毁、能力映射、缺失等级；OD-06 / 08 / 09 | 责任闭环；接入未闭环 | 可设计业务恢复与请求保护，待 SDK 对齐 |
| M16 Trace / Devtools | [临时线性事实、预算分离](l3-reactive-engine.md#l3-trace-budget) | 截断、敏感参数、事件协议与阈值；OD-04 / 12 | 原则明确，观测接口未闭环 | 可定义事件模型和边界基准；Replay 延期 |
| M17 文档与候选验证工具 | [复现入口和明确证据边界](../validation/README.md#reproduce) | 不覆盖 Prepared / 真正 Runtime / 跨端 | 已有可执行工具；覆盖范围有限 | 可继续维护和复跑，结果不能外推生产能力 |

横向检查覆盖以下接缝：L1→L2 语义与类型（M02–M06）；L2→L3 静态计划 / ABI（M05、M08、M09）；Data↔Scope 一致性（M07–M08）；Reaction→Validation→Host 完成（M09–M13）；Runtime↔L4 快照和订阅（M12–M15）；生命周期与异步适用性（M08、M12、M15）；锁定、Trace 与源位置（M06、M16）。性能 / 测试 / 观测 / 安全已有目标与责任说明，尚无足以证明目标端性能或完整隔离的实现结果。

## 待决策事项 {#open-decisions}

OD 是本次建立的跨主题问题编号。以下选项只有明确注明“来源候选”的才代表原资料讨论；其余均为**新增分析建议**。本表只索引未知项，最终结论应回写对应专题和 ADR，不在这里维护第二套规范。

| ID / 类别 | 具体问题与已有基础 | 可比较方向与当前状态 | 依赖 / 影响 / 下一步 |
| --- | --- | --- | --- |
| OD-01 / A | 增量缺少前置如何处理？已有本轮链 / Pending | 来源候选：严格跳过、编译保证共同入队、使用仍有效旧结论；当前仅倾向严格跳过 | 前置：G05 / G11；影响 M05 / 11 / 13；先完成 REV-01 案例，T01 |
| OD-02 / A | 字段有效性前置范围、跨 Scope 引用与跨轮资格失效 | 来源未定：仅 Schema 或含明确同步 Constraint；引用字段 / 规则如何解析；不隐含通用异步 DAG | 依赖 OD-01；影响 M08 / 11 / 12；推演 REV-02，T01 |
| OD-03 / A | 整体熔断后的 Pending / 再触发与异常校验 / Submit | 来源明确禁止自动无限重启；清理 / 保留及重试边界未定。新增建议：以明确入口和 Outcome 表比较轨迹 | 依赖 G10、OD-01；影响 M09 / 13 / 15；T02 |
| OD-04 / A | 同步通知重入、执行顺序和运行中再次失效 | 来源推荐稳定规则 / 入队顺序、外部重入归本轮；准确通知保护未确认 | 前置：G06 / G07；影响 M09 / 14 / 16；用 C16 和同目标写入验证，T02 |
| OD-05 / B | array.insert / move 位置与结构错误分类 | 位置语法未定；REV-04 的业务限制边界需澄清；不擅自增加新命令 | 前置：G02 / G06；影响 M02 / 08 / 09；T03 |
| OD-06 / B | 新实例激活默认值、创建 / 替换 / 销毁及稳定快照 SDK | 首次可配置且仅新实例已确认；字段、默认值、错误和持有语义未定；对象别名防御待验证 | 前置：G09；影响 M07 / 09 / 15；T03 / T04 |
| OD-07 / B | 观察等值 / Missing / 结构编码及整数组身份策略 | 来源推荐 Object.is、局部旧 ScopeReadView、整数组重建；Trie 是实现候选，不直接成为 ABI | 依赖 OD-05 / 06；影响 M05 / 08 / 12 / 14；T04 |
| OD-08 / B | External 到 Host 能力映射、输入报告与缺失等级 | 来源已定 Requirements / 运行时注册；一般事件、服务缺失等级未定；REV-05 映射选项为新增建议 | 依赖 G01 / G12；影响 M05 / 06 / 12 / 15；T05 |
| OD-09 / B | 局部异步结果与完整证明如何关联 Data / Context / 实例 | 来源已有代次保护和 valid / invalid / incomplete / stale 语义；SDK / 等待范围未定 | 依赖 OD-01 / 03 / 08；影响 M12 / 13 / 15；T02 / T05 |
| OD-10 / B | Prepared ABI、版本兼容、求值 / 订阅 / 首次读与改绑交接 | Form / View / Dependency Plan 方向已定；计划存储、feature、粒度仍未定 | 依赖 T01–T05 的最小消费契约；影响 M05 / 06 / 14；T06 / T07 |
| OD-11 / B | 正式类型 / Schema、内置签名别名、Manifest / 锁 / Schema Adapter 等价范围 | 来源均列为待固化；不因本次增加 ADR 而宣称已有发布版本或 Dart 选型 | 依赖 M02–M06 / M10；影响全层；T03 / T06 / T08 |
| OD-12 / B | Issue、完整结果、Source 通知和 Trace 事件最小公共结构 | 来源推荐来源存储 / 原子通知、头尾截断与受限参数；确切形状与优先级未定 | 依赖 OD-03 / 04 / 09；影响 M12 / 13 / 16；T05 / T07 / T08 |
| OD-13 / B | 输入解析失败、组合端口、UI 临时值的交付边界 | 只确认 Working Data 不退回旧合法值、UI 局部状态归 L4；Codec / 解析失败接入契约尚不足 | 依赖 OD-10 / 11；影响 M02 / 07 / 14；用非法数字与输入法组合态推演，T07 |
| OD-14 / B | Normalized Output 的转换归属、类型、验证和失败 / 新鲜度 | 只确认独立构造 / 校验与 Host 真实提交；具体输出 Schema、转换接口、完整证明关联未定义 | 依赖 OD-09 / 11 / 13 的相关输入约束；影响 M02 / 13 / 15；推演 REV-10，T05 |

A 表示应先解决的跨模块架构行为；B 表示方向明确但需模块设计。C 类为可推迟的实现选择：局部旧视图物理表示、索引缓存、预算阈值与限频常数；对外可观察行为仍须先定。D 类为未来扩展：稳定业务 Key 协调、时间切片 / 优先级、历史恢复 / 确定性 Replay、局部 Hash、完整设计器与物料市场。除非出现证据，不把 D 升为当前阻塞。

## 按依赖推进的设计路线 {#design-roadmap}

下面的顺序、任务 ID 和优先级是**审查建议**，承接[原有完整路线](architecture.md#roadmap)。并行箭头表示设计可互相验证，不要求完成整层代码才讨论下层。

```diagram
{
  "id":"figure-governance-roadmap",
  "title":"建议设计顺序：先闭合行为，再冻结接口与验证实现",
  "rows":[
    [{"title":"T01 · 校验前置闭环","body":"增量缺失与跨轮资格；OD-01 / 02"},{"title":"T03 · L1 与生命周期固化","body":"命令、激活、Union / 内置契约；OD-05 / 06 / 11"}],
    [{"title":"T02 · Flush / 完整校验完成","body":"Pending、重入、异常 Outcome、Submit；依赖 T01 的完成语义"},{"title":"T04 · Data / Scope 观察验证","body":"等值、替换、旧位置、快照防御；承接 T03"}],
    [{"title":"T05 · Host / 结果接入","body":"能力映射、代次、Issue、输入证明；承接 T01 / T02 的相关行为"}],
    [{"title":"T06 · 最小 Prepared 与发布契约","body":"联验消费结构、兼容与锁；以 T01–T05 为输入"}],
    [{"title":"T07 · 主端纵切验证","body":"输入 → Command → Flush → 校验 → 字段 → Host 完整结果"}],
    [{"title":"T08 · 跨端 / 性能 / 发布验收","body":"Golden Tests、真实设备成本、Trace、兼容迁移"}]
  ],
  "arrows":["↓ 相关行为交叉验证","↓","↓","↓","↓"],
  "note":"先定义契约再实现；T03 的独立规范工作可与 T01 并行。预算常数、缓存和数据结构在原型中标定，候选验证通过不代替生产验收。"
}
```

| 任务 / 优先级 / 分类 | 具体问题、现有基础与尚未知内容 | 前置依赖 / 影响 | 下一步、预期输出和完成标准 |
| --- | --- | --- | --- |
| T01 / 最高 / A | 在本轮链基础上解决 REV-01 / 02；未知为缺失、字段范围、跨轮失效 | G05 / G11；M05 / 11 / 12 / 13 | 先推演 A(idNumber)、B(name)及在途返回；输出确认后的决策、前置引用 / 实例绑定契约；V10–V13、缺失 / 环 / 兄弟 Scope / 资格撤销均有确定结果，不静默加 Watch |
| T02 / 最高 / A | 已有整体 Flush 边界；未知为 Pending、通知重入、异常完整结果 | T01 的校验完成语义；M09 / 13 / 15 / 16 | 输出状态转换、Outcome / 等待 / 再触发契约及错误分类；C16 / C17、单 Command 失败、熔断再输入、无 Reaction 校验、Context 变更均不误报成功，通知递归有界 |
| T03 / 高 / B | L1 主体已收敛；未知为位置命令、激活字段 / 默认值、严格 Union 与兼容 | G02 / G03 / G09；与 T01 并行，M02–M04 / 15 | 输出无占位类型 / 候选 Schema、别名 / Literal / Binder / Manifest 契约；澄清第六项插入与结构错误，类型 / Schema / 正反例互相对应，新激活仅新实例 |
| T04 / 高 / B+C | 已有逐 Command 前后比较和相对位置；未知为等值、数组替换、防御 / 实现成本 | T03 相关命令和生命周期；M07 / 08 / 12 / 14 | 输出观察 / 身份契约及最小原型证据；V0.6 的 01–16 与 B01–B08 对应稳定行为，连续 move/remove/insert 无串项，旧 snapshot 不变；Trie / 旧视图存法依据测量选定 |
| T05 / 高 / B | 已有 Host 三路径与来源 / 字段聚合；未知为能力映射、请求 / 结果、Context 证明与输出转换 | T01 / T02 相关行为、T03 能力契约；与 T07 的输入边界交叉验证；M06 / 12 / 13 / 15 | 输出 Requirements / 注册 / token / Issue / 完整结果及只读规范化输出契约；相同能力多规则、A→B→A、无关字段变化、销毁后成功与异常、缺必需能力、输入过期、转换失败均有验收，输出证明不得错配输入 |
| T06 / 高 / B | 已有两份结构和独立 ABI；未知为序列化、版本 / Lock / Diagnostic 细节 | T01–T05 最小消费需求；M05 / 06 / 14 | 输出可序列化 Prepared / Format 兼容矩阵、能力锁、诊断及来源关联；同锁定输入可复现、多实例隔离、Profile 不裁剪共享规则、不兼容拒绝且不回退 L1 |
| T07 / 中 / B | 主链职责已知；未知为框架首次读 / 订阅交接和解析失败 | T02 / T04 / T05 / T06；M07–M15 | 输出主端 Adapter、一个完整业务纵切及失败轨迹；覆盖挂载 / 改绑同时修改、父条件创建子树、复合端口不重复写、非法数字 / 输入法、移动后 Issue 跟随同一人、完整校验再由 Host 提交 |
| T08 / 中 / C，部分 B | 已有边界验收和性能目标；未知为跨端等价、真实性能 / Trace / 发布门槛 | T07；全层 | 输出 Web / Dart 共享向量、目标设备基准、Trace 截断 / 脱敏契约、迁移 / 回滚验证；V01–V16、C01–C18及跨层场景有实现证据，阈值有测量依据；未达成项继续公开，不假定全部模块可发布 |

T01 / T02 阻塞相关公共行为冻结，不阻止 T03 的独立规范工作或 T04 的验证原型。已有候选工具可以继续运行；不因设计未全闭环而将所有工程探索停下，也不以原型成功代替正式契约。

## 增量维护与变更准入 {#governance-maintenance}

新资料到达后，先更新[来源清单与映射](source-map.md#incremental-coverage)，判断它是补充、明确替代、候选还是冲突，再更新所属规范、相邻图文、ADR 的状态 / 替代链及本篇受影响条目。重复数字须带来源命名空间，例如 `L2.D01`、`DEP.D01`、`V05.D01`；不得把历史待确认重新列为当前未决。

本次 ADR 采用 `ADR-FE-001` 起的独立命名空间，与历史规划中的 ADR-01 / ADR-07 无隐式替代关系。已有阶段 D / R / B / V 编号全部保留，ADR 只提取背景与取舍，完整执行规则不复制维护。问题关闭须给出确认依据、受影响规范、反例及结果；建议被采纳后才更新为已确认，不以文件保存或日期先后代替决策。

正式发布准入至少需要：相关 A / B 问题闭环；正式类型与 Schema 对齐；Prepared / SDK / Manifest / Lock 兼容约定明确；代表业务正反例及生命周期、异常、异步、跨端行为有实现证据。当前证据不足以给任何生产模块盖“验收完成”章；文档生成与候选探针的通过只证明其声明范围。
