# 表达式、约束与校验

> L1 V1.0 架构与语义决策正文；正式类型、Schema 与发布验收状态见各节。

## Expression AST 与 ValueSpec {#expression}

> 状态：已收敛

**概念类型 · 正式 Union 仍需消歧校验**

```typescript
type Expression =
  | JsonPrimitive
  | { ref: Reference }
  | { use: string }
  | { op: string; args: Expression[] }
  | { literal: JsonValue };

type ValueSpec =
  | JsonPrimitive
  | { $expr: Expression }
  | { $literal: JsonValue }
  | ValueSpec[]
  | { [key: string]: ValueSpec };
```

Expression 是纯计算 AST，采用严格类型、有限内置 Pure Function 与版本化领域纯函数。Named Expression 可复用，但全局命名表达式不得隐式捕获调用方的局部 Scope；V1 不引入参数化函数语言。

**Pure Function 命名与能力边界 · 2026.10.17 架构决策**

内置与注册的同步纯计算统一称为 Pure Function（纯函数），使用同一调用协议；复杂同步校验直接复用领域纯函数，不新增平行的同步 Validator DSL。纯函数不执行 I/O、不读外部可变状态、不修改数据，也不管理 Scope 或校验状态；Constraint 负责适用条件、Issue 目标和错误码，内部 `assert` 必须返回 boolean。

本次保留 Expression 的 `op + args` 字段。`core.*` 为内置能力保留命名空间，业务 ID 不得覆盖；短 ID 的明确别名与规范化映射随正式契约固化，现有草案示例暂保留短名。L2 按确定 Catalog 解析签名与依赖，L3 绑定锁定实现；版本和制品锁不新增为 L1 顶层字段。详见 [L2 纯函数命名](../l2-preparation.md#l2-function-identity) 与 [能力契约](../l2-preparation.md#l2-manifests)。

**动态 Expression 可以出现在任意嵌套 ValueSpec 内**

```json
{
  "material": "summary-card",
  "props": {
    "title": "投保摘要",
    "badge": {
      "visible": {
        "$expr": {
          "op": "eq",
          "args": [
            { "ref": { "source": "data", "path": "/plan" } },
            "premium"
          ]
        }
      }
    }
  }
}
```

| 协议位置 | 表达式形态 |
| --- | --- |
| `constraint.assert` / `reaction.when` / `expressions.*` | 直接使用 Expression AST |
| `props.*` / `command.value` / `host.emit.payload` | 递归 ValueSpec，通过完整的 `$expr` 包装进入表达式 |
| 需要原样保留标记对象 | 通过显式 Literal 转义表达，不能按普通对象形状误判表达式 |

**读取、触发与订阅 · 2026.10.17 跨层依赖模型**

Expression 描述可能读取什么，本身没有订阅生命周期。L2 按类型递归分析 AST、Named Expression 与嵌套 ValueSpec，再按使用位置决定哪些读取形成触发依赖；L3 匹配活跃订阅，L4 管理 View 订阅的挂载与释放。不能扫描整份 JSON，把恰好包含 `ref` / `$expr` 的普通数据认成表达式。

| 合法使用位置 | 求值入口 | 变化是否自动形成观察依赖 |
| --- | --- | --- |
| `expressions.*` | 被引用时纯求值 | 仅提供读取集，由使用方决定触发；不捕获调用方局部 Scope |
| `reaction.watch` | 变化匹配 | 显式触发来源，保持 DataReference[] |
| `reaction.when` | watch 命中或显式首次激活入队后判断 | 否，不自动追加到 Reaction.watch |
| `reaction.then` / `command.value` 中的 ValueSpec | Command 执行时 | 否，按执行时当前数据求值 |
| Internal Constraint `when` / `assert` | 初始化、主动校验或依赖变化后的校验入口 | 是，合并二者所有可能读取 |
| External Constraint `watch` / `when` | 失效匹配 / 适用性判断 | watch 显式补充 Host 输入，when 可见读取自动合并 |
| View `bindings` | 首次读取与后续投影更新 | 是，端口所读数据；Field State 经 L3 接入契约消费 |
| View `props` 中的动态 ValueSpec | 首次求值与后续更新 | 是，含物料定义的禁用、可见性等动态 Props |
| Material 事件映射与 `host.emit.payload` 中的 ValueSpec | 事件实际发生时 | 否，不因读取字段变化而发出事件 |
| `ScopeBinder.from` | 绑定及实例化 | 结构性关系，用于创建、删除、重排和改绑 |
| Constraint `issue.target` / external `target` | Issue / 义务定位 | 目标本身不自动成为读取或触发依赖 |

L2 保守覆盖短路计算的全部可能输入，Literal 内部不做表达式分析。对象作为纯函数参数时按对象子树观察；V0.7 校验设计将完整 JSON Schema 保留为根级校验域，首版不自动拆分条件 / Keyword 局部单元。纯函数依赖只来自显式参数，不通过执行它推断输入。完整编译、Scope 与激活契约见 [跨层依赖与订阅](../dependency-reactivity.md)。

> **求值失败的语义**
> 
> 解析失败或类型不匹配不等于 Expression 返回 `false`，也不等于自动使用最近一次合法值。同步业务 Constraint 不通过、外部校验 Pending 也不应自动阻断全部 Reaction。

## Constraint：内部断言与外部校验义务 {#constraint}

> 状态：已收敛

**Internal · 可同步求值的业务约束**

```json
{
  "id": "age-eligible",
  "kind": "internal",
  "scope": {
    "from": { "source": "data", "path": "/insureds" },
    "as": "insured",
    "mode": "each"
  },
  "assert": {
    "op": "gte",
    "args": [
      { "ref": { "source": "data", "scope": "insured", "path": "/age" } },
      18
    ]
  },
  "issue": {
    "target": { "source": "data", "scope": "insured", "path": "/age" },
    "code": "AGE_BELOW_MINIMUM"
  }
}
```

**External · 声明义务，不声明 URL 或请求策略**

```json
{
  "id": "insured-eligibility",
  "kind": "external",
  "scope": {
    "from": { "source": "data", "path": "/insureds" },
    "as": "insured",
    "mode": "each"
  },
  "watch": [
    { "source": "data", "scope": "insured", "path": "/age" },
    { "source": "data", "scope": "insured", "path": "/idNumber" }
  ],
  "target": { "source": "data", "scope": "insured", "path": "/idNumber" },
  "requiredForSubmit": true
}
```

内部约束使用可选 `when` 和必需的 `assert`；外部约束声明依赖、归属位置及是否阻断提交。**Constraint 不执行 Command，不设计 onFail 动作链。**

Internal Constraint 的触发依赖来自 `when + assert` 的读取并集，无需再填 watch。例如 `when` 读取年龄、`assert` 读取监护人姓名，两者任一变化都可能改变结果；条件不再适用时移除该规则实例的旧 Issue。`issue.target` 只管错误归属，不代表唯一输入。

External Constraint 的 `watch: DataReference[]` 显式声明 Host 内部不透明的 Data 输入，与可选 `when` 的静态可见读取合并为失效依赖。当前协议没有 External Payload 字段，不据来源稿中的候选描述新增字段。依赖变化立即使旧结论失效并可登记本轮校验任务；是否立即请求 Host 由 blur、显式 validate、submit 或待固化的自动策略决定。V0.7 给出自动增量路径，不等于冻结所有外部校验每次输入都请求；watch 不描述 URL、请求策略或回调时机。

**字段迁移：**现行草案将原 `dependsOn` 改为 `watch`，引用值保持不变；旧字段仅保留在历史来源中。现行 Canonical 不接收旧字段或双字段混用。正式协议版本号、旧版识别与迁移工具尚待发布规范固化，本次不虚构版本号或宣称兼容已发布数据。Reaction.watch 的语义保持不变。

**有限前置与消息覆盖 · V0.7 设计方向**

校验前置在本轮 Constraint 链中检查、必要重排序，不增加校验结果反向 PubSub 或通用异步 DAG。来源的 `requires` 只是语法占位：字段有效性范围、规则 / 字段引用、跨 Scope 绑定和 Prepared 表示尚未冻结。本轮缺少前置时“诊断并跳过、不自动补齐”是当前倾向，旧有效前置未入本轮的增量例子仍需验证；不能据此静默扩展 Watch。默认消息 + 局部覆盖为推荐，来源 `validationMessages` 也不是本次新增的正式顶层字段。完整规则与取舍见 [校验专题](../l3-validation.md#validation-round)。

## 校验状态与提交 Readiness 的协议边界 {#validation}

> 状态：已收敛

L1 声明完整标准 Schema 和业务 Constraint，不在 Form Definition 中保存 `validationState`。L3 复用数据依赖匹配，登记去重的校验任务，在正常 Reaction 收敛后执行根 Schema 和本轮 Constraint 链；没有 Reaction 时也有校验入口。外部能力由 Host 执行，返回由 Runtime 核对适用性。

以下概念继续表达内部正确性与完整校验所需事实，不要求每个来源都对 View 暴露五态状态机：

| 概念 | 语义 |
| --- | --- |
| unverified | 尚未对当前有效输入取得结论 |
| pending | 对应校验正在进行 |
| valid | 当前有效输入验证通过 |
| invalid | 当前有效输入验证未通过，产生业务 Issue |
| error | 校验执行错误，以诊断区分，不能被当成通过 |

V0.7 推荐按 Source 保存 Issue、以 ScopeId + 相对路径形成字段聚合，View / Host 消费聚合结果，内容实际变化时才通知。同步结果原子替换以避免闪烁；异步输入失效撤销本来源过期 Issue，不清除其他来源。不暴露复杂状态不等于“没有 Issue 就通过”；内部仍要判断是否已执行、请求代次、输入有效性和 Scope 存活。Issue 最小结构、排序、去重与 SDK 仍待固化，详见 [结果与字段订阅](../l3-validation.md#validation-results)。

一个外部 Constraint 在数组 Scope 下派生多个实例义务，独立输入 / 请求代次避免无关字段变化误伤请求。返回成功与异常都须核对当前实例、Scope 和代次；失效、删除或替换后旧结果不得覆盖当前状态。多步异步业务优先封装在同一 Host External 实现，不由本轮排序推导跨规则异步等待能力。

普通增量只覆盖本轮命中规则，显式完整校验需覆盖全部适用 Constraint。Submit Readiness 仍依赖所需 Reaction 完成、Schema / 内部约束、输出有效性和所有当前适用且 requiredForSubmit 的外部义务。完整结果需区分当前通过、业务失败、未完成 / 配置或执行异常、输入已过期，不能以“队列空 / 未知 / 请求失败 / 无 Issue”冒充通过；具体 valid / invalid / incomplete / stale 编码与等待 API 未冻结。完整证明须与所验证输入关联，不同于单个外部请求的局部有效性。

正常校验在同步联动收敛后执行，异步不纳入 Reaction Flush 等待。V0.5 已退出局部 Health / 受损范围传播；可隔离错误或整体熔断后校验是否继续、Outcome 如何影响提交仍待 [完成契约](../l3-validation.md#validation-completeness) 固化，不建立失败下游禁用。真实保存、权限与提交归 Host。

Constraint 随 FormRuntime / Scope 激活，不随 View 挂载或隐藏建立、注销。初始化与主动校验有明确入口，不依赖先发生数据变化，subscribe 不隐含首次执行。Context 保留现行 Host 提供 / 表达式只读 / Data-only Command 与 Watch 契约，不由完整结果新鲜度要求推导新 Context 触发协议。

> **与 View 的关系已经定稿**
>
> View 的 `bindings` 只写数据位置。无需 `validationBind`、`errorBind` 或物料校验管理字段；Runtime 提供字段 Issue 聚合，Material 决定交互呈现。查询 / 订阅接口与字段有效性前置的精确范围仍见 [L3 校验设计](../l3-validation.md)。
