# L3 Reactive Engine：数据更新、Scope、Flush 与诊断

本篇在 L3 V0.4 的 20 节、R01–R26 与 C01–C18 基础上，整合 V0.5 对 Prepared 唯一入口、可隔离错误继续、整体 Flush 熔断及缺失值的修订。V0.6 补充逐 Command 检测、相对 Scope Index 与首次激活；后续用户修订明确 Dirty / 业务 Baseline / Reset 策略归 Host，普通 Reaction 不承担业务结果自动修复。V0.7 校验设计另归 [校验执行、结果与字段订阅](l3-validation.md)，补齐正常路径的校验消费，不改变本篇 Flush / Host 边界。候选索引与比较方案保留原状态。旧局部 Health 传播候选已被替代，修订理由与原件保留追溯。来源状态、当前确认和未决事项分别表达；没有冻结正式接口，也不表示运行时已经实现。整体职责见 [设计者指南](architecture.md#runtime)，渐进理解见 [使用与开发指南](usage-guide.md#usage-updates)。

## 执行基线与设计状态 {#l3-baseline}

核心路径是：外部 Operation 发出 Command → Working Data 即时更新 → Dependency Index 定位 Watch 候选 → 比较前后观察值 → 无有效变化则跳过，有变化才使对应 Reaction 入队 → 合并 pending → 延迟启动 Flush，执行至队列清空或安全停止。Reaction 写回继续进入当前 Flush；前轮结束后到达的 Host 异步结果形成新的失效和轮次。

当前规范按状态所有权、数据 / Scope、执行、错误、追踪和消费者顺序展开，末尾来源总账作为追溯附录。非原子修改、Scope、Host 编辑边界和错误 / Trace 的背景分别见 [ADR-006](decisions/ADR-FE-006-command-flush.md)、[007](decisions/ADR-FE-007-scope-comparison.md)、[008](decisions/ADR-FE-008-host-editing.md)、[009](decisions/ADR-FE-009-errors-trace.md)。未闭合的异常完成 / Pending、旧值防御及正式接口在[审查问题](governance.md#consistency-findings)与[路线 T02 / T04](governance.md#design-roadmap)集中跟进，不改变本篇已确认基线。

| 状态 | 内容 |
| --- | --- |
| 已确认 | L3 只消费 PreparedForm；不可变 Working Data / 即时 Command / 非原子 batch；最新状态合并与同轮级联；延迟启动同步 Flush；可隔离错误继续独立命令和规则；超限整体熔断；临时线性 Trace 与最小来源；首次入队建立 Context；缺失值由业务规则处理 |
| 已确认方向 | Devtools 可独立观察并保存执行历史，开启与关闭不改变语义 |
| 推荐 | Object.is 观察值比较、Trie / 模板组合、局部旧 ScopeReadView、整数组替换重建 Scope、位置型匹配；稳定队列顺序、静态 SCC 算法、Trace 头尾截断和编译 Source Map |
| 已确认 · 现行职责边界 | 每条 Command 前后 Root / Scope 检测；常规 Reaction 只响应有效 Watch 变化；runOnActivate 仅新实例首次激活；字段无业务所有权；稳定 snapshot；Dirty / 业务 Baseline / Reset 策略归 Host，不绕过 Watch 重跑已有实例 |
| 待讨论 / 固化 | 首次激活字段默认值、实例建立 / 替换与稳定快照 SDK；通知重入、精确排序、Pending、异常 Flush / Validation / Submit 衔接、错误分类及 ABI；业务 Dirty / Reset 策略不再作为 Runtime 未决项 |
| 待实现标定 | 局部旧 Scope 视图、共享对象防御、Trie / 模板 / Scope 解析性能；执行次数、耗时、记录容量和上报限频阈值 |
| 延期 | 时间切片 / 优先级、全量或局部 Hash、高级因果图分析、历史 Snapshot 恢复与确定性 Replay |

可隔离错误继续与超限整体熔断已经确认，不再列为两种可自由选择的候选。显式激活原则沿用，自动业务基准和 Reset 主动重算被本次边界修订替代；后续优先验收字段 / 默认值、稳定快照、Data / Scope 比较、通知和 Pending；记录容量、参数与阈值在实现中固化。来源中的后续会议建议和个人复核控件不改变决策状态。跨层 22 项来源决策见 [V0.5 总账](dependency-reactivity.md#dependency-v05-decisions)。

## Runtime / Host 职责：四条已确认原则 {#l3-runtime-host-boundary}

2026.10.19 用户明确确认以下原则，优先于 V0.6 中自动 Baseline 与 Reset 重算的旧结论。Runtime 是协议驱动的数据、规则和校验运行时，保证按声明正确执行；它不推断作者的业务结果期望，也不主动修复未被正确配置触发的字段。

| 已确认原则 | L3 执行含义 |
| --- | --- |
| 数据是事实 | 用户、Host、Reaction 修改同一字段进入同一 Command / 变化检测流程；来源可供诊断，不改变执行资格或字段所有权 |
| 有效依赖变化决定常规执行 | Dependency Index 定位 Watch 候选后比较观察值；无有效变化不新增入队，不因业务结果看似错误重算 |
| 初始化激活是独立入口 | runOnActivate 只在新 Reaction 实例首次建立时应用，不是重跑已有实例的便捷入口 |
| 编辑状态归外部业务 | Dirty、业务 Baseline、Reset 意图由 Host 定义；Runtime 提供稳定读 / snapshot / Command / Validation / Flush 等能力 |

```text
已有 Reaction：watch = [data:/age]，then = set premium 为按年龄计算的值
当前 Data：{ age: 25, premium: 150 }
Host 普通对象导入：{ age: 25, premium: 80 }
观察 age：25 → 25，无有效变化，已有规则不新增入队
结果：premium 保持 Host 导入的 80；Runtime 不主动恢复成 150
```

若整对象本身被另一条规则明确观察，引用变化仍可能使那条规则失效；这不改变只观察 age 的规则。常规修改不重建现有实例来伪装首次激活。若数组替换按身份契约真正创建新 Scope / 新规则实例，则按新实例的显式激活策略处理，不能把它解释成已存在实例的 Reset 重算模式。

“无有效变化不新增入队”不取消先前变化已经登记的 pending。逐条 Command 的 age 25→26→25 发生了两次有效观察值变化，同实例可合并执行一次；它与“从头到尾 age 都是 25、仅 premium 被覆盖”不同。Flush 的队列处理仍以已登记失效为依据，不通过业务结果正确性或上次执行参数猜测是否运行。

Context 由用户另外确认沿用现行契约：Command 只修改 Data，Reaction.watch 仍为 DataReference[]，Context 对表单表达式只读且由 Host 提供。此处流程统一描述受控更新，不借本次边界修订增加 Context 写入命令、Context Watch 或强制重算。

以下是后续实现的边界验收，不是现有候选探针通过记录：

| 编号 | 场景 | 必须观察到 |
| --- | --- | --- |
| B01 | 无先前 pending，导入 age25 / premium80 覆盖 age25 / premium150 | 只 watch age 的现存规则不执行，不自动修复 premium |
| B02 | Host Reset 恢复值，所有相关 Watch 均无有效变化 | 不新增已有规则任务，不重用 runOnActivate |
| B03 | Host 恢复 Command 使实际 Watch 值改变 | 正常匹配、比较、入队、合并与 Flush，无特殊 Reset 分支 |
| B04 | 取得 snapshot 后继续修改 Data | 旧快照稳定；读取不 Flush、不标 Clean、不创建 Baseline |
| B05 | 新建规则实例，随后仅重挂 View 或恢复同一实例数据 | 首次按策略运行；后两者不会再次当作该实例首次激活 |
| B06 | Host 自选快照与字段定义 Dirty / 保存 / Reset | Runtime 无 isDirty、markClean、resetToBaseline 或用户 / 派生字段分类 |
| B07 | age25→26→25 在 Flush 前先后发生 | 两次有效失效保留语义，pending 可合并；不因最终值等于旧值撤销既有任务 |
| B08 | 尝试将 Context 当作 L1 Command 目标或新 Watch 类别 | 维持现行只读 Context / Data-only Watch，不因本次修订放宽 |

## 概念与状态所有权 {#l3-ownership}

| 概念 | 含义与身份 | 生命周期 |
| --- | --- | --- |
| Operation | 外部 dispatch 的来源，可有 Operation ID | 不独占一轮 Flush；未命中 Reaction 时可无需 Flush |
| Command | set / patch / remove / array.* / batch 数据修改意图 | 按顺序执行，保留显式动作次数 |
| Data Change | 真实有效变化；Change ID 关联目标 Scope / Path | 用于失效匹配与追踪；同值调用不虚构有效变化 |
| Reaction Instance | Reaction ID + 实际 Scope 身份 | 随 Form / Scope 激活，可在同轮多次执行 |
| Pending | 按 ReactionInstanceKey 去重的待执行集合 | 属于 Reactive Engine，执行或中止时消费 / 处理 |
| Flush | 一次消费待执行实例的过程，具有 Flush ID | 队列清空、执行错误处理或保护停止时结束 |
| Flush Context | 本轮计数、来源、临时 Trace、预算和异常标志 | 首次 Reaction 入队建立；结束后释放 |
| ChangeContext | 当前 Command 前后 Data / Scope ReadState 与局部 impact | 本次比较结束即释放，不进 pending 或后续轮次 |

| 所有者 | 状态 | 释放 / 更新条件 |
| --- | --- | --- |
| L3 Data / Scope | 当前不可变 Root、稳定只读快照、数组身份与位置映射 | Runtime 生命周期；有效 Command 更新当前状态；不持有业务 Baseline / Dirty |
| Host 业务应用 | 异步加载、所选业务快照、Baseline / Dirty / Reset 意图、保存与提交策略 | Host 自行定义与保存；恢复意图生成普通 Command |
| Reactive Engine | 依赖索引、活跃观察者、pending、调度阶段 | 订阅 / Runtime 生命周期；不是全部放进 Context |
| Flush Context | 总执行数、单实例次数、外部重入标记、有序执行证据 | 本轮结束 / 中止；异常先提取报告 |
| Validation | Issues、校验状态、请求新鲜度及失效状态 | 独立于 Reaction Flush |
| Diagnostics / Host | 真实错误、整体预算停止原因、必要轮次报告 | Context 清理前提取；Host 可去重限频，不维护局部 Reaction Health 传播 |
| L4 / Host / Devtools | UI 状态与框架订阅、外部任务、可选历史 | 各自消费者生命周期 |

调度阶段与轮次结果分别表达。`idle / scheduled / flushing` 是阶段草图；`settled / aborted / completed_with_errors` 是结果草图，均非正式冻结枚举。可隔离错误继续其他独立行为已确认，但不能把出错或预算中止记为无异常收敛。V0.4 曾建议跨轮保存局部不可信范围，V0.5 明确不建立这套 Health、失败下游禁用或链级恢复状态；Submit 如何消费轮次结果继续单独固化。

Runtime 实例只根据兼容 PreparedForm 建立，按 Prepared Observation 匹配实际变化；不直接解释原始 L1，也不在运行时补 Watch。ABI 失败不得回退到原始定义解释器，见 [两份协议与唯一执行路径](dependency-reactivity.md#dependency-compiled-protocol)。

## 即时不可变数据与有序 Command {#l3-data}

五项不变量：

1. 业务值允许暂时不合法。清空必填项、超出年龄限制可以进入 Working Data，Validation 报告问题。
2. 有效 Command 同步生效。紧接着读取当前 Data 应看到修改，不等待 Reaction 或校验完成。
3. 每次更新形成不可变 Root，未变化子树可以结构共享；旧 Snapshot 保持稳定，不逐步深拷贝整张表单。
4. 单次数组结构操作同时保持 Data 与 Scope Identity 一致，不能暴露索引与身份映射错位的半完成状态。
5. 数据已更新不等于 Renderer 已绘制；调度延迟不保证浏览器先画一帧。

```text
读取 Snapshot v1：age = 20
执行 set age = 25
立即读取当前 Snapshot v2：age = 25
再次读取先前持有的 v1：仍为 age = 20
联动 premium 此刻可能尚未完成，需分别判断收敛状态。
```

默认 `batch` 和 Reaction 的 `then[]` 都按顺序执行 Command，各条有效修改实时生效，不默认回滚先前成功写入。该边界取代“候选数据树中完成整个 batch 后原子提交”的早期候选。业务 Invalid、Scope 已删除、非法数组位置、非法 Command 是不同结果；后几种属于结构性执行失败，单个结构操作仍须保持内部一致性。可隔离的单条 Command 失败应记录并报告，后续独立 Command 继续尝试，其他 Reaction 仍只由有效 Data Change 和自身 watch 决定；精确错误类型、返回值与无法继续的结构性条件待固化。

组合 batch 的每条实际子 Command 仍分别取得前后状态并完成检测，不能仅在整组结束后比较一次净结果。显式首次激活是独立入队原因；这里“按有效 Data Change”描述变化传播，不取消激活策略。

两条显式 `array.insert` 各执行一次，不能因目标相同被合并；待执行 Reaction 的多次失效可以合并，两者属于不同层次。同值短路放在实际变化判定中，基本值应避免无意义传播；对象不默认全量深比较；V0.6 推荐按观察值 Object.is 与存在性比较，子路径同值跳过、对象引用变化保守失效，具体编码继续固化。

## 实例初始化、稳定快照与 Host 业务基准 {#l3-initialization-baseline}

2026.10.19 用户进一步收敛职责：Runtime 不自动建立业务 Baseline，不维护 Dirty，也不把 Reset 变成 Reactive Engine 的特殊执行模式。这替代 V0.6 的“Runtime 初始收敛后建立基准”和“Reset 后按当前环境主动重算”结论；旧设计与修订理由保存在 [本次来源归档](../history/README.md#runtime-host-boundary)。

```text
Host：加载外部数据，选择初始输入
  → Runtime：装载兼容 PreparedForm + Working Data
  → Runtime：建立 Scope、规则实例和观察注册
  → 新 Reaction 实例：仅按 runOnActivate 首次入队
  → Flush：执行已入队规则，内部写回继续经过普通依赖变化检测
  → Host：按业务需要观察完成结果，可取得 snapshot() 自行保存业务 Baseline
```

新实例首次激活是明确的独立入口，不是“让数据保持正确”的授权。它只在新 Reaction 实例建立时应用；已有实例不会因导入、Reset、结果不符预期、读取快照或收到“重算意图”再次应用 runOnActivate。策略默认值、正式字段形状、实例建立 / 销毁与 SDK 仍需固化。真正创建新 Scope / 规则实例时按策略激活；不得为重跑已有实例伪造重建生命周期。

Runtime 提供稳定快照读取能力，是否保存、何时替换业务 Baseline 由 Host 决定。Host 可以在初始 Reaction 完成后保存快照，也可以依业务选别的时点；这不是 Runtime 的固定基准建立阶段。snapshot() 仅返回当前稳定数据表示，不隐式 Flush、不等待所有异步 Validation、不标记 Clean、不自动建立任何业务历史。初始规则未完成时取得的快照仍只是当时数据，所需完成 / 观察 API 另行固化。

```typescript
// 职责草图，正式类型、错误、返回值与完成观察接口仍待固化。
interface FormRuntime {
  read(ref: DataReference): unknown;
  snapshot(): FormData;
  dispatch(command: Command): void;
  // 数据订阅、规则执行观察与 Validation 等能力另按各自契约提供。
}
```

业务 Dirty 回答“用户是否修改了需要保存的数据”，不同应用可以有不同定义：

| Host 场景 | 可采用的业务判断 |
| --- | --- |
| 普通资料编辑 | 当前数据是否与所选加载快照不同 |
| 投保单编辑 | 需要提交的投保信息是否被修改 |
| 自动计算表单 | 计算结果变化是否应算用户编辑，由业务决定 |
| 审批系统 | 指定字段是否计入编辑状态 |
| 实时数据表单 | 外部数据变化是否计入用户修改 |

这些取舍不进入 Runtime 核心：不增加 isDirty、markClean、resetToBaseline，不因编辑状态区分用户字段 / Reaction 字段、基础字段 / 派生字段或修改来源。L3 的前后 Root、Scope 旧位置视图与临时 Trace 继续服务变化检测、稳定身份和诊断，不充当业务 Baseline。

Reset 由 Host 按业务定义生成普通恢复 Command；即使上层提供 reset() 便捷 API，也遵守同一修改、观察值比较、Scope 与错误契约。恢复后若有效 Watch 没变，已有 Reaction 不执行。Host 若希望使用当前费率，必须用正确的显式 Watch 配置或实际数据修改表达条件，不能调用绕过依赖检测的 Runtime 重算入口；Context 仍沿用现行只读输入与受控宿主入口，不扩展 L1 Command / Watch 到 Context。

异步数据加载、防止迟到响应覆盖编辑、保存 / 提交策略与业务 Baseline 都由 Host 编排。创建实例或显式初始化输入的准确 SDK 尚未冻结；普通对象导入仍是 Command，不代表重新创建规则或重置业务基准。初始校验、异步义务和 Submit 完成条件继续按各自契约设计。

## 单条 Command 内完成变化检测 {#l3-change-detection}

```diagram
{
  "id":"figure-l3-change-detection",
  "title":"Command 内的 Data / Scope 一致更新与观察失效",
  "rows":[
    [{"title":"读取变更前状态","body":"previousRoot + 可稳定读取旧绑定的 ScopeReadView；只保留本次需要的材料"}],
    [{"title":"完整提交 Data + Scope","body":"不可变更新与结构共享；结构操作不暴露只改数据或只改身份的半状态","major":true}],
    [{"title":"索引定位候选观察者","body":"Prepared 路径模板 + Trie 等索引；结合父子路径、结构影响与 Scope"}],
    [{"title":"比较前后逻辑观察值","body":"存活相对观察沿同一 ScopeId，绝对观察沿同一路径；生命周期分别处理"}],
    [{"title":"投递失效标识","body":"Reaction pending 去重；Validation 失效；View / Host 按各自协议通知"}],
    [{"title":"释放本次 ChangeContext","body":"不向下游传旧位置或 ScopeChange；只留下所需 ChangeId / Trace 关联"}]
  ],
  "arrows":["↓","↓","↓","↓","↓"],
  "note":"候选命中不是最终触发。比较逐条 Command 完成，Reaction 真正执行时读最新数据；通知时机与同步重入仍待固化。"
}
```

ChangeContext 不是 Reaction 输入，也不是 Flush Context。每条 Command 临时保留 previousRoot / nextRoot 与可读旧 Scope 位置，提交 Data / Scope 后定位候选、比较观察值，结束后即可释放。结构操作的 before / after 必须各自一致；下一个 Command 从上一个已提交状态继续，不等 Operation 或 Flush 结束才推导变化。

一次 Command 的有效 Data Change 不保证每位观察者失效：对象替换可能改变 Root / 父对象引用，而被观察的 age 值仍相同。来源、Command 名称与“谁会写这个字段”均不改变比较规则；显式只 watch age 的规则，不因 premium 被另一份数据覆盖就自动重算。

## 观察粒度、相等性与旧值来源 {#l3-observed-equality}

比较的是 Watch 所观察的值，不是整张表单的深度差异。**具体默认采用 `Object.is` 的方案为 V0.6 推荐项**，不是已冻结公共协议；它表达基本值比较及对象 / 数组引用比较，跨端等价行为仍需契约与验收。存在性如何编码也须与 Missing 读取契约一致，不能把缺失与 null 或合法的 0 / false 混同。

| 观察位置 | 修改前 → 后 | 推荐方案下是否失效 |
| --- | --- | --- |
| /insured/age | 25 → 25 | 不失效，即使父对象换了引用 |
| /insured/name | 张三 → 李四 | 失效 |
| /insured | 旧对象 → 新对象，内容可以相同 | 引用不同，保守失效 |
| /insured/address/city | 深圳 → 深圳 | 不失效 |
| /insured/beneficiaries | 旧数组 → 新数组 | 引用不同，失效 |

```typescript
// 推荐比较草图；Observed、存在性与跨端编码待固化。
function sameObservedValue(a: Observed, b: Observed) {
  return a.exists === b.exists && Object.is(a.value, b.value);
}
```

JSON 输入主要区分缺失与 null；若运行时允许显式 undefined，还需明确它与不存在的区别。Host 不得原地修改两个 Root 共用的对象，否则旧值与引用判断不再可信；输入复制、冻结或其他防御方式属于实现验证，不提前指定成本更高的统一策略。

| 旧值方案 | 状态成本与差别 | 当前方向 |
| --- | --- | --- |
| 周期性完整 Snapshot | 周期不能精准代表当前 Command 前状态，增加全表保存 | 不采用为变化检测基线 |
| 每个 Reaction 缓存上次执行参数 | Scope × 规则常驻缓存，且比较的是上次执行而非上条 Command | 默认不采用 |
| previousRoot / nextRoot | 两个引用，结构共享使旧值可读，不深拷贝全表 | 已确认前后 Root 原则 |

每条 Command 前后比较还能保留“25→26→25”的两次真实变化；不能把它偷换为“最终值等于上次 Reaction 参数，所以没变化”。同一实例仍只有一份 pending，实际执行读取最终值。Root 的临时持有与消费者主动持有旧 Snapshot 的生命周期分别管理，不要求强制销毁外部快照，也不永久保存所有 Root。

## Dependency Index：候选路径定位与 Prepared 模板 {#l3-dependency-index}

Trie / 前缀树与编译依赖模板结合是推荐实现方案：L2 输出规范化路径、Scope Slot 和静态依赖计划；L3 结合实际订阅与真实 Scope 建立可查询索引。Trie 不必成为 Prepared ABI，L2 不能把运行时所有被保人的实例节点编译写死。

```text
Prepared 路径模板 / 推荐运行时索引（不是 L1 语法）
root
├─ insureds
│  └─ [Scope Slot]
│     ├─ age         → 当前项保费 Reaction
│     ├─ premium     → 汇总相关观察
│     └─ beneficiaries / [Nested Scope Slot] / name → View 观察
└─ product / code    → 清空附加保障的 Reaction
另有集合 / 长度 / 顺序等结构观察描述，编码仍待固化。
```

| 修改 | 查找候选 | 随后比较 / 处理 |
| --- | --- | --- |
| set /insureds/0/age | 精确路径和相关祖先观察者 | 根据前后值与绑定实例决定失效 |
| set /insureds/0 为对象 | 该节点下已经登记的观察子树及祖先观察者 | 比较已有观察路径，不深遍历全部导入数据字段 |
| move /insureds | 集合 / 位置候选与相关 Scope 关系 | 相对实例观察按同一身份读取，避免无变化的全实例比较 |
| set /insureds 为数组 | 受影响子树、绝对位置与结构观察 | 结合旧实例销毁、新实例激活与存活观察比较 |

推荐 Trie 的典型成本为插入约 O(depth)、精确查找约 O(depth + matches)；父对象替换需遍历命中的观察子树，成本随相关订阅数量增长，不宣称每次操作恒定时间。深层数组、Move、高层对象少量 Watch 与海量子路径 Watch 都需实测；模板实例化、反查和解析缓存的准确数据结构在实现阶段决定。

来源的 `insureds/length`、通配符与相对路径均是说明性索引 / Authoring 示意，不能当成新增合法 L1 JSON Pointer。成员序号、长度、顺序的观察须用正式支持的集合 / 位置语义表达，具体结构观察编码继续固化。

## Scope Index：相对位置与同一逻辑实例 {#l3-scope-index}

ScopeId 稳定，位置由 Scope Registry / Scope Index 统一拥有。已确认的存储原则是父 Scope + 相对集合位置 + 本层位置，完整绝对路径按需向上解析；父级移动只改当前集合相关直接成员的位置，不重写整棵后代绝对路径。

```typescript
// 信息需求草图，不冻结权威顺序表与辅助 index 的具体编码。
interface ScopeEntry {
  id: ScopeId;
  parentScopeId: ScopeId;
  collectionPath: PathSegment[];
  index: number;
}
```

```text
A：parent=root，collection=insureds，index=0
B：parent=root，collection=insureds，index=1
X：parent=A，collection=beneficiaries，index=0
Y：parent=A，collection=beneficiaries，index=1
X 的绝对路径 = /insureds/<A.index>/beneficiaries/<X.index>
A 移动后 X / Y 的父关系和相对位置不变。
```

Scope Index 存事实，Dependency Index 查逻辑字段的观察者，两者不合并为一套永久物理路径订阅。可维护 collection → ScopeId[] 快速反查；若 Entry 同时保留 index，须确定一个权威来源，另一个作为派生辅助索引，由同一结构 Command 维护一致。

| 观察意图 | Move A / B 前后读取什么 | 年龄 A=25、B=30 时 |
| --- | --- | --- |
| Scope A 的相对 age | before / after 都沿 Scope A 读取 | 25→25，相对年龄不失效 |
| 固定 /insureds/0/age | 同一物理位置，可能从 A 切到 B | 25→30，失效；若恰好同值仍需按值比较 |
| 整个 /insureds 或顺序 | 数组引用 / 明确结构观察 | 顺序改变，影响相应观察者 |

身份与位置分离是确认原则；位置型与相对型 Watch 的具体匹配方案、跳过无变化实例的优化仍为推荐 / 验证工作。依赖成员序号的业务不能只 watch 相对 age，需明确位置或集合变化意图。L4 行组件绑定 ScopeId，Host 也可选择观察固定位置，两者都使用共同 Scope Resolver，无需自己重写移动后的物理订阅。

## 临时 ReadState：旧 Scope 位置也必须可读 {#l3-scope-read-state}

不可变 previousRoot 保住旧 Data，并不会自动保住原地修改的 Scope Registry 旧位置。结构 Command 需同时取得稳定旧绑定，才能让相对观察在两个状态中指向同一个实例。只存“同一个可变 Registry 的引用”不满足要求。

```typescript
interface ReadState {
  dataRoot: DataRoot;
  scopes: ScopeReadView;
}
interface ChangeContext {
  before: ReadState;
  after: ReadState;
  impact: ChangeImpact;
}
```

推荐先保留本次受影响集合的旧 ScopeId 顺序 / 位置视图，或使用轻量版本读取；不为了对称强制全量复制或不可变化整个 Registry。嵌套后代的旧绝对路径由旧父位置递归组合，必要时缓存本次解析。具体局部视图保存形式是实现验证项。

提交一致的 Data / Scope → 定位候选并在 before / after 读取 → 投递 ObserverId / ReactionInstanceId → 释放 ChangeContext。旧位置不放入 Pending，不随联动传播 ScopeChange。Reaction 最终执行只根据 ScopeId 读取当时最新位置与 Data；Trace 可保留 ChangeId，不借此延长整个 ReadState 生命周期。

## 数组操作、生命周期与统一订阅 {#l3-array-lifecycle}

| 操作 | Data / Scope | 已有相对观察 | 固定位置 / 集合观察 | 首次激活 |
| --- | --- | --- | --- | --- |
| array.insert | 新建 Scope，调整同层位置 | 存活成员同值可跳过 | 按位置 / 长度 / 集合变化比较 | 新成员按策略 |
| array.move | 身份保留，调整同层顺序 | 非位置型内部字段同值可跳过 | 顺序 / 位置观察按值或结构语义处理 | 不重新激活存活项 |
| array.remove | 销毁被删 Scope，存活项保留身份 | 存活成员同值可跳过；删项任务取消 | 受影响位置 / 长度比较 | 不适用 |
| set 现有成员对象 | 保留该行身份，嵌套结构另行处理 | Trie 命中的子字段逐一比较 | 父对象引用可能变化 | 通常不重激活该成员 |
| set 整个数组 | 推荐重建成员 Scope | 新实例无旧观察基准，按生命周期处理 | 集合与固定位置照常比较 | 新成员按策略 |

整数组替换默认重建是推荐，尚未冻结；没有稳定业务 Key 时不根据姓名或内容猜身份。未来按稳定 Key 协调是可选扩展，不预设为系统必需。嵌套集合替换、首次激活与草稿数据的组合仍需验收，不能把推荐策略当成已实现保证。

存活观察者比较前后值，删除和新建实例走生命周期：释放旧订阅 / 规则 / 外部结果适用性，按编译策略激活新实例。不能把不存在的旧实例当成普通旧值，也不能漏掉新建成员首次入队。生命周期安排不代替既有 Validation / View / Host 的各自完成语义。

| 消费者 | 共用的数据匹配基础 | 匹配后的行为 |
| --- | --- | --- |
| Reaction | Prepared Watch、路径索引、Scope Resolver、前后观察值 | 合并 pending，在 Flush 中执行 |
| Constraint / Validation | 相应数据依赖与 Scope | 使结果失效并去重登记校验 Pending；正常联动收敛后按本轮链执行，外部请求时机另按策略 |
| 已挂载 View | 订阅的 Data 路径 / Scope | 通知重读，由 L4 决定呈现节奏 |
| Host 数据观察 | 明确路径或 Scope 的数据订阅 | 通知读取当前数据，不需知道修改来自哪条规则 |
| Reaction 执行 / Flush 中止 / Error 事件 | **不进入 Data Trie** | 通过独立执行事件观察或 Trace 消费 |

统一的是数据依赖查找、比较与 Scope 解析，不是让全部消费者进入 Reaction Queue。执行事件 API 仍需固化；它与 `host.emit` 业务事件也不能仅因都称“事件”就混成同一协议域。同步通知重入与订阅释放交接仍按原有未决契约验收。

## 多 Command 轨迹与执行骨架 {#l3-command-sequence}

```text
起始：index0=A(age25)，index1=B(age30)
同一 Operation：
  Command 1：set /insureds/0/age=26 → Change #1，使保费@A 入队
  Command 2：move 0→1 → A/B 位置互换，相对 age 不失效
  Command 3：set /insureds/1/age=28 → Change #3，再次命中保费@A
Pending：保费@A 仍一份，triggeredBy 可包含 [#1,#3]
Flush：执行一次，通过 A 当前绑定读取 age28
```

Command 2 仍可能影响固定位置和集合观察者，不能因为相对年龄不变就把 Move 判为没有变化。每条 Command 立即写入并检测，后续命令读取前一步最新位置；可隔离错误不阻断独立行为。该轨迹不是原子事务，也不积累三份 ScopeChange 等到 Flush 再分析。

```text
executeCommand(preparedCommand):                  // 概念骨架，不是生产算法
  capture beforeRoot + affected old ScopeReadView
  apply immutable update and consistent Scope change
  commit Data + Scope together
  find candidate observers from local impact + dependency index
  for each observer alive in both before and after:
    read the same logical target in each ReadState
    if observed values differ: invalidate(observer, changeId)
  dispose removed Scope instances; activate created instances by policy
  release temporary before / ChangeContext

invalidate(observer, changeId):
  reaction   → enqueue or merge instance + source ChangeId
  validation → invalidate the rule instance result
  data view / host subscriber → mark notification pending
execution events → use the separate execution observer interface
```

源码附件的伪代码有 `result.changed` 早退；实现时必须确保它涵盖相关结构 / 生命周期变化，不能把“某个 Watch 同值”当成整次 Command 无效而跳过 Scope 处理。旧视图稳定性、Data / Scope 一致发布、生命周期与通知交接、模板索引维护都需实际验证。骨架不提前冻结回调顺序、重入算法、Scope 视图物理表示或正式 API。

## Flush 生命周期与外部操作归属 {#l3-flush}

```diagram
{
  "id":"figure-l3-flush",
  "title":"即时写入与一轮联动收敛",
  "rows":[
    [{"title":"Operation → Command","body":"同步更新不可变 Root 与 Scope；按有效变化匹配依赖"}],
    [{"title":"idle → scheduled","body":"首次出现 pending 后安排一次启动，并建立 Context 保存起点"}],
    [{"title":"flushing · 取出实例","body":"从 pending 移除，读取最新 Data，求值 when，按序执行 then","major":true}],
    [{"title":"当前轮继续","body":"内部有效修改追加失效；同实例执行后可再次入队"},{"title":"本轮结束 / 停止","body":"队列空或整轮预算停止；可隔离错误继续，真实结果与异常报告分别记录"}],
    [{"title":"释放本轮 Context","body":"正常不留生产完整历史；异常先向 Host 提取报告；Devtools 自行保存"}]
  ],
  "arrows":["↓","↓","↕","↓"],
  "note":"Flush 是联动调度边界，数据在每条 Command 时已经生效。可隔离错误继续，超限整体中止；精确排序、通知重入和中止后 Pending 仍待固化。"
}
```

V1 延迟一次启动，然后在同一同步执行过程消费任务直至结束；不实现时间切片。微任务可作为启动方式，但精确启动契约仍待固化。V0.5 确认首次 Reaction 入队、进入 scheduled 时建立临时 Context，保留首次有效变化及后续合并的来源，避免执行开始时才记录而丢失起因。

| 发生时机 | 数据 | Reaction 归属与状态 |
| --- | --- | --- |
| scheduled 期间多个 Operation | 每次同步生效 | 加入已安排轮次，合并同一 pending 实例 |
| Flush 内部 Reaction 发出 Command | 同步生效 | 新失效加入当前轮，不为 A → B → C 各开一轮 |
| 前轮结束后 Host 异步返回 | 同步生效 | 新失效安排下一轮，计数独立 |
| 同步 Flush 中外部回调重入 dispatch | 同步生效 | 推荐加入当前轮并记 hadExternalReentry；策略仍待确认 |
| 外部修改未命中 Reaction | 同步生效 | 无需安排 Reaction Flush；Validation / View 仍按自身契约响应 |

同一 JS 主线程的普通输入事件或 Promise 回调不能插入已经开始的同步 Flush 调用栈。同步订阅回调、外部注册代码的重入是另一种情况：通知链需要独立保护，不能只靠 Reaction 执行次数兜底。外部重入不重置本轮计数；此时队列能否清空仍可判断，但报告不能轻率归因为纯内部循环。

## Reaction 合并、重入队与执行顺序 {#l3-reactions}

Reaction 是最新状态驱动的收敛行为。年龄和产品在执行前各变化一次，同一个保费实例只保留一份 pending，执行时读取最终年龄与产品；追踪保留两条失效来源。需要每次点击都新增一条记录的业务，使用明确 Command / Host 事件表达，不依赖 Reaction 的触发计数。

```text
invalidate(instance, change):
  尚未 pending → 登记实例与触发来源
  已经 pending → 合并触发来源，不重复入队
takeNext():
  从 pending 取出并移除实例
  执行时读取最新状态
  执行后再被有效变化命中 → 允许重新入队
```

推荐按 PreparedForm 稳定规则顺序完成初始入队，执行中新增任务按首次登记顺序追加；重复失效不移动已排队实例。推荐当前 Reaction 不被新失效打断，完成当前 `then[]` 后再取下一项，避免规则嵌套调用。准确顺序和运行中再次失效细节仍是 R13 / R18 的待确认契约。

稳定顺序帮助复现，不能保证冲突写入的最终值与顺序无关。同目标覆盖、互相依赖、结构修改都需验收。`then` 允许 array.insert/remove/move，但配置必须符合状态收敛意图；无条件反复新增需诊断风险，不能据此假定每次触发均应完整保留为业务事件。

## 初始化、缺失与清空由业务规则表达 {#l3-missing-values}

V0.5 确认不新增通用 Reaction Ready 状态机。必须区分读取缺失 / 未初始化、null、空字符串、0 与 false，不能用统一 falsy 判断表示“未就绪”。Missing 的具体读取表示与准确 SDK 类型仍待固化；示意中的 undefined 不作为 JSON 数据值写入协议。

| 场景 | 业务规则需要表达什么 | 结果 |
| --- | --- | --- |
| 初始缺少 age | 用 when 或纯函数的显式空值契约跳过 / 返回 null | 不误调要求有效年龄的保费算法 |
| 用户后来清空 age | 若业务要求同步清空 premium，明确计算并写 null | 该有效 Change 正常影响其他依赖，不默认留旧保费 |
| when 不成立 | 不执行当前 then[] | 跳过本身不会撤销以前写过的值；需要清空应另行表达 |

```text
示意业务纯函数：
  age 为 Missing / null / 空字符串 → 返回 null
  否则 → 按明确的输入类型契约计算保费
Reaction 的 set 把返回值写入 premium，仍经过正常变化匹配。
```

首次激活策略可配置，由 L1 表达、L2 编译，仅在新 Reaction 实例建立时应用；字段默认值与 SDK 仍待固化。Reset 由 Host 生成普通 Command，没有 Watch 有效变化就不重跑已有实例；这取代旧的主动重算目标。空值处理仍由配置表达，L3 不补 watch 或修复派生值；详见 [初始化与 Host 业务基准](#l3-initialization-baseline)。

## 四种执行轨迹 {#l3-traces}

以下是逻辑演示，字母为规则实例，数值为解释用途，不是运行算法或真实性能数据。

| 场景 | 步骤 | 可观察结论 |
| --- | --- | --- |
| 正常级联 | Operation 写 age=25 → pending A；Flush #1 中 A 写 premium=150 → B；B 写 totalPremium=150 → C；C 无有效修改 | 全部在 #1；队列清空，正常释放 Context |
| 多次输入合并 | scheduled 时 Operation #1 写 age=21 使 A 入队；#2 写 product=PLUS 再命中 A；A 执行一次读取最终二者 | 同一 pending，多对一 triggeredBy 来源 |
| 往复震荡 | A 将 age 17→18 使 B 入队；B 将 18→17 再使 A 入队，持续有效变化 | pending 去重不能阻止循环；整个 Flush 达到预算后停止，保留已写 Data 并报告 |
| 同步外部重入 | Flush #4 中 A 写 premium；通知回调由 Host 同步写 discount；新失效使 B 入队 | 推荐归当前轮并标记外部干预；通知有界策略待决策 |

同规则的 `A#1 → B#1 → A#2` 是三次独立执行，需要各自 executionId；不能把 A 的所有执行折叠成一条运行记录。

## 静态风险与运行时有限执行 {#l3-protection}

| 机制 | 发现 / 保护什么 | 取舍与状态 |
| --- | --- | --- |
| 同值短路 | 相同观察值反复写入 | 基本保护；推荐 Object.is / 存在性比较，不默认全表深比较 |
| 同实例 pending 去重 | 执行前的重复失效 | 必须；不解决执行后的往复循环 |
| 本轮总执行数 + 单实例次数 | 无界传播与局部重复 | 必须；计数低成本，具体阈值待标定 |
| 执行边界耗时检查 | 过慢轮次 | 可以报告并阻止继续调度；不能强制抢占正在执行的同步函数 |
| L2 Watch / Write 图与 SCC | 潜在规则环链 | 推荐；Tarjan / Kosaraju 可用，风险默认 Warning，不能禁止所有环 |
| 每步全量 Data Hash | 重复数据状态 | 不做默认判环；单次 O(S)，K 次为 O(K×S)，也漏掉无限增长 |
| Runtime 执行图与 SCC | 实际反复触发的规则集合 | 不进入默认热路径；留给 Devtools / 高级诊断 |
| 局部指纹 / Merkle 式 Hash | 局部往复状态 | 延期；需要完备读取、Scope 和状态信息 |

重复 Data 不等于重复完整执行状态，图中有环也不等于一定不终止。V1 目标是提前提示风险、限制执行、解释异常，无法对任意函数与修改组合通用证明终止。正常多轮收敛不用报错；已删除 Scope 的过期待执行任务正常取消。

早期本地 Node 的毫秒数不能成为 Web / Flutter 的性能预算。全表 Hash 的复杂度随数据字节数 S 增长；轻量记录成本主要随执行事件数、实际变化与额外复制参数量增长。具体常数须用大型数组、高频输入及目标平台 benchmark 标定。

## Command 错误隔离与整体 Flush 熔断 {#l3-errors}

| 现象 | 当前约束 | 尚需固化 |
| --- | --- | --- |
| 合法多轮收敛 | 正常结束，不持久上报完整轨迹 | 不将次数多直接判错 |
| 疑似往复写入 / 持续覆盖 | 如实记录实际是否收敛，可报告异常模式 | 分类、阈值与上报限频 |
| Function / Command 可隔离错误 | 记录并报告，不回滚其他成功修改；后续独立 Command 继续尝试，其他 Reaction 按实际 Change 响应 | 错误类型、诊断、门控求值失败等具体继续条件与 API |
| 单实例 / 本轮执行数超限 | 中止整个当前 Flush，不做局部链路熔断 | 剩余 Pending 的清理 / 保留与后续再触发入口 |
| 耗时异常 | 执行边界判断并报告，无法抢占正在执行的同步函数 | 阈值和边界处理 |
| Scope 已删除 | 正常取消过期实例任务，回收关联 | 不作为业务错误上报 |

Reaction 没有执行控制意义的父子关系：A 修改数据使 B 失效，B 不检查 A 的成功状态，只检查自身 Scope、watch 与运行条件。某条命令失败，不自动禁用“下游”，不回滚其他成功修改；后续命令依次读取执行时的最新数据。可隔离错误与预算超限分别处理，安全预算到达时终止整轮，不能把“继续独立行为”理解成忽略保护。

整体停止的最小约束：保留已写 Data；不把停止伪装为正常收敛；清理 Context 前提取真实错误 / 超限类型与临时路径，交给 Host 报告；不自动无限重启同一批遗留任务。具体 Pending 处理及再触发仍待确认。

V0.4 曾保留“局部不可信范围、长期 Health、相关规则恢复后清除标记、利用依赖计划传播影响”的候选，V0.5 为降低状态机与影响链成本明确替代该方向：不做父子 Reaction 状态、失败下游禁用、局部熔断或链级恢复。解释异常的 Trace 不参与调度和权限决策；Validation 的 Issues / 新鲜度仍按自身契约管理。旧约束完整留在 [整合前正文](../history/README.md#protocol-runtime-v05-integration)。

## Trace：事实、来源与记录边界 {#l3-trace}

Runtime 记录有序执行事实与实际变化，Devtools / 离线平台重建因果关系。记录应能表达 Operation 来源、Reaction / Scope、执行顺序、状态和产生的有序修改，`triggeredBy[]` 支持多个变化合并触发一次执行。

```text
Operation #1 → Change #11：age 20→17
Operation #2 → Change #12：product BASIC→PLUS
Reaction A · Execution #13 · triggeredBy [#11,#12]
  → Change #14：premium 100→150
Reaction B · Execution #15 · triggeredBy [#14]
  → Change #16：discount 0→10%
Reaction A · Execution #17 · triggeredBy [#16]
```

| 信息 | 用途 | 限制 |
| --- | --- | --- |
| executionId | 区分同一实例在本轮的多次执行 | 不等于 L1 Reaction ID |
| changeId | 定位 Command 造成的真实变化 | 无变化调用可记录执行事实，不伪造有效 Change |
| triggeredBy | 标识使本次执行失效的变化 | 表示调度原因，不证明每项都是业务计算的必要条件 |
| dataVersion | 标识读取的工作状态版本及变化前后版本 | 版本号本身不保存历史值 |
| Scope / Path / op | 解释实际对象与修改位置 | Scope 稳定身份与当时路径需分别说明 |

概念级结构如下；字段、ID 空间、操作与变化粒度、失败 / 无变化的编码继续固化，不直接发布成正式 TS 包：

```typescript
interface ExecutionRecord {
  id: number;
  kind: 'operation' | 'reaction';
  name: string;
  scopeId?: string;
  triggeredBy?: ChangeId[];
  changes: DataChangeRecord[];
  status: 'success' | 'error';
}
interface DataChangeRecord {
  id: ChangeId;
  target: { scopeId?: string; path: string };
  op: string;
  beforeVersion: number;
  afterVersion: number;
}
```

来源草图同时给变化记录放入 `changed` 标志；本篇将有效变化与无变化 Command 事实分开说明，保留其信息需求，不冻结两套并行变化模型。首个失效之前的 Operation / Change 必须能在建立 Context 时被关联，具体采集方式待定。

V0.5 继续要求记录预算内的 Operation、Reaction 与 Command 结果。可隔离错误后仍可能有成功修改，因此记录应能区分失败命令、无变化尝试与后续实际 Change，不能只用整条 Reaction 的 success / error 推断每条命令的结果。具体事件粒度与字段仍待固化；这些状态只用于诊断，不用来禁用其他规则。推荐 Prepared Source Map 关联原始 L1 的身份、版本和位置，便于由报告回查配置，详见 [编译来源](l2-preparation.md#l2-authoring-diagnostics)。

## 记录预算、参数与异常上报 {#l3-trace-budget}

执行预算与记录预算独立：前者停止无限联动，后者限制事件条数及字节数。Trace 满了可停止详细采集或截断，但计数与循环保护必须继续。合并来源、参数副本等附属记录也需计入容量，不能通过大 `triggeredBy` 绕过记录预算。

推荐在正常容量内保留完整本轮，溢出时保留初始来源与最近一段，并标记 `truncated`；仅保留尾部是替代方案，最终策略仍待决策。截断造成的缺失引用必须如实表达，不能伪造完整因果链。

| 对象 | 生产临时 Trace 方向 | Devtools 可选扩展 |
| --- | --- | --- |
| Reaction / Scope、实际 Command 与目标 | 记录身份和事实 | 同一来源进一步展示 |
| when 结果 / Pure Function ID | 必要的少量元数据 | 更细的求值过程 |
| 标量业务参数 | 脱敏值、受限摘要或不留原值，策略待定 | 在明确授权范围扩展 |
| 大对象 / 数组参数 | 类型、大小、摘要，避免逐步深拷贝 | 受限稳定副本或检查点 |
| Working Data 全量 Snapshot | 不逐步复制 | 历史恢复属于延期能力 |

保存可变 Context / 外部对象引用不能证明历史参数；需要审计时必须明确受限副本或摘要形成的时点。正常结束释放生产完整记录，异常先提取报告；Devtools 可自行长期保留。异常报告至少应定位 Definition / 发布身份、Reaction / Scope / Path、轮次结果、保护原因及截断信息，具体字段、脱敏映射和限频待固化。注册能力、Runtime 和平台的版本信息也影响可解释范围。

报告交给 Host / 配置平台去重、限频，不能成为正常 Data 写入的等待或许可条件；Devtools 的历史保存与事件消费 API 在实现阶段确定。临时记录从首次入队建立到本轮结束释放，不以异常为由给生产 Runtime 增加所有正常轮次的长期历史。

## Devtools 因果分析与复现的三种层次 {#l3-devtools}

事后先扫描 changes 建立 `changeId → executionId` 索引，再扫描 triggeredBy 连边。记录完整时，成本随执行数、变化数和引用数线性增长；Runtime 无需实时维护父子树或运行 Tarjan。以执行实例为节点按时间向前连边，以 Reaction Instance 折叠展示时才可能出现 A ↔ B。

| 能力 | V1 边界 | 额外条件 |
| --- | --- | --- |
| 复原执行顺序和触发链 | 推荐支持；受截断范围限制 | 有序记录与 Change 关联 |
| 复原历史 Data 值 | 暂不承诺 | 初始 Data + 可重放的实际修改日志 + 数组 / Scope 恢复信息 |
| 确定性重新执行 | 暂不承诺 | Definition / Prepared / Function 版本、初始 Data / Context、外部输入、非确定性来源与环境约束 |

异常可定位不等于时间旅行。Devtools 关闭也必须得到同样的 Reaction 输出与调度结果。

## Validation、Renderer 与 Submit 的边界 {#l3-consumers}

共用匹配不等于共用完成条件。Reaction Flush 处理同步联动收敛，不等待所有外部校验或 UI 绘制。

| 消费者 | 失效时 | 执行 / 完成时 |
| --- | --- | --- |
| Reaction | 合并 pending 与来源 | 读取最新 Data；有效写入归当前轮 |
| Root Schema | 有效 Data Change 登记待校验标记 | 正常联动收敛后完整根校验一次，不自动拆成 Keyword 单元 |
| Internal Validation | 旧结论失效，实例 ID 去重入校验 Pending | 执行本轮前置整理后的 Constraint；按来源替换、字段聚合 |
| External Validation | 旧结论失效，撤销过期来源 Issue；取消由 Host 负责 | 请求时机按策略；返回成功 / 异常都核对请求、Scope、实例与输入有效性 |
| Renderer | 获知最新状态变化 | 读取 Data / Props 与字段 Issue 聚合，不要求消费同步校验的每个中间状态 |
| Submit | 显式完整校验覆盖全部适用约束，另核对所需联动与输出 | 无 Issue 不等于完备；异常 / 中止的准确交接仍待定 |

V0.7 已明确正常路径：共享依赖匹配登记校验 Pending，Reaction 收敛后执行完整根 Schema 与本轮 Constraint 链，结果按 Source 保存、字段聚合。没有 Reaction 时校验也有独立入口；初始化 / 主动完整校验不能等待第一次修改。本轮前置缺失的严格跳过倾向、requires 语法与完整返回仍需验证，不自动补齐前置，不引入前置结果 PubSub。

完整校验需区分当前通过、业务失败、不完备与过期，核对必要外部义务、当前输入与输出。可隔离错误或整体熔断后是否继续校验、Outcome 和提交如何交接仍待固化。V0.4 的按局部受损范围 / Health 传播决定提交方案已退出，不引入失败下游禁用；实际提交、权限和风控归 Host。完整职责、推荐存储、异步与 V01–V16 设计验收见 [L3 校验专题](l3-validation.md)。

微任务启动 Flush 可能仍发生在浏览器绘制前，耗时同步纯函数会阻塞主线程，这是 V1 接受的简化取舍。未来可以替换 Scheduler，但需保持数据写入、收敛、身份及异常契约。

## 跨层修订、替代方案与取舍 {#l3-impact}

| 层 / 早期候选 | 现行处理 | 保留理由与影响 |
| --- | --- | --- |
| L3 可变 JSON + 按需 Snapshot | 不可变 Working Data + 结构共享 | 稳定旧快照；更新算法保留优化空间 |
| batch 候选树统一提交 / 回滚 | 逐 Command 有序即时生效，不默认整体回滚 | 输入反馈与状态语义；通知合并独立处理 |
| Reaction 每次失效均独立执行 | 最新状态收敛、pending 去重 | 状态联动与事件记账分离；L1 同步说明 |
| Operation 包含完整联动事务 | 仅记录外部来源，多个 Operation 可共用 Flush | 调度轮次独立于修改来源 |
| 同步 / 全延迟 / 混合 / 分段调度候选 | V1 延迟启动、同步消费到结束 | 保持简单，可替换入口，暂不做 Fiber 式优先级 |
| 每步 Hash / 热路径完整因果图 | 同值短路、次数预算、轻量有序 Trace | 降低热路径成本；静态风险和离线解释分工 |
| 最近 N 条或长期生产历史 | 临时轮次记录；预算与截断待定；异常提取报告 | 保留起点有助定位，同时控制内存与复制成本 |
| L2 Read / Watch 分离 | 保持；推荐 Watch / Write SCC 风险诊断 | Write 不改变 Reaction 触发逻辑 |
| L1 then 中数组操作 | 保留，但需符合收敛意图并提示非幂等风险 | 显式 Command 次数不合并，Reaction 不承诺每次触发次数 |
| 原始 L1 与 Prepared 可双轨执行 | Runtime 只消费兼容 PreparedForm | 统一诊断、依赖计划与能力绑定，避免静默解释回退 |
| 普通错误一律停后续 / 局部 Health 传播 | 单 Command 可隔离错误继续独立行为；超限整体熔断 | 不检查上游成功，不做局部影响链与恢复状态 |
| 缺失输入靠通用 Reaction Ready | 业务 when / Pure Function 明确空值语义 | 区分初始缺失与清空；V0.6 已确认首次激活显式可配置，默认值待固化 |
| Scope / Validation / L4 | 保持稳定身份、校验所有权与新鲜度、按挂载订阅 | Trace 也按稳定 Scope 定位；Runtime 不控制 UI 帧与 Loading |

不默认整体回滚、逐步全表快照、运行时因果图或复杂调度，是具体成本与表单状态语义之间的选择。V0.5 进一步用单 Command 可隔离错误与整轮预算边界替代父子执行控制、局部熔断和不可信影响范围传播；Trace 仅诊断，不作为调度或权限门控。旧候选与整合前全文见 [V0.4 来源](../history/README.md#l3-integration) 及 [V0.5 整合归档](../history/README.md#protocol-runtime-v05-integration)。

## 决策总账 {#l3-decisions}

以下沿用 V0.4 的 R01–R26 稳定编号，受 V0.5 影响的行标明当前修订及原状态；未受影响项保留。“推荐”不是已经冻结，“待实现标定”也不是实现完成。完整 V0.4 原始状态在来源包中保留，V0.5 的独立 D01–D22 见 [跨层总账](dependency-reactivity.md#dependency-v05-decisions)。

| 编号 | 决策 | 状态 | 说明 / 所属层 |
| --- | --- | --- | --- |
| R01 | Working Data 不可变 + 结构共享 | 已确认 | 旧 Snapshot 稳定；每条有效 Command 可发布新 Root；L3 Data |
| R02 | 单个有效 Command 同步生效 | 已确认 | 业务合法性由 Validation 判断；结构操作保持内部一致性；L3 Data |
| R03 | 默认 Batch 非原子事务 | 已确认 | 子 Command 有序实时写入，不默认回滚前序成功修改；L1 / L3 |
| R04 | Reaction 是最新状态收敛行为 | 已确认 | 不依赖触发次数；同一待执行实例可以合并；L1 / L3 |
| R05 | 内部 Reaction 写入属于当前 Flush | 已确认 | 不为每条联动创建新 Flush；执行后可重新入队；L3 Reactive Engine |
| R06 | V1 延迟启动、同步执行到结束 | 已确认 | 不做分段调度/时间切片；L3 Scheduler |
| R07 | Operation 是来源，不是隔离事务 | 已确认 | 多个 Operation 可影响同一个 Flush；L3 |
| R08 | Trace 为顺序行为记录 + Change 来源 | 已确认 | 不构建运行时因果图；Devtools 事后分析；Diagnostics |
| R09 | 正常 Flush 不持久上报 | 已确认 | 执行结束后释放临时 Context；异常才提取报告；Diagnostics |
| R10 | Devtools 可观察完整执行 | 已确认方向 | 启用时由 Devtools 自行保存历史，不能改变执行语义；Devtools |
| R11 | L2 做 Watch/Write 图与潜在环诊断 | 推荐 | 静态 SCC 可辅助定位，但不禁止所有成环规则；L2 |
| R12 | Flush Context 自首次入队建立 | 已确认 · V0.5 | 原为推荐；当前确认保留 scheduled 初始来源与合并原因；L3 |
| R13 | 执行时使用稳定顺序与去重队列 | 推荐 | 稳定规则排序 + 首次入队顺序，具体语义需再确认；L3 |
| R14 | 超限熔断整个本轮 Flush | 已确认 · V0.5 | 原为推荐；统一整轮预算，不做局部熔断影响链；L3 |
| R15 | 可隔离 Command / Function 错误继续独立行为 | 已确认 · V0.5 | 原为待决策；记录错误，后续独立命令与规则继续；精确类型和接口待固化；L3 |
| R16 | 整体熔断后的 Pending 与再触发 | 待确认 · V0.5 | 不回滚、不无限自动重启；原局部影响范围 / 链级恢复被替代，具体队列处理待定；L3 |
| R17 | 同步订阅重入时的递归通知保护 | 待决策 | Data 同步写入不变；通知交付需要有界处理；L3 / L4 |
| R18 | 单次 Flush 的启动与执行排序细节 | 待决策 | 运行中被再次失效、同层/跨层写入冲突如何排序？；L3 |
| R19 | Trace 预算溢出策略 | 待决策 | 完整到上限后保留头尾并标注截断，还是仅尾部？；Diagnostics |
| R20 | 详细参数记录的边界 | 待决策 | 实际值/摘要/大小/类型、敏感数据与稳定拷贝；Diagnostics |
| R21 | 异常检测阈值与重复上报限频 | 待实现标定 | 单实例和总次数硬限制、耗时统计、告警聚合；L3 / Host |
| R22 | Validation / Submit 完成边界 | V0.7 正常路径方向收敛；异常交接待定 | 正常联动后本轮校验 / 完整校验分开；无 Issue 不等于通过。缺失前置、准确返回及异常 / 熔断如何交接继续待定；不恢复局部 Health |
| R23 | 确定性 Replay、历史 Snapshot | 延期 | 先保证执行链说明；需要时再引入检查点与重放数据；Devtools |
| R24 | 全量 Hash、局部 Hash、完整因果图 | 延期 | 仅高级诊断/开发分析有明确需求时再实现；L2 / Devtools |
| R25 | 复杂分段调度 / 优先级 | 延期 | 先做可替换调度入口，V1 不实现 Fiber；L3 |
| R26 | 新实例首次激活与 Host 业务状态边界 | 已确认 · 后续用户修订 | 新实例按 runOnActivate；业务 Baseline / Dirty / Reset 归 Host；不因恢复意图重跑已有实例。取代 V0.6 自动基准与主动重算，字段默认值 / SDK 待固化 |

## 设计验收与下一步 {#l3-acceptance}

| 用例 | 场景 | 输入 / 过程 | 必须观察到 |
| --- | --- | --- | --- |
| C01 | 单步输入 | set age=25 后立即读取 | 返回 25，不等待 Flush |
| C02 | 多次合并 | 启动前两次修改 A 的 watch | A 仅一份 pending，执行读最终值 |
| C03 | 链式写入 | A 写 premium，B 观察 premium | B 进入当前 Flush |
| C04 | 重复失效 | A 执行后 C 再改其 watch | A 可重新入队，保留新来源 |
| C05 | 同值短路 | A set 与当前原始值相同 | 无有效 Change，不继续触发 |
| C06 | 动态数组移动 | B 从 index1 移到 index0 | Scope B 稳定；订阅与 Trace 不串项 |
| C07 | 业务校验失败 | 输入超范围年龄 | Data 接受，Validation 产生 Issue |
| C08 | 简单自环收敛 | age16→A 设置18，再执行无修改 | 正常结束，无错误上报 |
| C09 | 往复震荡 | A→B→A 持续有效变化 | 达到预算停止并生成定位报告 |
| C10 | 合并来源 | 两个 Change 命中待执行 A | A 的一次执行关联两个 Change ID |
| C11 | 多次规则执行 | A#1→B#1→A#2 | 独立 executionId，可还原链条 |
| C12 | 正常清理 | 正常 Flush 完成 | 生产 Runtime 不保留完整 Trace 历史 |
| C13 | 异常上报 | 熔断后提取报告 | 定位 Definition 版本、Reaction / Scope / Path 和截断 |
| C14 | 记录预算满 | Trace 先于执行保护达到上限 | 停止详细采集 / 截断，保护仍工作 |
| C15 | 异步 Host 操作 | 前轮结束后 Host 写入 | 新轮次，不复用旧执行计数 |
| C16 | 同步重入 | 通知回调再次同步 dispatch | Data 即时更新，通知不会无限递归；策略待定 |
| C17 | 整体熔断后再触发 · V0.5 修订 | 本轮中止后又出现外部修改 | 不自动无限重启遗留任务，不回滚已写 Data；Pending / 再触发契约待补，不再断言局部 Health 标记 |
| C18 | Devtools 关闭 | 开关 Devtools 运行同表单 | Reaction 输出和调度语义一致 |

这些是未来 Runtime 的设计验收，当前候选协议检查与有界探针不实现真实 Flush / Trace / 整体熔断，不能将其通过计数当成本表已经通过。C17 按 V0.5 替代原局部 Health 要求，旧行在归档保留；C16、C17 需补准确契约。新增的 Command 隔离、初始化空值和 Prepared 拒绝回退见 [V0.5 的 12 个跨层场景](dependency-reactivity.md#dependency-v05-acceptance)。

下一步以 [逐 Command 数据 / Scope 检测的 16 个场景](#l3-v06-acceptance) 与 [现行边界验收](#l3-runtime-host-boundary) 验证稳定快照、新实例激活、已有实例同值不重跑、普通恢复 Command、替换 / Dispose、通知重入与精确排序。整体熔断后 Pending / 再触发以及异常轮次的 Validation / Submit 衔接继续补齐；正常路径已纳入 [校验专题](l3-validation.md#validation-completeness)。随后固化 Trace / 参数 / 错误接口，以动态数组与高频输入标定预算。可隔离错误继续与整轮熔断不再重开为局部传播设计。正式类型、Schema、Prepared ABI、Runtime 与适配器按落地任务建立，不将本篇概念结构当成生产发布包。

## V0.6 数据变更与 Scope 决策总账 {#l3-v06-decisions}

以下保留来源 D01–D25 的编号、标题、说明与状态，属于 V0.6 命名空间，与 V0.5 的 D01–D22 及本篇 R 编号分别识别。来源正文的“已收敛具体结论”不提升决策表中的推荐项；尤其 Object.is、Trie 组合、临时 ScopeReadView、整数组重建与位置型匹配仍为推荐。 **来源状态是当时记录，现行处理以最后一列和本次用户修订为准**；D07 / D08 的核心职责已撤回，D21 / D22 不再是 Runtime 待决项。

| 来源编号 | 决策 | 来源状态 | 来源说明 | 现行处理 |
| --- | --- | --- | --- | --- |
| D01 | 数据字段不需要所有权语义 | 已确认 | 用户、Host、Reaction 修改同一字段，Reactive Engine 对来源一视同仁。 | 沿用原有确认 / 推荐 / 验证状态 |
| D02 | 显式 Watch 由 L1 规定、L2 编译 | 已确认 | 运行时不自动补全业务触发意图；L2 可给配置诊断建议。 | 沿用原有确认 / 推荐 / 验证状态 |
| D03 | Command 实时更新 Working Data | 已确认 | 每条独立 Command 立即写入，后续 Command 读当前最新值。 | 沿用原有确认 / 推荐 / 验证状态 |
| D04 | 不可变结构共享的前后 Root | 已确认 | 当前 Command 比较之前/之后 Root，不需要完整周期快照。 | 沿用原有确认 / 推荐 / 验证状态 |
| D05 | 多 Command 逐条变化检测 | 已确认 | 不等待 Operation 或 Flush 结束才推导 Data Change。 | 沿用原有确认 / 推荐 / 验证状态 |
| D06 | Reaction Pending 去重并读最新态 | 已确认 | 多个变化同一待执行规则实例合并，执行后再次失效可以再入队。 | 沿用原有确认 / 推荐 / 验证状态 |
| D07 | Baseline 在初始 Reaction 正常收敛后建立 | 已确认 | 首次自动联动不直接制造 Dirty。 | 被替代：Runtime 不自动建业务 Baseline；Host 自选快照和时点 |
| D08 | Reset 按当前环境重新计算 | 已确认 | 目标确定，具体选择重算规则的入口另议。 | 被替代：Host 生成普通恢复 Command，无有效 Watch 变化不重跑已有实例 |
| D09 | 首次执行策略显式可配置 | 已确认 | 实例激活与实际第一次执行业务计算分离。 | 沿用并限定：仅新 Reaction 实例首次激活，不重跑已有实例 |
| D10 | ScopeId 与数组下标分离 | 已确认 | Move 时存活成员身份稳定，位置映射随数组操作变化。 | 沿用原有确认 / 推荐 / 验证状态 |
| D11 | Scope Index 存相对父级位置 | 已确认 | 完整绝对 Data Path 是按需解析结果，不是事实来源。 | 沿用原有确认 / 推荐 / 验证状态 |
| D12 | ScopeChange 不沿链路传播 | 已确认 | 局部变更比较后，只下发观察者失效或执行事件。 | 沿用原有确认 / 推荐 / 验证状态 |
| D13 | 不同消费者共用数据依赖匹配 | 已确认 | Reaction / Validation / View / Host 复用索引基础能力。 | 沿用原有确认 / 推荐 / 验证状态 |
| D14 | 执行事件与数据 Watch 分离 | 已确认 | Host 监听 Reaction execution / errors 不走 Data Trie。 | 沿用原有确认 / 推荐 / 验证状态 |
| D15 | 整体 Flush 是熔断边界 | 已确认 | 无局部链路熔断 / 失败传播 / 上游子任务健康模型。 | 沿用原有确认 / 推荐 / 验证状态 |
| D16 | 默认 Object.is 比较观察值 | 推荐 | 对象/数组按引用；必要时显式考虑路径存在性。 | 沿用原有确认 / 推荐 / 验证状态 |
| D17 | Trie 与编译期依赖模板结合 | 推荐 | L2 规范化，L3 按动态 Scope 绑定实例，避免全量扫描。 | 沿用原有确认 / 推荐 / 验证状态 |
| D18 | 临时前后 ScopeReadView | 推荐 | 结构变更前保留受影响局部旧位置，比较后释放。 | 沿用原有确认 / 推荐 / 验证状态 |
| D19 | 数组整替换默认重建成员 Scope | 推荐 | 不依据姓名或对象内容推断身份；稳定业务 Key 可扩展。 | 沿用原有确认 / 推荐 / 验证状态 |
| D20 | 位置型 Watch 与 Scope 相对 Watch 分别匹配 | 推荐 | 确保移动仅影响确实观察位置或集合的消费者。 | 沿用原有确认 / 推荐 / 验证状态 |
| D21 | Reset 的显式重算范围与调度入口 | 待讨论 | 在旧 Watch 不变化的场景下仍要达到当前环境收敛目标。 | 移出核心：无 Runtime Reset 重算入口，业务配置和恢复意图归 Host |
| D22 | Context 变化后的 Dirty 业务语义 | 待讨论 | Baseline 已确认，但是否只考虑用户业务输入尚未定。 | 移出核心：Dirty 由 Host 定义，不增加 Runtime 字段分类或编辑状态 |
| D23 | BeforeScopeView 的局部保存形式 | 实现验证 | 选择集合顺序切片或轻量版本化，不全量复制。 | 沿用原有确认 / 推荐 / 验证状态 |
| D24 | 对象引用约束与防御策略 | 实现验证 | Host 原地修改共享对象须受到约束或输入层隔离。 | 沿用原有确认 / 推荐 / 验证状态 |
| D25 | Trie 模板实例化的真实性能 | 实现验证 | 分别测试深层数组、集合 Move、大对象少量 Watch。 | 沿用原有确认 / 推荐 / 验证状态 |


## V0.6 端到端设计验收与实现边界 {#l3-v06-acceptance}

以下对应来源 01–16。它们是同一套 PreparedForm / Data / Scope / Dependency Index 的未来验收，包含推荐方案需证明的预期行为，不是现有候选验证通过结果。整数组默认重建仍为推荐，首次激活字段默认值仍待固化；15 / 16 场景已按后续用户修订更新，撤回 Runtime 业务基准 / Reset 重算要求。

| 来源场景 | 输入 / 过程 | 必须证明 |
| --- | --- | --- |
| 01 单字段同值 | set(age,25)，原值为25 | 不因同值产生数据失效通知或调度；独立执行事件另行处理 |
| 02 父对象替换、子字段同值 | /insured 换新引用，age仍25 | 子路径年龄观察跳过，整个对象引用观察可失效 |
| 03 父对象替换、被观察字段改变 | 新年龄30 | 索引命中子观察路径并登记年龄规则 |
| 04 未观察大对象字段修改 | 500个未观察字段变化 | 不扫描全部Reaction、不凭空触发未命中观察者 |
| 05 Move与稳定Scope | A及其嵌套受益人随父移动 | 身份保留；A相对age不因位置变化失效 |
| 06 Move与固定索引 | 观察/insureds/0/age | 按前后位置值比较，切换对象且值不同时失效 |
| 07 删除首项 | 删除A，B前移 | A销毁；B相对观察不被读成另一个人 |
| 08 嵌套受益人移动 | X在A内移动 | X身份保留，父集合顺序观察正确失效 |
| 09 整数组导入 | 按推荐重建策略替换数组 | 旧Scope释放、新Scope激活；位置与集合观察更新，草稿不被不明策略破坏 |
| 10 多Command命中同一实例 | set年龄→move→set年龄 | 逐条比较、pending去重，Trace保留多个ChangeId，执行读取最终数据 |
| 11 同步业务级联 | 内部Command产生新变化 | 可继续失效其他规则，同轮执行到收敛 |
| 12 整个Flush熔断 | 持续震荡 | 整体预算停止，不计算局部健康或影响链 |
| 13 View行绑定 | 行组件绑定ScopeId后数组移动 | 仍读取同一实例在新索引的数据，L4不重写物理订阅 |
| 14 Host执行事件 | 监听Reaction完成与数据变化 | 两类订阅分开，执行事件不进入Data Trie |
| 15 异步初始化 · 后续修订 | Host 加载数据后建立实例 | 新规则按 runOnActivate；Runtime 提供稳定 snapshot，Host 可自行选择时点保存业务 Baseline，Runtime 不自动建立 |
| 16 Host Reset · 后续修订 | Host 恢复数据，现存规则的 Watch 未变 | 只走普通 Command / 比较链路，不因 Reset 或费率期望重跑已有实例；新实例确实建立时才应用 runOnActivate |

实现前优先验证共享对象不可被外部原地修改、连续 Move / Remove / Insert 的旧位置视图、整数组重建与首次激活对草稿的组合影响；再明确存在性、位置型观察和解析缓存。分别测量深数组、频繁重排、大对象少量 Watch 与大量子路径 Watch 的索引成本，不预设全局依赖快照、无限版本链或沿联动传播 ScopeChange。

下一步可用这 16 个案例验证 Prepared Watch → 索引候选 → Data / Scope 前后值 → 观察者失效的闭环，再做性能基准；Validation 同步 / 异步失效、删除清理与完整校验已进入 [校验专题](l3-validation.md)，缺失前置、返回类型与异常 Submit 衔接仍待固化。业务 Reset / Dirty / Baseline 已划归 Host，不再作为 Runtime 的待讨论执行模式；不得由推荐索引实现倒推字段所有权、结果修复或自动 Watch。原始附件与整合前全文见 [V0.6 来源归档](../history/README.md#data-scope-v06-integration)。
