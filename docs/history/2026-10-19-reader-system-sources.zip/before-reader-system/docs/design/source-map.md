# 来源映射与知识覆盖

> id: SRC-FE-001 · type: source-map · status: 本地资料范围的来源索引与覆盖记录 · module: 全层 · tags: provenance, coverage, decisions, history · last_reviewed: 2026-10-19

本篇将原始资料、现行完整规范、ADR 和审查问题关联起来。[机器清单](../architecture-source-inventory.json)逐文件记录路径、角色、字节数、SHA-256 与章节，ZIP 内条目使用 `包路径::成员路径` 标识。该表示是检索标识，不伪造可直接点击的 ZIP 内 URL；下载包后按成员路径定位。摘要证明文件身份，不证明设计已实现。

这里的来源映射是文档证据索引；[Prepared Source Map](../CONTEXT.md)是编译产物回查原定义的候选诊断能力，二者不是同一个协议或实现。

## 原始结构、权威关系与覆盖范围 {#source-structure}

实际资料已经按现行主题与历史归档组织，不再另建 architecture/ 平行规范。用户建议体系对应：README→[维护入口](../README.md)及[整体架构](architecture.md)；Current Design→现有 `docs/design/`；Decisions→`docs/design/decisions/`；Design History→既有 `docs/history/`；Governance / Roadmap→[架构治理](governance.md)；Source Map→本篇及机器清单；Glossary→[CONTEXT](../CONTEXT.md)。只新建有实际内容的 ADR 目录。

| 资料层 | 范围与角色 | 本次处理 / 证据边界 |
| --- | --- | --- |
| 现行正文 | 整体架构、使用指南、L1 八主题及分组、L2、依赖、L3 执行、L3 校验、术语 | 保留完整细节、图示、代码和稳定锚点；补充权威阅读路径、ADR 与审查引用；不把未知补成已确认 |
| 历史早期设计 | 2026-10-14 架构 / 草案 / 抽象边界；六组原稿、同步稿、主台账、修订记录；V1 定稿副本 | 按主题核对主要取舍与替代链；原文件保留，所有可识别章节进入清单；旧规划 ADR 不改号 |
| 后续阶段来源 | L2 V0.1、依赖 V0.1、Flush V0.4、协议 V0.5、Scope V0.6、Host 边界摘录、校验 V0.7 | 核对范围、来源决策表、案例与关键转折；按主题 ADR 归因，保留原确认 / 推荐 / 待定状态 |
| 整合前快照 | 上述 ZIP 中 before-* 路径、术语统一前副本 | 原样归档并计算摘要；用于还原当时正文，不重复解释为新的一组现行结论 |
| 验证附件 | 原验证 ZIP、生成源、契约 Manifest、Fixture、报告、覆盖和说明 | 检查现有证据范围与声明；候选结构 / 有界探针不证明 Prepared / Scope / Flush / Validation / L4 实现 |
| 生成阅读视图 | `docs/reading/`、验证页面及历史入口 | 仅为同步检查读取生成结构；不反向提取设计约束，不单独维护规范 |

**覆盖声明：**完成本地现行主题的整理与交叉审查，建立本地历史文件及 ZIP 成员的完整可重复盘点，重要决策按下表定位。历史快照采用主题 / 替代链核对，未对每份重复快照的每句话重新作语义证明；代码 / 样本附件按其证据边界检查。因此不能称为“所有历史讨论逐句全量重写”或“生产设计 / 实现全量验收”。本地不存在的完整原始对话仍为来源缺口；后续新增资料必须增量核对。

## 来源编号与精确定位 {#source-register}

### SRC-EARLY：最初架构与抽象边界 {#src-early}

[2026-10-14 目录](../history/2026-10-14/README.md)保存完整层级、模型、依赖、事务 / Host 交互和详细设计路线。[术语统一前原始来源包](../history/2026-10-17-decision-sources.zip)内 `before-pure-function-terminology/2026-10-14/` 保存原字节。现行[整体架构](architecture.md)保留这些完整问题与图示，Resource / 通用执行器等旧候选的替代说明在[架构演进](architecture.md#decisions)。早期标题、原锚点和内容摘要身份见机器清单，不补造段落编号。

### SRC-L1：六组专题、定稿与包装修订 {#src-l1}

- [第一至三组](../history/2026-10-15-round-originals/README.md)：Data / Reference / Scope；Expression / Pure Function / Constraint；Behavior / Command / Reaction。
- [第四至六组](../history/2026-10-16-round-originals/README.md)：View / Profile / Material；Lifecycle / Validation / Submission；统一协议与组合验收。
- [定稿前同步稿](../history/2026-10-16-before-v1-final/README.md)、[10-15 修订](../history/2026-10-16-before-v1-final/changes-2026-10-15.md)、[10-16 集成](../history/2026-10-16-before-v1-final/changes-2026-10-16.md)、[当时一致性审查](../history/2026-10-16-before-v1-final/consistency-review-2026-10-16.md)。这些日志精确保留 B6、F1 / F2、外部义务及先后替代状态。
- [V1 定稿阅读副本](../history/2026-10-16-v1-final-original.html)及[原字节 ZIP](../history/2026-10-17-decision-sources.zip)内 `before-pure-function-terminology/2026-10-16-v1-final-original.html`；现行 L1 八主题承接其 32 节基线和后续修订。历史记录的初始下载摘要不等于站内阅读副本摘要，见[历史台账](../history/README.md#archive-5)。
- [Profile 去 entry 修订](../history/README.md#profile-revision)与[依赖迁移记录](../history/README.md#dependency-integration)承接候选样本的确定迁移。未存在正式已发布版本，不编造迁移版本号。

### SRC-L2：平台与编译发布 V0.1 {#src-l2}

[来源包](../history/2026-10-17-decision-sources.zip)内 `l2-preparation-platform-capability-v0.1.html`，21 个主体章。第 03 章“边界”、04–09 章能力 / Manifest / Host、10–12 章构建 / 版本 / Lock、13–16 章编译 / 依赖 / 环、17–21 章案例 / 失败 / 决策 / 交付。完整现行规范是 [L2](l2-preparation.md)；[原归档说明](../history/README.md#l2-integration)记录术语统一和摘要。

### SRC-DEP：跨层依赖 V0.1 {#src-dependency}

[来源包](../history/2026-10-17-dependency-reactivity-sources.zip)内 `l1-l4-dependency-reactivity-v0.1.html`，23 个主体章及整合前 13 份 Markdown。第 02 / 05 章分离概念及使用位置，07–10 章递归分析 / 计划 / Scope，11–18 章接口 / 时机 / L4 三方案 / 生命周期 / 跨层流程，19–23 章验收 / 决策 / 迁移 / 术语。现行[依赖专题](dependency-reactivity.md)承接；[迁移说明](../history/README.md#dependency-integration)说明 dependsOn→watch。

### SRC-V04：L3 Flush / Trace V0.4 {#src-v04}

[来源包](../history/2026-10-18-l3-flush-sources.zip)内 `l3-reactive-engine-flush-trace-v0.4.html`，20 个主体章及整合前 17 份来源。第 04–09 章不可变数据 / 非原子 Batch / Flush / 最新态，10–15 章保护 / 错误 / Trace / 消费者，18–20 章 R01–R26、C01–C18 和路线。现行[L3 决策表](l3-reactive-engine.md#l3-decisions)保留原编号，并显式标出后续替代，不能将 V0.4 的 Health 候选再当现行基线。

### SRC-V05：原始 / 编译后协议与 Watch V0.5 {#src-v05}

[来源包](../history/2026-10-19-protocol-runtime-v05-sources.zip)内 `l1-l2-l3-definition-prepared-watch-runtime-v0.5.html`，19 个主体章及整合前 20 份来源。原标日期 2026-10-18，整合日期 2026-10-19。第 01–06 章双结构 / Watch / 作者确认 / 编译，07–13 章执行 / 错误 / 缺失 / 整体熔断 / Trace，16–18 章 D01–D22 / 未决 / 12 个案例。当前[总账与案例](dependency-reactivity.md#dependency-v05-decisions)区分历史状态及后续进展。

### SRC-V06：变化索引与 Scope V0.6 {#src-v06}

[来源包](../history/2026-10-19-data-scope-v06-sources.zip)内 `l3-data-change-dependency-index-scope-v0.6.html`，20 个主体章及整合前 20 份来源。第 04 章当时的 Baseline / Reset，05–14 章逐 Command / 等值 / Trie / 相对 Scope / ReadState / 生命周期，18–19 章 16 场景与 D01–D25。现行[总账](l3-reactive-engine.md#l3-v06-decisions)保留 D07 / D08 当时确认与当前撤回；D16–D20 仍为推荐，不能提升状态。

### SRC-HOST：用户明确的 Runtime / Host 边界修订 {#src-host}

[来源包](../history/2026-10-19-runtime-host-boundary-sources.zip)内 `user-confirmed-runtime-host-boundary.md`，以及 `before-runtime-host-boundary/` 的 22 份源文件。摘录四条原则和 Context 答复，明确声明不是完整逐字消息。现行[四条原则 / B01–B08](l3-reactive-engine.md#l3-runtime-host-boundary)承接，替代 V0.6 自动业务基准 / 主动 Reset 重算。缺完整对话标为来源局限，不伪造会话轮次。

### SRC-V07：Validation V0.7 {#src-v07}

[来源包](../history/2026-10-19-validation-v07-sources.zip)内 `l3-validation-engine-stage-design-v0.7.html`，18 个主体章及整合前 22 份来源。第 03 章候选收缩、05–09 章完整 Schema / Pending / 前置 / 算法、10–14 章 Source / 消息 / 订阅 / 异步 / 完整校验，16–18 章 D01–D19 / V01–V16 / 后续。现行[校验专题](l3-validation.md)完整承接，D06 与 D14 的张力保留，见 [REV-01 / 02](governance.md#rev-01)。

### SRC-VAL：候选验证源及现有结果 {#src-validation}

[原始验证包](../history/l1-protocol-validation-source.zip)内 `l1_protocol_validation/README.md`、baseline、01–05 cases / fixtures / manifests / validator / report；现行源在 `docs/validation/`，新增 06–08 来自 extend_cases.py。01–05 仅按已记录的 Profile 去包装、External watch 等确定迁移，原包不改。精确迁移检查由[验证入口](../validation/README.md#reproduce)执行，结果以[报告](../validation/report.json)和[覆盖](../validation/coverage.json)为准。

### SRC-REVIEW：本次重构前的完整来源快照 {#src-review}

[本次快照](../history/2026-10-19-architecture-review-sources.zip)保存 `before-architecture-review/` 下 22 份文件：原有全部现行设计 Markdown、根 / docs 入口、CONTEXT、历史 / 验证说明和两个阅读生成模块。SHA-256 为 `33ef0fe7198c96f40d5b6b3cd75e62acd9e23685df9a47594fc92b32207cebe5`。它记录本次修改前状态，不冒充早期用户原件。原有技术章节、代码块和 diagram ID 由覆盖脚本对照检查。

## 重要结论、来源与处理映射 {#conclusion-map}

K 编号为本次稳定结论索引。来源中的“已确认”只指其相应范围；表中“推荐 / 未决”不能写入正式运行契约。

| ID / 模块 | 可独立检索的结论与现行状态 | 原始依据 | 完整现行位置 / ADR | 重构处理及后续变化 |
| --- | --- | --- | --- | --- |
| K01 全局 | 四层、唯一数据、多视图共享：确认 | SRC-EARLY、SRC-L1 D1 | [层级](architecture.md#architecture)、[001](decisions/ADR-FE-001-boundaries.md) | 保留完整图与责任；归入既有主题 |
| K02 Host | 请求 / 上传 / 业务提交移出核心：确认 | SRC-L1 第三组 ADR-03-00 / EXT-1 / EXT-2 | [三路径](l1/05-view-material-host.md#host)、[001](decisions/ADR-FE-001-boundaries.md) | 旧 Resource Manager / 通用执行器归档；跨层竞态仍保留 |
| K03 Data | 允许无效工作态、Missing ≠ null、Host 值优先补缺：确认原则 | SRC-L1 第一组 D2 / D7 与定稿 | [Data](l1/02-data-reference-scope.md#data)、[002](decisions/ADR-FE-002-static-language.md) | 保留，不扩写默认值实现算法 |
| K04 语言 | 结构化 Reference、根路径固定、局部 Binder、Handle 分责：确认 | SRC-L1 第一 / 六组、定稿 D2 / D3 | [引用 / Scope](l1/02-data-reference-scope.md#reference)、[002](decisions/ADR-FE-002-static-language.md) | 全局词法表候选归档；不与 L3 实例表混同 |
| K05 表达式 | 纯 AST、递归 ValueSpec / Literal、Named 不捕获局部：确认 | SRC-L1 第二组 / 定稿 D4 | [Expression](l1/03-expression-validation.md#expression)、[002](decisions/ADR-FE-002-static-language.md) | 完整类型草图与例子保留，Union 待固化 |
| K06 能力 | 纯同步校验复用 Pure Function、assert boolean：确认 | SRC-L2 第 04–07 章、L2 D04–D06 | [纯函数](l2-preparation.md#l2-pure-functions)、[002](decisions/ADR-FE-002-static-language.md) | 术语统一；op 未迁移，短名规范化待固化 |
| K07 View | 三节点、Profile 直接值、bindings / slots Canonical：确认 | SRC-L1 第四 / 六组 / 定稿 D8–D10、包装修订 | [View](l1/05-view-material-host.md#view)、[003](decisions/ADR-FE-003-view-material.md) | 合并重复入口；entry 等旧语法只留历史 |
| K08 Template | schemaRef + Typed DataReference 静态复用：确认 | SRC-L1 定稿 D11 与修订 08 | [模板](l1/05-view-material-host.md#templates)、[003](decisions/ADR-FE-003-view-material.md) | 泛型 / 动态 ID / Handle 参数候选归档 |
| K09 Material | 容器负责呈现；不建独立 Validation DSL：确认 | SRC-L1 修订 05 / 06 / 09、D12 / D13 | [Interaction](l1/05-view-material-host.md#interaction)、[003](decisions/ADR-FE-003-view-material.md) | Presentation / ValidationMetadata 明确替代 |
| K10 编译 | 唯一 Prepared 执行入口：确认 | SRC-V05 D01 / D02 / D05 | [双结构](dependency-reactivity.md#dependency-compiled-protocol)、[004](decisions/ADR-FE-004-prepared-entry.md) | 原始 / 编译双轨候选被替代；ABI 仍未冻结 |
| K11 依赖 | Reads / Watch / Subscription 分离，作者确认建议：确认 | SRC-DEP D01 / D04 / D05、SRC-V05 D03 / D04 | [Watch](dependency-reactivity.md#dependency-watch-review)、[005](decisions/ADR-FE-005-watch-subscription.md) | 使用位置唯一完整矩阵在 L1；其余主题引用 |
| K12 Constraint | Internal when+assert，External watch+when：确认 | SRC-DEP 第 04–05 章、DEP.D02 / D03 | [Constraint](l1/03-expression-validation.md#constraint)、[005](decisions/ADR-FE-005-watch-subscription.md) | dependsOn→watch 迁移；不新增 External Payload |
| K13 View 订阅 | L2 编译 / L3 匹配 / L4 挂载；规则不随 View：确认 | SRC-DEP 第 15–18 章 | [生命周期](dependency-reactivity.md#dependency-view)、[005](decisions/ADR-FE-005-watch-subscription.md) | 三方案取舍保留；首次读与改绑 API 未决 |
| K14 数据执行 | 即时不可变 Root、默认非原子 batch：确认 | SRC-V04 R01–R03、SRC-V05 D06 | [数据](l3-reactive-engine.md#l3-data)、[006](decisions/ADR-FE-006-command-flush.md) | 替代旧第三组 B6 / 候选树统一提交 |
| K15 Reaction | pending 合并、最新态、执行后可重入队：确认 | SRC-V04 R04 / R05、SRC-V05 D07 | [合并](l3-reactive-engine.md#l3-reactions)、[006](decisions/ADR-FE-006-command-flush.md) | 不丢显式 Command 次数；排序仍推荐 / 未决 |
| K16 Flush | 延迟启动同步执行，同轮级联，Operation 为来源：确认 | SRC-V04 R06 / R07、SRC-V05 D08 | [Flush](l3-reactive-engine.md#l3-flush)、[006](decisions/ADR-FE-006-command-flush.md) | 分段调度延期；通知重入 / Pending 未决 |
| K17 检测 | 逐 Command 前后 Data / Scope，候选后比较：确认 | SRC-V06 D04 / D05 / D12 | [检测](l3-reactive-engine.md#l3-change-detection)、[007](decisions/ADR-FE-007-scope-comparison.md) | 旧 Root / ScopeChange 不传播到 pending |
| K18 Scope | 稳定身份、父级相对位置：确认 | SRC-V06 D10 / D11 | [Scope](l3-reactive-engine.md#l3-scope-index)、[007](decisions/ADR-FE-007-scope-comparison.md) | 完整绝对路径为解析结果，不重写全部后代 |
| K19 候选索引 | Object.is、Trie、局部旧视图、整数组重建：推荐 | SRC-V06 D16–D20、D23–D25 | [等值 / 索引](l3-reactive-engine.md#l3-observed-equality)、[007](decisions/ADR-FE-007-scope-comparison.md) | 原状态保留；OD-07，不冻结为 ABI |
| K20 生命周期 | 仅新实例首次激活，业务编辑归 Host：确认 | SRC-HOST，明确替代 SRC-V06 D07 / D08 / D21 / D22 | [四原则](l3-reactive-engine.md#l3-runtime-host-boundary)、[008](decisions/ADR-FE-008-host-editing.md) | 旧自动 Baseline / 主动 Reset 归档，B01–B08 保留 |
| K21 快照 | 稳定 snapshot 不 Flush / 建基准 / 标 Clean：确认 | SRC-HOST | [snapshot](l3-reactive-engine.md#l3-initialization-baseline)、[008](decisions/ADR-FE-008-host-editing.md) | 与 Command 临时旧值、Host 业务快照分别解释 |
| K22 Context | Host 提供、表达式只读、Data-only Command / Watch：确认 | SRC-HOST 末段 | [Context 边界](l3-reactive-engine.md#l3-runtime-host-boundary)、[008](decisions/ADR-FE-008-host-editing.md) | 不新增 Context 触发链；证明新鲜度 OD-09 |
| K23 错误 | 可隔离错误继续、预算整体熔断、无局部 Health：确认 | SRC-V05 D09 / D10，替代 SRC-V04 第 11 章候选 | [错误](l3-reactive-engine.md#l3-errors)、[009](decisions/ADR-FE-009-errors-trace.md) | Pending / Submit 的空缺公开，REV-03 |
| K24 追踪 | 临时线性事实、Change 来源、首次入队建 Context：确认 | SRC-V04 R08 / R09、SRC-V05 D11 / D12 | [Trace](l3-reactive-engine.md#l3-trace)、[009](decisions/ADR-FE-009-errors-trace.md) | 预算 / 截断 / 参数待定；Replay 与历史恢复延期 |
| K25 校验 | 完整根 Schema、独立 Constraint、共用索引：主线收敛 | SRC-V07 D01–D04 | [Schema](l3-validation.md#validation-schema)、[010](decisions/ADR-FE-010-validation.md) | 不拆 Keyword、不跨端传 JS 校验函数 |
| K26 校验前置 | 本轮整理收敛；严格缺失倾向与增量兼容未决 | SRC-V07 D05 / D06 / D14–D16 | [前置](l3-validation.md#validation-round)、[010](decisions/ADR-FE-010-validation.md) | 不把 D06 升格完整契约；REV-01 / 02、OD-01 / 02 |
| K27 校验结果 | 字段聚合方向收敛，Source / 原子通知 / 模板推荐 | SRC-V07 D08–D13 | [结果](l3-validation.md#validation-results)、[010](decisions/ADR-FE-010-validation.md) | 过期不可提交为必要约束；token / Issue API 待定 |
| K28 完整性 | 无 Issue 不等于通过；完整覆盖 / 新鲜度必要 | SRC-L1 第五组 F4 / F5、SRC-V07 D17 | [完整校验](l3-validation.md#validation-completeness)、[010](decisions/ADR-FE-010-validation.md) | 准确返回、异常交接、输出转换未闭环 |
| K29 L2 / 平台 | 静态编译与平台资产 / 发布分责：确认 | SRC-L2 D01–D03 / D08 / D09 | [平台](l2-preparation.md#l2-platform)、[011](decisions/ADR-FE-011-release-lock.md) | 两条流水线与应用本地能力保留 |
| K30 发布 | 版本+制品锁定、不可变 Release、ABI 独立：确认 | SRC-L2 D10 / D11、第 10–12 章 | [发布](l2-preparation.md#l2-release)、[011](decisions/ADR-FE-011-release-lock.md) | 摘要覆盖 / 兼容矩阵未冻结；不虚构已发布版本 |
| K31 证据 | 静态结构与有界探针不能证明生产执行：事实 | SRC-VAL 及现行报告的 validationScope | [附件边界](../validation/README.md)、[模块矩阵](governance.md#design-status) | 保留原报告，实施验收不计入现有通过统计 |

所有旧结论只有有明确替代来源的才标“被替代”。未定位到完整实现接口的内容继续留在 [OD 清单](governance.md#open-decisions)，不靠 ADR 补造设计。新增 REV-04 / 05 / 07 / 10 和 OD-13 / 14 的反例与建议是本次分析，其来源是相关现行契约之间的接缝，不冒充历史已讨论方案。

## 机器盘点、完整保留与未覆盖语义 {#source-inventory}

<!-- BEGIN SOURCE INVENTORY SUMMARY -->

以下数字由脚本生成，仅表达文件身份和内容保留检查：

| 盘点类别 | 条目数 |
| --- | --- |
| `candidate-validation-evidence` | 36 |
| `current-markdown` | 30 |
| `documentation-tooling` | 5 |
| `history-archive` | 9 |
| `history-integration-snapshot` | 165 |
| `history-original-member` | 30 |
| `history-readable-copy` | 30 |
| 合计（ZIP 容器与成员分别计数） | 305 |

原有 15 份设计 Markdown 的 132 个二级章节锚点、89 个代码块及 15 个架构图 ID 全部保留。
清单有 266 组不同字节内容，39 个重复字节条目；去重只用于盘点，不删除来源。

<!-- END SOURCE INVENTORY SUMMARY -->

机器检查保留原有技术主题的二级章节锚点、所有代码块和原 diagram ID，识别新增来源及重复字节。历史文件 / ZIP 成员的 headings 清单只是可定位性证据；`indexed-preserved` 表示原文已盘点保留，绝不等同于逐句完成语义审查。表中 K01–K31 才是已明确映射的重要结论；相关未决边界在治理篇维护。

现有机器清单不记录不存在的决策人或逐字会话；ZIP 内脚本、全量 JSON 和生成页面的归档完整性不等于生产语义覆盖。原有样本的 Runtime 未覆盖项见 SRC-VAL；本次不把它们升级为已经通过。

## 可重复执行与新增资料处理 {#incremental-coverage}

从项目根运行：

```bash
python3 tools/docs/audit_architecture.py
python3 tools/docs/build_docs.py
python3 tools/docs/audit_architecture.py --check
python3 tools/docs/build_docs.py --check
```

第一步重建机器清单与本篇盘点摘要；check 发现任何来源身份、章节、文件数量或当前规范变化时失败，要求重新审查再生成。它不自动确认新来源结论。协议样例发生变更时另运行 `python3 docs/validation/run_validation.py`。

新增资料先分配 SRC 编号、核对摘要 / 原标题 / 锚点，再判断补充、明确替代、候选或冲突，更新 K 条目、所属规范、ADR 和治理事项。新资料若不能归入现有 SRC 类别，工具要求先补充分类映射，不静默算作已审查。历史源只归档；需要改变现行行为时以明确确认及可复现反例为依据，保留修订前源文件和替代关系。
