(() => {
  const doc = document.documentElement;
  const sidebar = document.getElementById('sidebar');
  const mask = document.getElementById('mask');
  const menuButton = document.getElementById('menuBtn');
  const themeButton = document.getElementById('themeBtn');
  const storedTheme = (() => {
    try { return localStorage.getItem('form-engine-docs-theme') || localStorage.getItem('l1v1-theme'); }
    catch { return null; }
  })();

  function setTheme(theme) {
    doc.dataset.theme = theme;
    themeButton.textContent = theme === 'dark' ? '浅色' : '深色';
    themeButton.setAttribute('aria-label', theme === 'dark' ? '切换浅色主题' : '切换深色主题');
    try { localStorage.setItem('form-engine-docs-theme', theme); } catch {}
  }
  setTheme(storedTheme === 'dark' ? 'dark' : 'light');
  themeButton.addEventListener('click', () => setTheme(doc.dataset.theme === 'dark' ? 'light' : 'dark'));
  addEventListener('storage', event => {
    if (event.key === 'form-engine-docs-theme') setTheme(event.newValue === 'dark' ? 'dark' : 'light');
  });

  function closeMenu() {
    sidebar.classList.remove('open');
    mask.classList.remove('open');
    menuButton.setAttribute('aria-expanded', 'false');
  }
  menuButton.addEventListener('click', () => {
    const open = sidebar.classList.toggle('open');
    mask.classList.toggle('open', open);
    menuButton.setAttribute('aria-expanded', String(open));
  });
  mask.addEventListener('click', closeMenu);
  addEventListener('keydown', event => { if (event.key === 'Escape') closeMenu(); });
  document.getElementById('printBtn').addEventListener('click', () => window.print());
  document.querySelectorAll('.sidebar a').forEach(link => link.addEventListener('click', closeMenu));

  document.querySelectorAll('.copy').forEach(button => button.addEventListener('click', async () => {
    const raw = button.closest('.code-box').querySelector('pre code').textContent;
    try {
      await navigator.clipboard.writeText(raw);
      button.textContent = '已复制';
    } catch {
      const textarea = document.createElement('textarea');
      textarea.value = raw;
      textarea.style.position = 'fixed';
      textarea.style.opacity = '0';
      document.body.appendChild(textarea);
      textarea.select();
      try { button.textContent = document.execCommand('copy') ? '已复制' : '复制失败'; }
      catch { button.textContent = '复制失败'; }
      textarea.remove();
    }
    setTimeout(() => { button.textContent = '复制'; }, 1400);
  }));

  const navLinks = [...document.querySelectorAll('.toc a')];
  const sections = navLinks.map(link => document.getElementById(link.dataset.to)).filter(Boolean);
  const groups = [...document.querySelectorAll('.toc-group')];
  const searchInput = document.getElementById('tocSearch');
  let activeSection;
  function openGroup(group) {
    if (!group) return;
    if (!searchInput.value.trim()) groups.forEach(other => { other.open = other === group; });
    else group.open = true;
  }
  function revealHash() {
    let anchor;
    try { anchor = decodeURIComponent(location.hash.slice(1)); } catch { return; }
    const target = document.getElementById(anchor);
    if (target?.tagName === 'DETAILS') target.open = true;
    for (let parent = target?.parentElement; parent; parent = parent.parentElement) {
      if (parent.tagName === 'DETAILS') parent.open = true;
    }
    const chapter = target?.closest('.protocol-chapter') || target?.querySelector('.protocol-chapter');
    const link = navLinks.find(link => link.dataset.to === (chapter?.id || anchor));
    const group = link?.closest('.toc-group');
    openGroup(group);
    return Boolean(group);
  }
  addEventListener('hashchange', revealHash);
  revealHash();
  function update() {
    const maximum = doc.scrollHeight - innerHeight;
    document.getElementById('progress').style.width = `${maximum > 0 ? Math.max(0, Math.min(100, scrollY / maximum * 100)) : 0}%`;
    let current = sections[0]?.id;
    sections.forEach(section => { if (section.getBoundingClientRect().top < 145) current = section.id; });
    navLinks.forEach(link => {
      const active = link.dataset.to === current;
      link.classList.toggle('active', active);
      if (active) link.setAttribute('aria-current', 'location');
      else link.removeAttribute('aria-current');
    });
    const activeLink = navLinks.find(link => link.dataset.to === current);
    groups.forEach(group => group.classList.toggle('active-group', Boolean(activeLink && group.contains(activeLink))));
    if (current !== activeSection) {
      const group = activeLink?.closest('.toc-group');
      openGroup(group);
      activeSection = current;
    }
  }
  let scheduled = false;
  addEventListener('scroll', () => {
    if (scheduled) return;
    scheduled = true;
    requestAnimationFrame(() => { update(); scheduled = false; });
  }, { passive: true });
  addEventListener('resize', update);
  update();
  let groupStates;
  searchInput.addEventListener('input', event => {
    const query = event.target.value.trim().toLocaleLowerCase();
    if (query && !groupStates) groupStates = groups.map(group => group.open);
    navLinks.forEach(link => {
      const group = link.closest('.toc-group');
      const groupLabel = group?.querySelector('summary').textContent.toLocaleLowerCase() || '';
      const chapterLabel = `${link.textContent} ${link.title}`.toLocaleLowerCase();
      link.hidden = Boolean(query) && !chapterLabel.includes(query) && !groupLabel.includes(query);
    });
    groups.forEach((group, index) => {
      group.hidden = Boolean(query) && ![...group.querySelectorAll('a')].some(link => !link.hidden);
      if (query && !group.hidden) group.open = true;
      else if (!query && groupStates) group.open = groupStates[index];
    });
    if (!query) {
      groupStates = undefined;
      const activeGroup = navLinks.find(link => link.dataset.to === activeSection)?.closest('.toc-group');
      if (!revealHash()) openGroup(activeGroup);
    }
  });
})();
