# 命令与同步联动

> L1 V1.0 架构与语义决策正文；正式类型、Schema 与发布验收状态见各节。

## Command：封闭的受控数据修改语言 {#commands}

> 状态：已收敛

| 操作 | 语义 | 边界 |
| --- | --- | --- |
| set | 替换目标 Data 值 | 目标必须为可写 Data Reference |
| patch | 浅层对象字段更新 | 不隐式递归深度合并 |
| remove | 删除属性位置 | 区分将属性设为 null |
| array.insert | 插入集合项 | 受目标 Schema 约束 |
| array.remove | 按稳定项身份删除 | 不可仅依赖不稳定 index |
| array.move | 按稳定项身份移动 | 保留被移动项身份 |
| batch | 按顺序组织多个 Command，各条有效修改即时生效 | 默认非原子，不默认回滚前序成功修改；不能变成通用工作流 |

**修改目标与计算值必须严格区分**

```json
{
  "op": "set",
  "target": { "source": "data", "path": "/order/total" },
  "value": {
    "$expr": {
      "op": "mul",
      "args": [
        { "ref": { "source": "data", "path": "/order/price" } },
        { "ref": { "source": "data", "path": "/order/quantity" } }
      ]
    }
  }
}
```

Command 只做表单数据修改。请求上传、业务审批、支付、弹窗动画和远端提交均不变成 Command 类型。复杂业务逻辑可以由 Host 根据结果发回一个受控 Command。

Command ValueSpec 在执行时求值，不因读取其他字段而自行建立订阅。Reaction 产生的新 Command 也走相同修改入口，保证后续依赖继续统一匹配。Command 的顺序与次数是行为的一部分，两次 `array.insert` 不能仅因目标相同就合并成一次。

有效 Command 同步更新 Working Data，后续读取立即可见；数据允许业务上暂时不合法，由 Validation 报告。单个结构操作仍须保持 Data 与 Scope Identity 一致。`batch` 与 `then[]` 不默认整体回滚；可隔离的单 Command 错误记录后继续后续独立命令，其他 Reaction 按有效 Change 响应，不检查上游成功。具体错误分类、接口与无法继续的结构性条件待固化，详见 [L3 数据与修改边界](../l3-reactive-engine.md#l3-data)。

## Reaction：明确触发与条件的边界 {#reactions}

> 状态：已收敛

**规则级作用域可使用有序绑定链**

```typescript
interface Reaction {
  id: string;
  scope?: ScopeBinder | ScopeBinder[];
  watch: DataReference[];
  when?: Expression;
  then: Command[];
}
```

**数据变化时的最小联动声明**

```json
{
  "id": "clear-city-on-country-change",
  "scope": {
    "from": { "source": "data", "path": "/insureds" },
    "as": "insured",
    "mode": "each"
  },
  "watch": [
    { "source": "data", "scope": "insured", "path": "/country" }
  ],
  "then": [
    {
      "op": "set",
      "target": { "source": "data", "scope": "insured", "path": "/city" },
      "value": null
    }
  ]
}
```

`watch` 决定何时触发，`when` 决定触发后是否执行；二者不能互相代替。Expression 读取到的依赖不应自动变成触发条件。`then` 已经是有序 Command 数组，不必再强制包一层 `batch`。

L2 分开记录读取与显式触发关系，L3 随 FormRuntime / Scope 激活 Reaction，通过统一观察机制匹配 watch；View 是否挂载不影响业务联动。`when` 与 `then` 的读取均不自动追加 watch。首次是否运行 Reaction 是独立生命周期策略，不能由订阅注册隐式决定。

L2 可提示 Reads / Watch 差异或潜在写冲突，由作者选择补充或保持，确认后修改 L1 并重编。不静默增加、删除或覆盖 watch，也不把未采纳建议作为 Runtime 执行依赖。Constraint / View 仍按各自语义推导观察，见 [编译审查闭环](../dependency-reactivity.md#dependency-watch-review)。

V0.6 确认首次激活执行策略显式可配置：L1 表达，L2 编译，在 Runtime / 新 Scope 实例激活时按策略入队，不依赖先发生 watch 变化，也不等于注册订阅必然运行。来源用 `runOnActivate` 表达，具体字段形状、默认值与兼容规则尚待正式规范固化；当前候选 Schema / 样例未因此自动支持该字段。它不是通用 onInit 脚本，也不将初始化的输入缺失语义交给 Ready 状态机。

每条 Command 内部完成前后 Data / Scope 读取和变化检测，待执行实例只接收失效标识与必要 ChangeId。对象 / 数组引用比较、子路径同值跳过是 V0.6 的推荐相等性方案；不把 Command 修改来源或“哪个 Reaction 写这个字段”变成触发条件。普通字段、Host 回写与 Reaction 写回走同一检测，不引入派生字段所有权，详见 [观察粒度](../l3-reactive-engine.md#l3-observed-equality)。

Reaction 表达最新状态收敛：同一实际 Scope 下的实例尚待执行时，多次 watch 失效可以合并，执行时读取最新 Data；执行后再次失效允许重新入队。它不承诺每次触发各执行一次。需要每次点击、新增都保留独立效果时，明确发出 Command / Host 事件。`then` 允许数组操作，但无条件重复新增等非幂等写入需诊断收敛风险。

> **范围约束**
> 
> Reaction.watch 的变化匹配只消费内部 Data Change，V0.6 的显式首次激活策略是另一种入队原因；Command 求值与修改保持同步受控，不引入异步业务 Reaction。外部校验完成仅更新 Validation State，不触发只观察 Data 的联动；需要改变数据时由 Host 显式提交 Command。L3 V1 延迟启动同步 Flush，内部级联留在当前轮；可隔离错误继续独立行为，预算超限整轮熔断，不建立父子执行控制或局部 Health。通知重入、精确排序与熔断后 Pending 仍待固化，见 [L3 执行契约](../l3-reactive-engine.md#l3-flush)。L1 不加入队列、计数、Trie、Scope Index 或 Trace 字段。
