# 生命周期与多视图交付

> L1 V1.0 架构与语义决策正文；正式类型、Schema 与发布验收状态见各节。

## 初始化、更新、重初始化与提交 {#lifecycle}

> 状态：已收敛

| 操作 | 语义约束 |
| --- | --- |
| Initialize | Host 数据优先，补真正缺失的默认值；创建 Scope 与规则，按首次激活策略使初始 Reaction 正常收敛后建立 Baseline |
| Update | 向当前 Working Data 提交受控数据修改；不是重新初始化 |
| Reinitialize | 以新外部初始数据明确建立新的当前基线；重建相应身份 / 规则并满足初始化完成契约，不假扮逐字段编辑 |
| Reset | 恢复当前业务基准并按当前环境重新计算；不是必然回到第一次加载的旧基线，显式重算入口 / 范围待讨论 |
| Submit / Readiness | 相关联动可信收敛、内外约束与输出完整性符合要求后，由 Host 执行真实提交 |

Definition 不增加 `onInit`、`onReset`、`beforeSubmit` 等通用生命周期脚本。宿主 API 的具体返回值或事务流程属于 L3/Host 实现，但上述生命周期的语义差异必须保持。

Runtime 随 Form / Scope 激活业务 Reaction 与 Constraint；首次校验、主动校验与 Reaction 初始化策略分别有明确入口，不能把 subscribe 等同于首次执行。重初始化和销毁需要处理旧订阅与外部结果适用性，不能只替换 Data 而保留无效实例关联。

V0.6 已确认首次激活策略显式可配置、初始 Reaction 正常收敛后建立 Baseline，不让首次自动联动直接制造 Dirty；不等待所有外部异步 Validation 才建立该基准。首次字段名 / 默认值、初始化异常完成契约与 SDK 仍待固化，缺失与清空继续由业务规则表达。

推荐 Host 先异步取得数据，再创建 Runtime；若确需先创建，再使用显式 initialize(data)，API 尚未冻结，并需防止迟到响应覆盖已编辑值。普通 set / patch 导入不是初始化完成信号，网络等待也不是初始化时钟。

Reset 按当前 Context 重算的目标已确认；Watch 输入不变时，不能指望普通变化匹配自动重新执行。主动选择哪些规则、如何调度，以及 Context 改变后的 Dirty 是否忽略部分差异仍待讨论；不推断派生字段所有权。详见 [Baseline 与 Reset](../l3-reactive-engine.md#l3-initialization-baseline)。异常 / 整体预算停止、Pending 再触发与 Validation / Submit 衔接仍见 [L3 完成边界](../l3-reactive-engine.md#l3-consumers)，不再采用局部 Health 传播候选。

## 多 Profile 与按需交付 {#profiles}

> 状态：已收敛

View Profile 表达同一业务数据在不同终端或场景下采用不同的物料树。服务端或 L2 可以按请求只准备当前 Profile 的入口与其静态引用依赖，但共享 Data Schema、Constraint、Reaction 不能仅因为某字段不可见就被裁剪掉。

Profile 切换只释放旧视图订阅并挂载新视图订阅及局部 UI 状态；同一 FormRuntime 的业务规则不随 View 切换反复注册或销毁。隐藏、虚拟列表未挂载与数据 / 校验有效性属于不同生命周期，见 [跨层激活归属](../dependency-reactivity.md#dependency-layers)。

**Profile 是选择入口，不是复制 Form Definition**

```json
{
  "views": {
    "expanded": {
      "$use": "expanded-form"
    },
    "compact": {
      "$use": "compact-form"
    }
  }
}
```
