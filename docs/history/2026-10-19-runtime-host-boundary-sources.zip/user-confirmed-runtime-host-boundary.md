# 2026.10.19 · 用户确认的 Runtime / Host 边界修订

来源：当前对话中的用户明确指令；本文件为决策摘录，不冒充逐字完整原始消息。

1. 数据是事实，Runtime 不区分用户、Host、Reaction 的字段所有权或编辑来源。
2. 常规 Reaction 只响应显式 Watch 的有效观察值变化，不主动修复业务结果。
3. runOnActivate 仅作用于新 Reaction 实例首次激活，不是重跑已有实例的通用入口。
4. Dirty、业务 Baseline 与 Reset 策略归 Host，Runtime 提供稳定快照与受控读写。

被替代：Runtime 自动建立 Baseline；Reset 为使用当前费率主动重算已有实例；Context / Dirty 作为 Runtime 核心待决项。

用户已进一步确认：Context 保留现行契约，本次只收敛职责边界。L1 Command 只写 Data，Reaction.watch 只接受 DataReference；不在本次扩展 Context 写入或触发协议。
