# L1 V1.0 FormDefinition：5 级协议能力验证包

本验证包来自本轮已归档的《L1 Definition Protocol V1.0 · 架构定稿与完整决策归档》，不意味着官方正式 JSON Schema 已经发布，也不意味着 L3/L4 实现已经通过。

## 5 份独立 Canonical 协议

1. `cases/01-basic.json`：基础资料表单；Data + Material + Binding + Host Event。
2. `cases/02-order.json`：命名 Expression、动态 Props、国家变更后清空城市、同步 Constraint。
3. `cases/03-nested.json`：团队/成员两层 Scope、Typed Template Params、受控删除、逐成员外部校验。
4. `cases/04-insurance-archive.json`：原 L1 V1.0 HTML 定稿文档中的投保 JSON，未更改内容；双 Profile、Sheet 容器、被保人规则。
5. `cases/05-claims-complex.json`：保单/旅客/理赔三层 Scope、跨父级金额约束、条件凭证字段、复合 DateRange、双端视图与外部风险校验。

`fixtures/` 是每份表单相应的有效数据样本。`manifests/` 提供**测试用** Material Contract 和 Host Event 列表，并非正式运行环境。

## 可复现的验证流程

要求 Python 3.9+，安装 `jsonschema` 和 `beautifulsoup4`：

```bash
python -m pip install -r requirements.txt
python build_cases.py
python validator/create_schema.py
python validator/validate_cases.py
python validator/behavior_smoke.py
python create_report.py
```

1. `validator/l1-candidate-structural.schema.json`：根据 L1 归档固化的**候选** Canonical 结构 Schema（用于本轮验收，不能冒称协议正式定稿）。
2. `validator/validate_cases.py`：执行候选 Schema 静态验证、JSON Pointer 和 Scope 校验、View Template 参数 Schema 检查、Material Port 和 Host Event 检查、基础 Expression 类型检查、JSON Schema 样本数据验证，以及 11 个错误注入案例。
3. `validator/behavior_smoke.py`：轻量只读表达式求值和部分受控数据修改抽测：四个 Scope 定位联动、两个内部 Constraint 负例、按 Scope 展开的外部验证义务数量。不具备正式 L3 Runtime 的完整能力。
4. `report.json` 和 `index.html`：机器可读和可视化验收结果。

## 已验证与未验证

**验证通过**：5/5 协议静态+样本，11/11 错误注入被拦截，6/6 行为语义抽测。见 `report.json`。

**尚未验证**：完整表单 Runtime、事务与联动调度、数组项跨排序的稳定身份保持、循环依赖、复杂组合 Schema 推断、外部校验过期/竞态/状态机、完整提交 Readiness、Material 实际 Web/Flutter 渲染。

**仍需规范固化的协议点**：`array.insert`/`array.move` 插入或移动位置的确切形状及规则；Material Manifest 版本锁定；JSON Schema 复杂兼容性的静态验收边界。它们不需要新增顶层领域模型，但不能在正式发布前被含糊处理。

## 源文档

`baseline/L1-Definition-Protocol-V1.0.html` 为归档 HTML 的拷贝，用于可重复提取原始基线 JSON。第 4 份协议未经修改。
